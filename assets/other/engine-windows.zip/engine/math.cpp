/****************************/
/**        --------        **/
/**        math.cpp        **/
/**        --------        **/
/**  Rutinas necesarias    **/
/**  para inicializar d3d  **/
/****************************/

#include <math.h>

/*** Estructura de datos: VERTEX ***/
typedef struct normal_tex_vertex
{
  float  x,  y,  z; // Posici�n
  float nx, ny, nz; // Normal
  float  u,  v;     // Textura
} NORMAL_TEX_VERTEX;
/*__________*/

/*** FVF ***/
DWORD FVF = D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1; // FVF

/*** Colores Comunes ***/
const D3DXCOLOR WHITE  (1.0f, 1.0f, 1.0f, 1.0f);
const D3DXCOLOR BLACK  (0.0f, 0.0f, 0.0f, 1.0f);
const D3DXCOLOR RED    (1.0f, 0.0f, 0.0f, 1.0f);
const D3DXCOLOR GREEN  (0.0f, 1.0f, 0.0f, 1.0f);
const D3DXCOLOR BLUE   (0.0f, 0.0f, 1.0f, 1.0f);
const D3DXCOLOR YELLOW (1.0f, 1.0f, 0.0f, 1.0f);
const D3DXCOLOR CYAN   (0.0f, 1.0f, 1.0f, 1.0f);
const D3DXCOLOR MAGENTA(1.0f, 0.0f, 1.0f, 1.0f);
const D3DXCOLOR GRAY   (0.5f, 0.5f, 0.5f, 1.0f);
const D3DXCOLOR PALE   (0.1f, 0.1f, 0.1f, 1.0f);

/*** Colores Extra ***/
const D3DXCOLOR BEACH_SAND         (1.0f , 0.976, 0.616, 1.0f);
const D3DXCOLOR DESERT_SAND        (0.980, 0.804, 0.529, 1.0f);
const D3DXCOLOR LIGHTGREEN         (0.235, 0.722, 0.471, 1.0f);
const D3DXCOLOR PUREGREEN          (0.0f , 0.651, 0.318, 1.0f);
const D3DXCOLOR DARKGREEN          (0.0f , 0.447, 0.212, 1.0f);
const D3DXCOLOR LIGHT_YELLOW_GREEN (0.486, 0.773, 0.463, 1.0f);
const D3DXCOLOR PURE_YELLOW_GREEN  (0.224, 0.710, 0.290, 1.0f);
const D3DXCOLOR DARK_YELLOW_GREEN  (0.098, 0.482, 0.188, 1.0f);
const D3DXCOLOR LIGHTBROWN         (0.776, 0.612, 0.427, 1.0f);
const D3DXCOLOR DARKBROWN          (0.451, 0.392, 0.341, 1.0f);


/*** Estructura de datos: RAY ***/
typedef struct ray
{
  D3DXVECTOR3 p0;
  D3DXVECTOR3 u;
} RAY;

/*** Estructura de datos: SPHERE ***/
typedef struct sphere
{
  D3DXVECTOR3 center;
  float       radius;
} SPHERE;

/*** Estructura de datos: BOX ***/
typedef struct box
{
  D3DXVECTOR3 min;
  D3DXVECTOR3 max;
} BOX;
/*__________*/


/*** Funci�n: Poner los datos de un v�rtices ***/
void SetVertexData( NORMAL_TEX_VERTEX* vertex,    // V�rtice a llenar datos
		    float x , float y , float z , // Posisici�n
		    float nx, float ny, float nz, // Normal
		    float u , float v )           // Textura
{
  vertex->x  = x ; vertex->y  = y ; vertex->z  = z;
  vertex->nx = nx; vertex->ny = ny; vertex->nz = nz;
  vertex->u  = u ; vertex->v  = v ;
}

/*** Funci�n: Convierte de float a DWORD ***/
DWORD FtoD( float v )
{
  return *((DWORD*)&v);
}

/*** Funci�n: devuelve un n�mero decimal aleatorio ***/
float RandomFloat( float min, float max, unsigned int decimals )
{
  unsigned long int d = pow( 10, decimals );
  unsigned long int r = abs(max - min) * d;
  return min + (rand()%r / (float)d);
}

/*** Funci�n: Calcula los FPS ***/
unsigned int CalculateFPS( float elapsed )
{
  static float         elapsedTime  = 0.0f;
  static unsigned int  numberFrames = 0;
  static unsigned int  FPS          = 0;

  elapsedTime += elapsed; // Tiempo se acumula
  numberFrames++;         // 1 cuadro se acumula
  if( elapsedTime > 1.0f )              // Ya pas� un segundo
  {
      FPS = numberFrames / elapsedTime; // FPS = Frames / Time
      elapsedTime  = 0.0f;
      numberFrames = 0.0f;
  }

  return FPS;
}

/*** Funci�n: Devuelve el rayo creado desde un punto x,y en la ventana ***/
RAY PickingRay( LONG x, LONG y, IDirect3DDevice9* Device )
{
  RAY res;
  D3DVIEWPORT9 viewPort;
  D3DXMATRIX proj, view, world;
  D3DXVECTOR3 screenNear( (float)x, (float)y, 0.0f );
  D3DXVECTOR3 screenFar ( (float)x, (float)y, 1.0f );
  D3DXVECTOR3 worldNear, worldFar;

  // Obtengo las matrices
  Device->GetViewport( &viewPort );
  Device->GetTransform( D3DTS_PROJECTION, &proj );
  Device->GetTransform( D3DTS_VIEW, &view );
  D3DXMatrixIdentity( &world );
  
  // Obtengo los puntos en el plano lejano y cercano
  D3DXVec3Unproject( &worldNear, &screenNear, &viewPort, &proj, &view, &world );
  D3DXVec3Unproject( &worldFar, &screenFar, &viewPort, &proj, &view, &world );

  res.p0 = worldNear;
  res.u = worldFar - worldNear;
  D3DXVec3Normalize( &res.u, &res.u );

  return res;
}

/*** Funci�n: Dice si un rayo intercepta una esfera ***/
bool TestRaySphere( RAY ray, SPHERE sphere )
{
  D3DXVECTOR3 v = ray.p0 - sphere.center;
  float b       = 2.0f * D3DXVec3Dot( &(ray.u), &v );
  float c       = D3DXVec3Dot( &v, &v ) - sphere.radius * sphere.radius;

  // Discriminante
  float discriminant = (b * b) - (4.0f * c);
  if( discriminant < 0.0f )
    // Respuesta imaginaria( no intersecta )
    return false;

  discriminant = sqrtf( discriminant );
  
  // 2 respuestas
  float s0 = (-b + discriminant) / 2.0f;
  float s1 = (-b - discriminant) / 2.0f;
  
  // Verifico que alguna respuesta sea v�lida
  if( s0 >= 0.0f || s1 >= 0.0f )
    return true;
  else
    return false;
}

/*** Funci�n: Verifica si un punto est� dentro de una caja ***/
bool PointInsideBox( BOX b, D3DXVECTOR3 p )
{
  return( ( p.x >= b.min.x && p.x <= b.max.x ) &&
	  ( p.y >= b.min.y && p.y <= b.max.y ) &&
	  ( p.z >= b.min.z && p.z <= b.max.z ) );
}

/*** Funci�n: Crea un screenshot del estado del framebuffer actual ***/
void CreateScreenshot( IDirect3DDevice9* Device, char* appName )
{
  // Nomnre del archivo
  char   fileName[100];
  time_t actualTime;
  time( &actualTime );
  sprintf( fileName, "%s  %s.bmp", ctime( &actualTime ), appName );
  fileName[13] = '�'; fileName[16] = '�'; fileName[24] = ' '; fileName[25] = '-';
  // Superficie a guardar el screenshot
  IDirect3DSurface9* surface;
  // Dimensiones de la ventana //
  int cx = GetSystemMetrics(SM_CXSCREEN);
  int cy = GetSystemMetrics(SM_CYSCREEN);
  // Creo la superficie con el formato y tama�o adecuados
  Device->CreateOffscreenPlainSurface( cx, cy, D3DFMT_A8R8G8B8, D3DPOOL_SYSTEMMEM, &surface, NULL );
  // Obtengo el screenshot
  Device->GetFrontBufferData( 0, surface );
  // Lo guardo a un archivo
  D3DXSaveSurfaceToFile( fileName, D3DXIFF_BMP, surface, NULL, NULL );
  // Libero la superficie anteriormente usada
  surface->Release();
}
