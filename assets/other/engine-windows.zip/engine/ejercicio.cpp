#include "d3d.cpp"
#include "math.cpp"
#include "fonts.cpp"
#include "x.cpp"
#include "camera.cpp"
#include "terrain.cpp"
#include "pSystem.cpp"
#include "sprite.cpp"
#include "shader.cpp"
#include "shadow.cpp"
#include "xaudio.cpp"

/* Especificaciones */
#define WIDTH      1024
#define HEIGHT     768
#define FULLSCREEN true

IDirect3DDevice9* Device; // Interfaz global al dispositivo gr�fico

D3DCOLOR fontColor = D3DCOLOR_RGBA(255,255,255,255); // Color de la fuente
RECT     posText   = {0, 0, 100, 100};               // Posisici�n(cuadro) del texto
char     fpsText[10];                                // Texto para almacenar los FPS

D3DXMATRIX normalProj;     // Proyecci�n
CAMERA     camera;         // C�mara
float      vel = 20.0f;    // Velocidad de traslaci�n

TERRAIN      terrain;      // Terreno
D3DMATERIAL9 terrainMtrl;  // Material del Terreno
D3DLIGHT9    terrainLight; // Luz del terreno

// Effecto de sonido
XAUDIO2FX_REVERB_I3DL2_PARAMETERS effect = XAUDIO2FX_I3DL2_PRESET_DEFAULT;
// Sonido
X3DAUDIO_LISTENER listener;
SOUND fxSound;
MUSIC ambMusic;
bool  playSound = false;
bool  stopSound = false;
bool  playMusic = false;

/*** Inicializaci�n de recursos ***/
void Init( void )
{
  // Primero
  InitD3D( WIDTH, HEIGHT, FULLSCREEN, true, &Device );
  InitXAudio( effect );

  // Escondo el cursor del mouse
  ShowCursor( false );

  // Figuras s�lidas
  Device->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID );

  // Los tri�ngulos est�n en sentido horario
  // Descarto los pol�gonos mirando hacia atr�s en sentido anti-horario
  Device->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );

  // Habilito el Z-buffer
  Device->SetRenderState( D3DRS_ZENABLE, D3DZB_TRUE );
  // La funci�n de profundidad
  Device->SetRenderState( D3DRS_ZFUNC, D3DCMP_LESSEQUAL );

  // Habilito el uso de luces
  Device->SetRenderState( D3DRS_LIGHTING, true );
  // Suavizado para los colores de luz
  Device->SetRenderState( D3DRS_SHADEMODE, D3DSHADE_GOURAUD );
  // Normalizo los v�rtices normales
  Device->SetRenderState( D3DRS_NORMALIZENORMALS, true );
  // Habilito la luz especular
  Device->SetRenderState( D3DRS_SPECULARENABLE, true );
  // La luz especular es relativa a la c�mara
  Device->SetRenderState( D3DRS_LOCALVIEWER, true );
  // Luz ambiente global(Negro)
  Device->SetRenderState( D3DRS_AMBIENT, D3DCOLOR_RGBA(0,0,0,0) );

  // Especifico la forma de blending(transparencia)
  Device->SetRenderState( D3DRS_BLENDOP, D3DBLENDOP_ADD );
  Device->SetRenderState( D3DRS_SRCBLEND, D3DBLEND_SRCALPHA );
  Device->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );
  // Especifico el origen del canal alfa(material)
  Device->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE );
  Device->SetTextureStageState( 0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1 );
  // Especifico que pixeles pasan a hacer blending
  Device->SetRenderState( D3DRS_ALPHATESTENABLE, FALSE );
  Device->SetRenderState( D3DRS_ALPHAFUNC, D3DCMP_GREATER );
  Device->SetRenderState( D3DRS_ALPHAREF, 0 );

  // Filtros de texturas
  Device->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR ); // Magnifiaci�n
  Device->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR ); // Minificaci�n
  Device->SetSamplerState( 0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR ); // Mipmaps

  // Viewport
  D3DVIEWPORT9 viewport;
  viewport.X      = 0;
  viewport.Y      = 0;
  viewport.Width  = WIDTH;
  viewport.Height = HEIGHT;
  viewport.MinZ   = 0.0f;
  viewport.MaxZ   = 1.0f;
  Device->SetViewport( &viewport );

  // Proyecci�n normal
  D3DXMatrixPerspectiveFovLH( &normalProj,                   // Resultado
			      D3DX_PI / 4.0f,                // FOV
			      (float)WIDTH / (float) HEIGHT, // Aspecto
			      1.0f,                          // Plano cercano
			      1000.0f );                     // Plano LejanO

  // Fuente
  InitFont( "Times New Roman", Device );

  /* C�mara */
  camera.pos   = D3DXVECTOR3( 5.0f, 10.0f, -630.0f );
  camera.right = D3DXVECTOR3( 1.0f,  0.0f,    0.0f );
  camera.up    = D3DXVECTOR3( 0.0f,  1.0f,    0.0f );
  camera.look  = D3DXVECTOR3( 0.0f,  0.0f,    1.0f );

  /* Luz del terreno */
  ZeroMemory( &terrainLight, sizeof(D3DLIGHT9) );
  terrainLight.Type         = D3DLIGHT_DIRECTIONAL;
  terrainLight.Ambient      = PALE;
  terrainLight.Diffuse      = WHITE;
  terrainLight.Specular     = BLACK;
  terrainLight.Direction    = D3DXVECTOR3( 0.0f,  -1.0f,  0.0f );
  terrainLight.Position     = D3DXVECTOR3( 0.0f, 100.0f,  0.0f );
  terrainLight.Attenuation0 = 1.0f;
  terrainLight.Attenuation1 = 0.0f;
  terrainLight.Attenuation2 = 0.0f;
  terrainLight.Range        = 200.0f;

  
  /* Material del terreno */
  ZeroMemory( &terrainMtrl, sizeof(D3DMATERIAL9) );
  terrainMtrl.Ambient  = GRAY;
  terrainMtrl.Diffuse  = GRAY;
  terrainMtrl.Specular = BLACK;
  terrainMtrl.Emissive = BLACK;
  terrainMtrl.Power    = 0.0f;

  /* Terreno */
  InitTerrain( &terrain, "coastMountain64.raw", "desert.bmp", 64, 64, 10.0f, 1.0f, Device );

  /* Sonido */
  CreateSound( &fxSound, "explosion.ogg", false );

  /* M�sica */
  CreateMusic( &ambMusic, "sunday.ogg" );

  /* Listener */
  ZeroMemory( &listener, sizeof(X3DAUDIO_LISTENER) );
}

/*** Liberaci�n de recursos ***/
void Free( void )
{
  // Fuente
  FreeFont();

  // Libero el terreno
  FreeTerrain( &terrain );

  // Libero el sonido
  FreeSound( &fxSound );

  // Libero la m�sica
  FreeMusic( &ambMusic );
  
  // �ltimo
  FreeXAudio();
  FreeD3D( Device );
}

/*** Funci�n para evaluar lo introducido por el usuario ***/
void Input( float elapsed )
{
  // Nota:
  // 0x8000 = Key down - El bit m�s a la izq.(most significant) es 1
  // 0x0001 = Key up   - El bit m�s a la der.(less significant) es 1
  if( GetAsyncKeyState( VK_SNAPSHOT ) & 0x0001 )
    CreateScreenshot( Device, "Ejercicio" );
  if( GetAsyncKeyState( VK_LBUTTON ) & 0x0001 )
    playSound = true;
  if( GetAsyncKeyState( VK_RBUTTON ) & 0x0001 )
    stopSound = true;
  if( GetAsyncKeyState( 'M' ) & 0x0001 )
    {
      if( playMusic )
	{
	  playMusic = false;
	  StopMusic( &ambMusic );
	}
      else
	{
	  playMusic = true;
	  PlayMusic( &ambMusic, 1.0f, true );
	}
    }
  if( GetAsyncKeyState( VK_SPACE ) & 0x0001 )
    {
      fxSound.Position = camera.pos;
      fxSound.Velocity = D3DXVECTOR3( 0, 0, 0 );
    }

  if( GetAsyncKeyState( 'W' ) & 0x8000 )
    Walk( &camera, elapsed * vel, true );
  if( GetAsyncKeyState( 'S' ) & 0x8000 )
    Walk( &camera, elapsed * -vel, true );
  if( GetAsyncKeyState( 'D' ) & 0x8000 )
    Strafe( &camera, elapsed * vel, true );
  if( GetAsyncKeyState( 'A' ) & 0x8000 )
    Strafe( &camera, elapsed * -vel, true );

  // Altura de la c�mara = altura del terreno + altura persona
  camera.pos.y = GetHeight( &terrain, camera.pos.x, camera.pos.z ) + 5.0f;

  if( GetAsyncKeyState( VK_UP ) & 0x8000 )
    Pitch( &camera, elapsed );
  if( GetAsyncKeyState( VK_DOWN ) & 0x8000 )
    Pitch( &camera, -elapsed );
  if( GetAsyncKeyState( VK_RIGHT ) & 0x8000 )
    Yaw( &camera, elapsed, true );
  if( GetAsyncKeyState( VK_LEFT ) & 0x8000 )
    Yaw( &camera, -elapsed, true );
}

/*** Tareas de sonido para cada frame ***/
void Sound( float elapsed )
{
  /* Listener */
  listener.Position    = camera.pos;
  listener.Velocity    = D3DXVECTOR3( 0, 0, 0 );
  listener.OrientFront = camera.look;
  listener.OrientTop   = camera.up;

  /* Sound */
  SetSoundProperties( &fxSound, &listener );
  if( playSound )
    {
      PlaySound( &fxSound, 1.0f );
      playSound = false;
    }
  if( stopSound )
    {
      StopSound( &fxSound );
      stopSound = false;
    }

  /* M�sica */
  if( playMusic )
    StreamMusic( &ambMusic );
}

/*** Tareas de video para hacer en cada cuadro ***/
void Video( float elapsed )
{
  /* Proyecci�n */
  Device->SetTransform( D3DTS_PROJECTION, &normalProj );

  /* C�mara */
  D3DXVECTOR3 dir = camera.pos + camera.look;
  D3DXVECTOR3 up  = D3DXVECTOR3( 0.0f, 1.0f, 0.0f );
  D3DXMATRIX  cam;
  D3DXMatrixLookAtLH(&cam,
		     &camera.pos, // Posici�n
		     &dir,        // Direcci�n
		     &up );       // Arriba

  Device->SetTransform( D3DTS_VIEW, &cam );

  /* Limpio la pantalla */
  Device->Clear( 0,    // N�mero de rect�ngulos a borrar
		 NULL, // Puntero a rect�ngulos a borrar (NULL=toda la pantalla)
		 D3DCLEAR_TARGET  | 
		 D3DCLEAR_ZBUFFER |
		 D3DCLEAR_STENCIL,   // Borrar el Framebuffer y el z-buffer
		 (D3DCOLOR)BLACK,    // Framebuffer se borra con negro
		 1.0f,               // Z-buffer se borra con 1.0f
		 0 );                // Stencil-buffer se borra con 0
  
  // Habilito la luz
  Device->SetLight( 0, &terrainLight );
  Device->LightEnable( 0, true );

  // Dibujado
  Device->BeginScene();

  /* Terreno */
  RenderTerrain( &terrain, &terrainMtrl, Device );

  /* FPS */
  sprintf( fpsText, "%d fps", CalculateFPS( elapsed ) );
  RenderText( fpsText, &posText, fontColor );
  /*________*/

  Device->EndScene();

  /* Presento el Framebuffer */
  Device->Present( NULL, NULL, NULL, NULL ); // Todos los par�metros son NULL
}

/*** Loop ***/
void Loop( float elapsed )
{
  Input( elapsed );
  Sound( elapsed );
  Video( elapsed );
}
