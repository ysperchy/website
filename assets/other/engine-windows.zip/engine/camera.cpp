/*****************************/
/**       ------------      **/
/**        camera.cpp       **/
/**       ------------      **/
/**  Inicializaci�n y ren-  **/
/**  derizaci�n de modelos  **/
/*****************************/

/*** Estructura de datos: CAMERA ***/
typedef struct camera
{
  D3DXVECTOR3 pos;
  D3DXVECTOR3 right;
  D3DXVECTOR3 up;
  D3DXVECTOR3 look;
} CAMERA;
/*_______*/


/*** Funci�n: Movimiento lateral ***/
void Strafe( CAMERA* cam, float units, bool yLock )
{
  if( yLock )
    cam->pos += D3DXVECTOR3( cam->right.x, 0.0f, cam->right.z ) * units;
  else
    cam->pos += cam->right * units;
}

/*** Funci�n: Movimiento altitudinal ***/
void Fly( CAMERA* cam, float units )
{
  cam->pos += cam->up * units;
}

/*** Funci�n: Movimiento frontal ***/
void Walk( CAMERA* cam, float units, bool yLock )
{
  if( yLock )
    cam->pos += D3DXVECTOR3( cam->look.x, 0.0f, cam->look.z ) * units;
  else
    cam->pos += cam->look * units;
}

/*** Funci�n: Rotaci�n en el eje "derecha" ***/
void Pitch( CAMERA* cam, float units )
{
  D3DXMATRIX T;
  D3DXMatrixRotationAxis( &T, &cam->right, units );
  
  D3DXVec3TransformCoord( &cam->up, &cam->up, &T );
  D3DXVec3TransformCoord( &cam->look, &cam->look, &T );

  D3DXVec3Normalize( &cam->up, &cam->up );
  D3DXVec3Normalize( &cam->look, &cam->look );
}

/*** Funci�n: Rotaci�n en el eje "arriba" ***/
void Yaw( CAMERA* cam, float units, bool upYaw )
{
  D3DXMATRIX T;
  if( upYaw )
    D3DXMatrixRotationY( &T, units );
  else
    D3DXMatrixRotationAxis( &T, &cam->up, units );
  
  D3DXVec3TransformCoord( &cam->right, &cam->right, &T );
  D3DXVec3TransformCoord( &cam->look, &cam->look, &T );

  D3DXVec3Normalize( &cam->right, &cam->right );
  D3DXVec3Normalize( &cam->look, &cam->look );
}

/*** Funci�n: Rotaci�n en el eje "direcci�n" ***/
void Roll( CAMERA* cam, float units )
{
  D3DXMATRIX T;
  D3DXMatrixRotationAxis( &T, &cam->look, units );
  
  D3DXVec3TransformCoord( &cam->right, &cam->right, &T );
  D3DXVec3TransformCoord( &cam->up, &cam->up, &T );
  
  D3DXVec3Normalize( &cam->right, &cam->right );
  D3DXVec3Normalize( &cam->up, &cam->up );
}
