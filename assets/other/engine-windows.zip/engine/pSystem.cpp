/******************************/
/**        -----------       **/
/**        pSystem.cpp       **/
/**        -----------       **/
/** Creaci�n y renderizaci�n **/
/** de sistema de part�culas **/
/******************************/

//---   Estructuras   ---//

/*** Estructura de dato: POINT_COLOR***/
typedef struct point_color
{
  D3DXVECTOR3 pos;
  D3DCOLOR    color;
}POINT_COLOR;

DWORD PARTICLE_FVF = D3DFVF_XYZ | D3DFVF_DIFFUSE;

/*** Estructura de dato: PARTICLE ***/
typedef struct particle
{
  D3DXVECTOR3 pos;    // Posici�n
  D3DXVECTOR3 vel;    // Velocidad
  D3DXVECTOR3 acc;    // Aceleraci�n
  D3DXCOLOR   color;  // Color
  float       life;   // Tiempo de vida
  float       age;    // Edad(tiempo)
  bool        active; // Estado: viva?
}PARTICLE;

/*** Estructura de dato: PSYSTEM ***/
typedef struct pSystem
{
  unsigned int            numParticles; // N�mero de part�culas
  unsigned int            batch;        // Tama�o de bloques de part�culas
  float                   size;         // Tama�o de las part�culas
  IDirect3DTexture9*      texture;      // Textura de las part�culas
  IDirect3DVertexBuffer9* vb;           // Vertex Buffer
  PARTICLE*               particles;    // Arreglo de part�culas
  void*                   resetFunc;    // Funci�n que reinicia part�culas
  void*                   updateFunc;   // Funci�n que actualiza part�culas
}PSYSTEM;

typedef void ResetFunc( PSYSTEM*, PARTICLE* );
typedef void UpdateFunc( PSYSTEM*, PARTICLE*, float );

/*_______*/


//--- Funciones ---//

/*** Funci�n: Inicializa un sistema de partículas ***/
void InitPSystem( PSYSTEM* pSystem,
		  unsigned int      numParticles,
		  unsigned int      batch,
		  float             size,
		  char*             texture,
		  void              resetFunc( PSYSTEM*, PARTICLE* ),
		  void              updateFunc( PSYSTEM*, PARTICLE*, float ),
		  IDirect3DDevice9* Device )
{
  // Guardo los datos del sistema de part�culas
  pSystem->numParticles = numParticles;
  pSystem->batch        = batch;
  pSystem->size         = size;
  pSystem->resetFunc    = resetFunc;
  pSystem->updateFunc   = updateFunc;
  
  // Cargo la textura
  D3DXCreateTextureFromFile( Device, texture, &pSystem->texture );
  
  // Reservo memoria para las part�culas
  pSystem->particles = (PARTICLE*)calloc( numParticles, sizeof(PARTICLE) );
  
  // Creo el vertex buffer para renderizar las part�culas
  Device->CreateVertexBuffer( batch * sizeof(POINT_COLOR),
			      D3DUSAGE_DYNAMIC | D3DUSAGE_POINTS | D3DUSAGE_WRITEONLY,
			      PARTICLE_FVF,
			      D3DPOOL_DEFAULT,
			      &pSystem->vb,
			      NULL );
}

/*** Funci�n: Actualiza las caracter�sticas de las part�culas ***/
void UpdatePSystem( PSYSTEM* pSystem, float elapsed )
{
  // Actualizo todas las part�culas
  unsigned int i;
  for( i = 0; i < pSystem->numParticles; i++ )
    ((UpdateFunc*)pSystem->updateFunc)( pSystem, &(pSystem->particles[i]), elapsed );
}

/*** Funci�: Resetea las caracter�sticas de las part�culas ***/
void ResetPSystem( PSYSTEM* pSystem )
{
  // Reseteo todas las part�culas
  unsigned int i;
  for( i = 0; i < pSystem->numParticles; i++ )
    ((ResetFunc*)pSystem->resetFunc)( pSystem, &(pSystem->particles[i]) );
}

/*** Funci�n: Renderiza el sistema de part�culas ***/
void RenderPSystem( PSYSTEM* pSystem, IDirect3DDevice9* Device )
{
  // Pre-renderizado
  Device->SetRenderState( D3DRS_LIGHTING, false );
  Device->SetRenderState( D3DRS_POINTSPRITEENABLE, true );
  Device->SetRenderState( D3DRS_POINTSCALEENABLE, true );
  Device->SetRenderState( D3DRS_POINTSIZE, FtoD(pSystem->size) );
  Device->SetRenderState( D3DRS_POINTSIZE_MIN, FtoD(1.0f) );
  Device->SetRenderState( D3DRS_POINTSCALE_A, FtoD(0.0f) );
  Device->SetRenderState( D3DRS_POINTSCALE_B, FtoD(0.0f) );
  Device->SetRenderState( D3DRS_POINTSCALE_C, FtoD(1.0f) );
  // Alpha
  Device->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
  Device->SetTextureStageState( 0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1 );
  Device->SetRenderState( D3DRS_ALPHABLENDENABLE, true );
  Device->SetRenderState( D3DRS_SRCBLEND, D3DBLEND_SRCALPHA );
  Device->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );
  // Tetxura y buffers
  Device->SetTexture( 0, pSystem->texture );
  Device->SetFVF( PARTICLE_FVF );
  Device->SetStreamSource( 0, pSystem->vb, 0, sizeof(POINT_COLOR) );
    
  // Renderizado
  POINT_COLOR* buffer;
  pSystem->vb->Lock( 0, 0, (void**)&buffer, D3DLOCK_DISCARD );
  unsigned int i, j = 0;
  // Renderizo por bloques(batch)
  for( i = 0; i <= pSystem->numParticles; i++ )
    {
      // Verifico que el bloque est� completo
      if( j == pSystem->batch || i == pSystem->numParticles )
	{
	  // Dibujo las part�culas
	  pSystem->vb->Unlock();
	  Device->DrawPrimitive( D3DPT_POINTLIST, 0, j );
	  // Reinicio el Batch
	  j = 0; 
	  // La part�cula actual debe ser procesada
	  if( i != pSystem->numParticles )
	    {
	      pSystem->vb->Lock( 0, 0, (void**)&buffer, D3DLOCK_DISCARD );
	      i--;
	    }
	  continue;
	}
      
      // Verifico que la part�cula est� activa
      if( pSystem->particles[i].active )
	{
	  // La copio a los bufferes
	  buffer[j].pos   = pSystem->particles[i].pos;
	  buffer[j].color = (D3DCOLOR)pSystem->particles[i].color;
	  j++;
	}
    }

  //Post-renderizado
  Device->SetRenderState( D3DRS_LIGHTING, true );
  Device->SetRenderState( D3DRS_POINTSPRITEENABLE, false );
  Device->SetRenderState( D3DRS_POINTSCALEENABLE, false );
  Device->SetRenderState( D3DRS_ALPHABLENDENABLE, false );
  Device->SetTexture( 0, NULL );
}

/*** Funci�n: Libera los recursos asocidados un sistema de part�culas ***/
void FreePSystem( PSYSTEM* pSystem )
{
  pSystem->texture->Release();
  pSystem->vb->Release();
  free( pSystem->particles );
}
