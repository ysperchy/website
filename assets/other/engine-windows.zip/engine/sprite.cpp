/********************************/
/**       --------------       **/
/**         sprite.cpp         **/
/**       --------------       **/
/**  Interfaz para renderizar  **/
/**  elementos HUD en D3D      **/
/********************************/

/*** Interfaz para el uso de sprites ***/
ID3DXSprite* HUD = NULL;


/*** Funci�n: Inica la interfaz HUD ***/
void InitHUD( IDirect3DDevice9* Device )
{
  D3DXCreateSprite( Device, &HUD );
}

/*** Funci�n: Termina la interfaz HUD ***/
void FreeHUD()
{
  HUD->Release();
}


//*****
// Las siguientes funciones deben ser
// llamadas dentro de un bloque:
// Device->BeginScene();
// ...
// Device->EndScene();
//*****

/*** Funci�n: Inicia el modo 2D ***/

void Begin2D()
{
  HUD->Begin( D3DXSPRITE_ALPHABLEND );
}

/*** Funci�n: Renderiza una textura en modo HUD ***/
void Render2DTexture( IDirect3DTexture9* tex,
		      unsigned int xi, unsigned int yi,
		      unsigned int xf, unsigned int yf )
// tex: Textura
// xi, yi: Ubicaci�n esquina izquierda superior
// xf, yf: Ubicaci�n esquina derecha inferior
{
  // Escalamiento
  D3DSURFACE_DESC texDesc;
  D3DXMATRIX scaleMatrix;
  tex->GetLevelDesc( 0, &texDesc );
  D3DXMatrixScaling( &scaleMatrix,
		     (float)(xf - xi) / (float)texDesc.Width,
		     (float)(yf - yi) / (float)texDesc.Height,
		      1.0f );
  HUD->SetTransform( &scaleMatrix );

  // Dibujado
  HUD->Draw( tex, NULL, NULL,
	     &D3DXVECTOR3( float(xi), float(yi), 0.0f ),
	     0xFFFFFFFF );
}

/*** Funci�n: Termina el modo 2D ***/
void End2D()
{
  HUD->End();
}
