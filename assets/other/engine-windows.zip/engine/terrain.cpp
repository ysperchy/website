/***************************/
/**      -----------      **/
/**       terrain.c       **/
/**      -----------      **/
/**  Creaci�n y rende-    **/
/**  rizaci�n de terrenos **/
/***************************/

/*** Estructura de Datos: TERRIAN ***/
typedef struct terrain
{
  unsigned char*          heightMap;
  unsigned int            vertsPerRow;
  unsigned int            vertsPerCol;
  float                   cellSpacing;
  IDirect3DIndexBuffer9*  indexBuffer;
  IDirect3DVertexBuffer9* vertexBuffer;
  IDirect3DTexture9*      texture;
} TERRAIN;
/*________*/


/*** Funci�n: Inicializa un terreno ***/
void InitTerrain( TERRAIN*          terrain,
		  char*             terrainFile,
		  char*             terrainTexture,
		  unsigned int      vertsPerRow,
		  unsigned int      vertsPerCol,
		  float             cellSpacing,
		  float             heightScale,
		  IDirect3DDevice9* Device )
{
  /* Caracter�sticas */
  terrain->vertsPerRow = vertsPerRow;
  terrain->vertsPerCol = vertsPerCol;
  terrain->cellSpacing = cellSpacing;

  /* Memoria para el heightMap */
  terrain->heightMap = (unsigned char*)calloc( vertsPerRow * vertsPerCol,
					       sizeof(unsigned char) );

  /* Leo el heightMap */
  FILE* file = fopen( terrainFile, "r" );
  fread( terrain->heightMap, sizeof(unsigned char), vertsPerRow * vertsPerCol, file );
  fclose( file );

  /* Escalo el heightmap */
  unsigned int h;
  for( h = 0; h < vertsPerRow * vertsPerCol; h++ )
    terrain->heightMap[h] *= heightScale;


  /* Calculo los v�rtices */
  Device->CreateVertexBuffer( vertsPerRow * vertsPerCol * sizeof(NORMAL_TEX_VERTEX),
			      NULL,
			      FVF,                    // S�lo contienen coordenadas xyz, uv, normales
			      D3DPOOL_MANAGED,        // Memoria de sistema(copia) y video
			      &terrain->vertexBuffer, // OUT
			      NULL );                 // NULL

  float uTexDelta = 1.0f / (vertsPerRow - 1);
  float vTexDelta = 1.0f / (vertsPerCol - 1);
  
  NORMAL_TEX_VERTEX* vertex;
  terrain->vertexBuffer->Lock( 0,               // Offset
			       0,               // Tama�o(0 para todo)
			       (void**)&vertex, // OUT
			       NULL );          // Flags

  unsigned int i, j;
  for( i = 0; i < vertsPerCol; i++ )
    {
      for(  j = 0; j < vertsPerRow; j++ )
	{
	  NORMAL_TEX_VERTEX v;
	  v.x  = j * cellSpacing;
	  v.y  = terrain->heightMap[ (i * vertsPerRow) + j ];
	  v.z  = -(i * cellSpacing);
	  v.nx = 0.0f;
	  v.ny = 0.0f;
	  v.nz = 0.0f;
	  v.u  = j * uTexDelta;
	  v.v  = i * vTexDelta;
	  vertex[ (i * vertsPerRow) + j ] = v;
	}
    }
  
  /* Calculo las normales */
  for( i = 0; i < vertsPerCol - 1; i++ )
    {
      for( j = 0; j < vertsPerRow - 1; j++ )
	{
	  /*
	    A---B
	    |  /|
	    | / |
	    |/  |
	    C---D
	  */
	  D3DXVECTOR3 n;
	  D3DXVECTOR3 A, B, C;
	  
	  A = D3DXVECTOR3(vertex[ ((i + 0) * vertsPerRow) + (j + 0) ].x,
			  vertex[ ((i + 0) * vertsPerRow) + (j + 0) ].y,
			  vertex[ ((i + 0) * vertsPerRow) + (j + 0) ].z );

	  B = D3DXVECTOR3(vertex[ ((i + 0) * vertsPerRow) + (j + 1) ].x,
			  vertex[ ((i + 0) * vertsPerRow) + (j + 1) ].y,
			  vertex[ ((i + 0) * vertsPerRow) + (j + 1) ].z );

	  C = D3DXVECTOR3(vertex[ ((i + 1) * vertsPerRow) + (j + 0) ].x,
			  vertex[ ((i + 1) * vertsPerRow) + (j + 0) ].y,
			  vertex[ ((i + 1) * vertsPerRow) + (j + 0) ].z );
	  
	  D3DXVECTOR3 v1 = B - A;
	  D3DXVECTOR3 v2 = C - A;
	  
	  D3DXVec3Cross( &n, &v1, &v2 );
	  D3DXVec3Normalize( &n, &n );
	  vertex[ (i * vertsPerRow) + j ].nx = n.x;
	  vertex[ (i * vertsPerRow) + j ].ny = n.y;
	  vertex[ (i * vertsPerRow) + j ].nz = n.z;
	}
    }
  
  // �ltima fila
  for( j = 0; j < vertsPerRow - 1; j++ )
    {
      /*
	A---B
	|  /|
	| / |
	|/  |
	C---D
      */
      D3DXVECTOR3 n;
      D3DXVECTOR3 C, A, B;
      
      C = D3DXVECTOR3( vertex[ (vertsPerCol - 1) * vertsPerRow + j + 0 ].x,
		       vertex[ (vertsPerCol - 1) * vertsPerRow + j + 0 ].y,
		       vertex[ (vertsPerCol - 1) * vertsPerRow + j + 0 ].z );

      A = D3DXVECTOR3( vertex[ (vertsPerCol - 2) * vertsPerRow + j + 0 ].x,
		       vertex[ (vertsPerCol - 2) * vertsPerRow + j + 0 ].y,
		       vertex[ (vertsPerCol - 2) * vertsPerRow + j + 0 ].z );

      B = D3DXVECTOR3( vertex[ (vertsPerCol - 2) * vertsPerRow + j + 1 ].x,
		       vertex[ (vertsPerCol - 2) * vertsPerRow + j + 1 ].y,
		       vertex[ (vertsPerCol - 2) * vertsPerRow + j + 1 ].z );
      
      D3DXVECTOR3 v1 = A - C;
      D3DXVECTOR3 v2 = B - C;
      
      D3DXVec3Cross( &n, &v1, &v2 ); 
      D3DXVec3Normalize( &n, &n );
      vertex[ (vertsPerCol - 1) * vertsPerRow + j ].nx = n.x;
      vertex[ (vertsPerCol - 1) * vertsPerRow + j ].ny = n.y;
      vertex[ (vertsPerCol - 1) * vertsPerRow + j ].nz = n.z;
    }
  
  // �ltima columna
  for( i = 0; i < vertsPerCol - 1; i++ )
    {
      /*
	A---B
	|  /|
	| / |
	|/  |
	C---D
      */
      D3DXVECTOR3 n;
      D3DXVECTOR3 B, D, C;
      
      B = D3DXVECTOR3( vertex[ (vertsPerRow * (i + 0)) + (vertsPerCol - 1) ].x,
		       vertex[ (vertsPerRow * (i + 0)) + (vertsPerCol - 1) ].y,
		       vertex[ (vertsPerRow * (i + 0)) + (vertsPerCol - 1) ].z );
		      
      D = D3DXVECTOR3( vertex[ (vertsPerRow * (i + 1)) + (vertsPerCol - 1) ].x,
		       vertex[ (vertsPerRow * (i + 1)) + (vertsPerCol - 1) ].y,
		       vertex[ (vertsPerRow * (i + 1)) + (vertsPerCol - 1) ].z );

      C = D3DXVECTOR3( vertex[ (vertsPerRow * (i + 1)) + (vertsPerCol - 2) ].x,
		       vertex[ (vertsPerRow * (i + 1)) + (vertsPerCol - 2) ].y,
		       vertex[ (vertsPerRow * (i + 1)) + (vertsPerCol - 2) ].z );
      
      D3DXVECTOR3 v1 = D - B;
      D3DXVECTOR3 v2 = C - B;
      
      D3DXVec3Cross( &n, &v1, &v2 ); 
      D3DXVec3Normalize( &n, &n );
      vertex[ (vertsPerRow * (i + 0)) + (vertsPerCol - 1) ].nx = n.x;
      vertex[ (vertsPerRow * (i + 0)) + (vertsPerCol - 1) ].ny = n.y;
      vertex[ (vertsPerRow * (i + 0)) + (vertsPerCol - 1) ].nz = n.z;
    }
  
  // Normal: extrema derecha inferior
  {
    /*
      A---B
      |  /|
      | / |
      |/  |
      C---D
    */
    D3DXVECTOR3 n;
    D3DXVECTOR3 D, B, C;
    
    D = D3DXVECTOR3( vertex[ (vertsPerCol - 1) * vertsPerRow + vertsPerRow - 1 ].x,
		     vertex[ (vertsPerCol - 1) * vertsPerRow + vertsPerRow - 1 ].y,
		     vertex[ (vertsPerCol - 1) * vertsPerRow + vertsPerRow - 1 ].z );

    B = D3DXVECTOR3( vertex[ (vertsPerCol - 2) * vertsPerRow + vertsPerRow - 1 ].x,
		     vertex[ (vertsPerCol - 2) * vertsPerRow + vertsPerRow - 1 ].y,
		     vertex[ (vertsPerCol - 2) * vertsPerRow + vertsPerRow - 1 ].z );

    C = D3DXVECTOR3( vertex[ (vertsPerCol - 1) * vertsPerRow + vertsPerRow - 2 ].x,
		     vertex[ (vertsPerCol - 1) * vertsPerRow + vertsPerRow - 2 ].y,
		     vertex[ (vertsPerCol - 1) * vertsPerRow + vertsPerRow - 2 ].z );
    
    D3DXVECTOR3 v1 = C - D;
    D3DXVECTOR3 v2 = B - D;
    
    D3DXVec3Cross( &n, &v1, &v2 ); 
    D3DXVec3Normalize( &n, &n );
    vertex[ (vertsPerCol - 1) * vertsPerRow + vertsPerRow - 1 ].nx = n.x;
    vertex[ (vertsPerCol - 1) * vertsPerRow + vertsPerRow - 1 ].ny = n.y;
    vertex[ (vertsPerCol - 1) * vertsPerRow + vertsPerRow - 1 ].nz = n.z;
  }
  
  terrain->vertexBuffer->Unlock();

  /* �ndices */
  Device->CreateIndexBuffer( (vertsPerRow - 1) * (vertsPerCol - 1) * 2 * 3 * sizeof(WORD),
			     D3DUSAGE_WRITEONLY,    // Est�tico, s�lo escritura,
			     D3DFMT_INDEX16,        // �ndices de 16bits(2 bytes - int)
			     D3DPOOL_MANAGED,       // Memoria de sistema(copia) y video
			     &terrain->indexBuffer, // OUT
			     NULL );

  WORD* indices = NULL;
  terrain->indexBuffer->Lock( 0,                // Offset
			      0,                // Tama�o(0 para todo)
			      (void**)&indices, // OUT
			      NULL );           // Flags

  for( i = 0; i < vertsPerCol - 1; i++ )
    {
      for( j = 0; j < vertsPerRow - 1; j++ )
	{
	  /*
	    A---B
	    |  /|
	    | / |
	    |/  |
	    C---D
	  */
	  unsigned int base = (i * (vertsPerRow - 1) + j) * 2 * 3;
	  // Tri�ngulo 1(ABC)
	  indices[ base + 0 ] = ((i + 0) * vertsPerRow + j) + 0;
	  indices[ base + 1 ] = ((i + 0) * vertsPerRow + j) + 1;
	  indices[ base + 2 ] = ((i + 1) * vertsPerRow + j) + 0;
	  // Tri�ngulo 2(BDC)
	  indices[ base + 3 ] = ((i + 0) * vertsPerRow + j) + 1;
	  indices[ base + 4 ] = ((i + 1) * vertsPerRow + j) + 1;
	  indices[ base + 5 ] = ((i + 1) * vertsPerRow + j) + 0;
	}
    }

  terrain->indexBuffer->Unlock();

  /* Coloreado del Terreno */
  if( terrainTexture != NULL )
    // Cargo la Textura
    D3DXCreateTextureFromFile( Device,
			       terrainTexture,
			       &terrain->texture );
  else
    // Creo la textura
    {
      D3DXCreateTexture( Device,
			 vertsPerRow,        // Ancho(Width)
			 vertsPerCol,        // Largo(Height)
			 D3DX_DEFAULT,       // Mipmap
			 0,                  // Uso
			 D3DFMT_X8R8G8B8,    // Formato
			 D3DPOOL_MANAGED,    // Memoria �ptima
			 &terrain->texture );

      D3DLOCKED_RECT textureData;
      terrain->texture->LockRect( 0,            // Nivel de textura
				  &textureData, // Puntero a los datos
				  NULL,         // Toda la texura
				  0 );          // Flags
      DWORD* pixels = (DWORD*)textureData.pBits;

      for( i = 0; i < vertsPerCol; i++ )
	{
	  for( j = 0; j < vertsPerRow; j++ )
	    {
	      float height = (float)terrain->heightMap[ (i * vertsPerRow) + j ];
	      D3DXCOLOR c;
	      if( height < 42.5f )
		{
		  c = BEACH_SAND;
		}
	      else if( height < 85.0f )
		{
		  c = LIGHT_YELLOW_GREEN;
		}
	      else if( height < 127.5f )
		{
		  c = PUREGREEN;
		}
	      else if( height < 170.0f )
		{
		  c = DARK_YELLOW_GREEN;
		}
	      else if( height < 212.5f )
		{
		  c = DARKBROWN;
		}
	      else
		{
		  c = WHITE;
		}
	      // Pongo el color en DWORD
	      pixels[ (i * vertsPerRow + j) ] = (D3DCOLOR)c;
	    }
	}
      terrain->texture->UnlockRect( 0 );

      // Filtro la textura
      D3DXFilterTexture( terrain->texture,
			 NULL,           // Sin paleta de colores
			 D3DX_DEFAULT,   // Source es el nivel 0
			 D3DX_DEFAULT ); // Est�ndar mipmaps

      // Guardo la textura
      // D3DXSaveTextureToFile( "terrainTex.png", D3DXIFF_PNG, terrain->texture, NULL );
    }
}

/*** Funci�n: Libera los recursos asociados a un terreno ***/
void FreeTerrain( TERRAIN* terrain )
{
  free( terrain->heightMap );
  terrain->vertexBuffer->Release();
  terrain->indexBuffer->Release();
  terrain->texture->Release();
}

/*** Funci�n: Renderiza el terreno ***/
void RenderTerrain( TERRAIN* terrain, D3DMATERIAL9* terrainMtrl, IDirect3DDevice9* Device )
{
  // Ato el buffer de v�rtices
  Device->SetStreamSource( 0,                           // S�lo 1 stream
			   terrain->vertexBuffer,       // El buffer
			   0,                           // Offset
			   sizeof(NORMAL_TEX_VERTEX) ); // Tama�o de los v�rtice
  Device->SetFVF( FVF ); // FVF
  
  // Clamp(evita bordes raros en el mapeado de la textura)
  Device->SetSamplerState( 0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP );
  Device->SetSamplerState( 0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP );

  Device->SetIndices( terrain->indexBuffer ); // �ndices
  Device->SetMaterial( terrainMtrl );         // Material
  Device->SetTexture( 0, terrain->texture );  // Textura

   // Dibujo
  Device->DrawIndexedPrimitive( D3DPT_TRIANGLELIST,               // Indices de tri�ngulos
				0,                                // Base de la ubicaci�n de los v�rtices(0)
				0,                                // �ndices m�nimo(0)
				terrain->vertsPerRow *
				terrain->vertsPerCol,             // N�mero de v�rtices en el vertex buffer
				0,                                // Offset de los �ndices
				(terrain->vertsPerRow - 1) * 
				(terrain->vertsPerCol - 1) * 2 ); // N�mero de primitivas(tri�ngulos) a dibujar
}

/*** Funci�n: Obtener altura con una coordenada(XZ) ***/
float GetHeight( TERRAIN* terrain, float x, float z )
{
  x = abs( x / terrain->cellSpacing );
  z = abs( z / terrain->cellSpacing );

  /* Coordenadas del cuadro */
  unsigned int row = floorf(x);
  unsigned int col = floorf(z);

  /*
    A---B
    |1 /|
    | / |
    |/ 2|
    C---D
  */
  float A = terrain->heightMap[ ((col + 0) * terrain->vertsPerRow) + (row + 0) ];
  float B = terrain->heightMap[ ((col + 0) * terrain->vertsPerRow) + (row + 1) ];
  float C = terrain->heightMap[ ((col + 1) * terrain->vertsPerRow) + (row + 0) ];
  float D = terrain->heightMap[ ((col + 1) * terrain->vertsPerRow) + (row + 1) ];
    
  float height = 0.0f;
  float dx     = x - row;
  float dz     = z - col;

  /* Tri�ngulo 1 */
  if( dx + dz < 1.0f )
    {
      float Hz = (C - A)*dz;
      float Hx = (B - A)*dx;
      height   = A + Hx + Hz;
    }
  /* Tri�ngulo 2 */
  else
    {
      float Hz = (B - D)*(1.0f - dz);
      float Hx = (C - D)*(1.0f - dx);
      height   = D + Hx + Hz;
    }
    
  return height;
}
