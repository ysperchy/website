/********************************/
/**       --------------       **/
/**         xaudio.cpp         **/
/**       --------------       **/
/** Interfaz para reproducir   **/
/** m�sica y espacializar son- **/
/** idos ambientales           **/
/********************************/
#define INPUTCHANNELS  1
#define OUTPUTCHANNELS 8
#define BUFFERSIZE     64*1024 // 64Kb
#define NUMBUFFERS     8

/*** Estructura: AUDIO_DEVICE ***/
typedef struct audio_device
{
  IXAudio2*               XAudio2;
  IXAudio2MasteringVoice* MasteringVoice;
  IXAudio2SubmixVoice*    SubmixVoice;
  IUnknown*               ReverbEffect;
  X3DAUDIO_HANDLE         X3DInstance;
  XAUDIO2_DEVICE_DETAILS  Details;
} AUDIO_DEVICE;
/*________*/

/*** Estructura: SOUND ***/
typedef struct sound
{
  IXAudio2SourceVoice* SourceVoice;
  XAUDIO2_BUFFER       SoundBuffer;
  X3DAUDIO_VECTOR      Position;
  X3DAUDIO_VECTOR      Velocity;
} SOUND;
/*________*/

/*** Estructura: MUSIC ***/
typedef struct music
{
  OggVorbis_File       OggFile;
  WAVEFORMATEX         MusicFormat;
  IXAudio2SourceVoice* SourceVoice;
  XAUDIO2_BUFFER       MusicBuffers[NUMBUFFERS];
  unsigned int         CurrentBuffer;
  bool                 Loop;
} MUSIC;
/*_______*/


/// Dispositivo de Audio ///
AUDIO_DEVICE AudioDevice;
  
/*** Funci�n: Inicializa el sistema de sonido ***/
// effect = XAUDIO2FX_I3DL2_PRESET_DEFAULT
//          diferentes effectos pueden ser encontrados
//          en la documentaci�n de DirectX
bool InitXAudio( XAUDIO2FX_REVERB_I3DL2_PARAMETERS effect )
{
  // Inicializaci�n
  ZeroMemory( &AudioDevice, sizeof(AUDIO_DEVICE) );
  CoInitializeEx( NULL, COINIT_MULTITHREADED );
 
  HRESULT hr;

  /// Inicializaci�n XAudio2
  hr = XAudio2Create( &AudioDevice.XAudio2, NULL );
  if( hr != S_OK )
    return false;

  // Creo una voz maestra
  hr = AudioDevice.XAudio2->CreateMasteringVoice( &AudioDevice.MasteringVoice );
  if( hr != S_OK )
    {
      AudioDevice.XAudio2->Release();
      return false;
    }

  // Obtengo los detalles del dispositivo y chequeo capacidades
  AudioDevice.XAudio2->GetDeviceDetails( 0, &AudioDevice.Details );
  if( AudioDevice.Details.OutputFormat.Format.nChannels > OUTPUTCHANNELS )
    {
      AudioDevice.XAudio2->Release();
      return false;
    }

  // Creo el efecto de reverberaci�n
  hr = XAudio2CreateReverb( &AudioDevice.ReverbEffect, NULL );
  if( hr != S_OK )
    {
      AudioDevice.XAudio2->Release();
      return false;
    }

  // Creo la 'submix voice'
  const XAUDIO2_EFFECT_DESCRIPTOR effects[] = { { AudioDevice.ReverbEffect, TRUE, 1 } };
  const XAUDIO2_EFFECT_CHAIN      effectChain = { 1, effects };
  hr = AudioDevice.XAudio2->CreateSubmixVoice( &AudioDevice.SubmixVoice, 1,
					       AudioDevice.Details.OutputFormat.Format.nSamplesPerSec,
					       0, 0, NULL, &effectChain );
  if( hr != S_OK )
    {
      AudioDevice.XAudio2->Release();
      AudioDevice.ReverbEffect->Release();
      return false;
    }
  
  // Pongo el efecto aplicado a los sonidos reproducidos
  XAUDIO2FX_REVERB_PARAMETERS native;
  ReverbConvertI3DL2ToNative( &effect, &native );
  AudioDevice.SubmixVoice->SetEffectParameters( 0, &native, sizeof(XAUDIO2FX_REVERB_PARAMETERS) );

  // Inicializaci�n de X3DAudio
  X3DAudioInitialize( AudioDevice.Details.OutputFormat.dwChannelMask,
		      X3DAUDIO_SPEED_OF_SOUND,
		      AudioDevice.X3DInstance );

  AudioDevice.XAudio2->StartEngine();
  return true;
}

/*** Funci�n: Libera el dispositivo de audio ***/
void FreeXAudio( void )
{
  AudioDevice.XAudio2->StopEngine();
  AudioDevice.SubmixVoice->DestroyVoice();
  AudioDevice.MasteringVoice->DestroyVoice();
  AudioDevice.XAudio2->StopEngine();
  AudioDevice.ReverbEffect->Release();
  AudioDevice.XAudio2->Release();
  CoUninitialize();
}

/*** Funci�n: Crea un sonido(OGG) ***/
void CreateSound( SOUND* sound, char* soundFile, bool loop )
{
  // Abro el archivo ogg
  WAVEFORMATEX format;
  OggVorbis_File oggFile;
  vorbis_info* info;
  FILE* file;
  file = fopen( soundFile, "rb" );
  ov_open( file, &oggFile, NULL, 0 );

  // Saco la informaci�n
  info = ov_info( &oggFile, -1 );
  ZeroMemory( &format, sizeof(WAVEFORMATEX) );
  format.wFormatTag      = WAVE_FORMAT_PCM;
  format.nChannels       = info->channels;
  format.nSamplesPerSec  = info->rate;
  format.nAvgBytesPerSec = info->rate * (info->channels * 16) / 8;
  format.nBlockAlign     = (info->channels * 16) / 8;
  format.wBitsPerSample  = 16;
  format.cbSize          = NULL;

  // Copio el sonido y pongo sus propiedades
  ZeroMemory( &sound->SoundBuffer, sizeof(XAUDIO2_BUFFER) );
  int bitStream;
  int nBuffer = 0;
  char buffer[BUFFERSIZE];
  long int bytesRead  = 0;
  long int totalBytes = 0;
  do {
    // Leo el archivo ogg
    bytesRead = ov_read( &oggFile,
			 buffer,
			 BUFFERSIZE,
			 0, 2, 1,
			 &bitStream );
    // Copio la informaci�n leida al buffer
    sound->SoundBuffer.pAudioData = (BYTE*)realloc( (void*)sound->SoundBuffer.pAudioData,
						    totalBytes + bytesRead );
    memcpy( (void*)&(sound->SoundBuffer.pAudioData[totalBytes]),
		    buffer, bytesRead );
    // Actualizo los datos de control
    totalBytes += bytesRead;
    nBuffer++;
  }while( bytesRead != 0 );

  // Propiedades del sonido
  sound->SoundBuffer.Flags      = XAUDIO2_END_OF_STREAM;
  sound->SoundBuffer.AudioBytes = totalBytes;
  sound->SoundBuffer.PlayBegin  = 0;
  sound->SoundBuffer.PlayLength = 0;
  if( loop )
    {
      sound->SoundBuffer.LoopBegin  = 0;
      sound->SoundBuffer.LoopLength = 0;
      sound->SoundBuffer.LoopCount  = XAUDIO2_LOOP_INFINITE;
    }
  else
    {
       sound->SoundBuffer.LoopBegin  = XAUDIO2_NO_LOOP_REGION;
       sound->SoundBuffer.LoopLength = 0;
       sound->SoundBuffer.LoopCount  = 0;
    }
  ov_clear( &oggFile );

  // Source Voice
  const IXAudio2Voice* voices[]      = { AudioDevice.MasteringVoice, AudioDevice.SubmixVoice };
  const XAUDIO2_VOICE_SENDS sendList = { 2, (IXAudio2Voice**)voices };
  AudioDevice.XAudio2->CreateSourceVoice( &sound->SourceVoice, &format,
					  NULL, XAUDIO2_DEFAULT_FREQ_RATIO,
					  NULL, &sendList, NULL );
}

/*** Funci�n: Libera un sonido ***/
void FreeSound( SOUND* sound )
{
  sound->SourceVoice->DestroyVoice();
  free( (void*)sound->SoundBuffer.pAudioData );
}

/*** Funcion: Propiedades espaciales del sonido ***/
void SetSoundProperties( SOUND* sound, X3DAUDIO_LISTENER* listener )
{
  X3DAUDIO_EMITTER emitter;
  FLOAT32 mc[INPUTCHANNELS * OUTPUTCHANNELS];
  X3DAUDIO_DSP_SETTINGS dspSettings;
  ZeroMemory( &emitter , sizeof(X3DAUDIO_EMITTER) );

  // Propiedades del emisor
  emitter.Position            = sound->Position;
  emitter.Velocity            = sound->Velocity;
  emitter.OrientFront         = D3DXVECTOR3( 0, 0, 1 );
  emitter.OrientTop           = D3DXVECTOR3( 0, 1, 0 );
  emitter.ChannelCount        = INPUTCHANNELS;
  emitter.ChannelRadius       = 1.0f;
  emitter.DopplerScaler       = 1.0f;
  emitter.pVolumeCurve        = NULL; //<--- Atenuaci�n con respecto a la distancia
  emitter.CurveDistanceScaler = 1.0f;
  // Cono del emisor
  X3DAUDIO_CONE emitterCone;
  emitterCone.InnerAngle  = 0.0f; // Inner = X3DAUDIO_2PI || Outer != 0 --> (point emitter)
  emitterCone.OuterAngle  = 0.0f; // Outer = 0 ---> (point emitter)
  emitterCone.InnerVolume = 0.0f;
  emitterCone.OuterVolume = 1.0f;
  emitterCone.InnerLPF    = 0.0f;
  emitterCone.OuterLPF    = 1.0f;
  emitterCone.InnerReverb = 0.0f;
  emitterCone.OuterReverb = 1.0f;
  emitter.pCone           = &emitterCone;


  // Calculo la incidencia 3D
  dspSettings.SrcChannelCount     = INPUTCHANNELS;
  dspSettings.DstChannelCount     = AudioDevice.Details.OutputFormat.Format.nChannels;
  dspSettings.pMatrixCoefficients = mc;

  X3DAudioCalculate( AudioDevice.X3DInstance, listener, &emitter,
		     X3DAUDIO_CALCULATE_MATRIX     | X3DAUDIO_CALCULATE_DOPPLER    |
		     X3DAUDIO_CALCULATE_LPF_DIRECT | X3DAUDIO_CALCULATE_LPF_REVERB |
		     X3DAUDIO_CALCULATE_REVERB, &dspSettings );

  // Pongo las incidencias calculadas
  sound->SourceVoice->SetFrequencyRatio( dspSettings.DopplerFactor );
  sound->SourceVoice->SetOutputMatrix( AudioDevice.MasteringVoice, INPUTCHANNELS,
				       AudioDevice.Details.OutputFormat.Format.nChannels,
				       dspSettings.pMatrixCoefficients );
}

/*** Funci�n: Ejecuta un sonido ***/
void PlaySound( SOUND* sound, float volume )
{
  // Obtengo el estado actual
  XAUDIO2_VOICE_STATE state;
  sound->SourceVoice->GetState( &state );

  // Alimento el buffer si no hay uno presente
  if( state.BuffersQueued == 0 )
    sound->SourceVoice->SubmitSourceBuffer( &sound->SoundBuffer );

  // Volumen
  sound->SourceVoice->SetVolume( volume );
  // Play
  sound->SourceVoice->Start( 0 );
}

/*** Funci�n: Para un sonido ***/
void StopSound( SOUND* sound )
{
  sound->SourceVoice->Stop( 0 );
}

/*** Funci�n: Carga una canci�n para ser reproducida(OGG) ***/
void CreateMusic( MUSIC* music, char* musicFile )
{
  vorbis_info* info;
  FILE*        file;

  // Abro el archivo OGG
  file = fopen( musicFile, "rb" );
  ov_open( file, &(music->OggFile), NULL, 0 );
  info = ov_info( &(music->OggFile), -1 );
  
  // Calculo el formato
  ZeroMemory( &(music->MusicFormat), sizeof(WAVEFORMATEX) );
  music->MusicFormat.wFormatTag      = WAVE_FORMAT_PCM;
  music->MusicFormat.nChannels       = info->channels;
  music->MusicFormat.nSamplesPerSec  = info->rate;
  music->MusicFormat.nAvgBytesPerSec = info->rate * (info->channels * 16) / 8;
  music->MusicFormat.nBlockAlign     = (info->channels * 16) / 8;
  music->MusicFormat.wBitsPerSample  = 16;
  music->MusicFormat.cbSize          = NULL;

  // Source Voice
  const IXAudio2Voice* voices[]      = { AudioDevice.MasteringVoice, AudioDevice.SubmixVoice };
  const XAUDIO2_VOICE_SENDS sendList = { 2, (IXAudio2Voice**)voices };
  AudioDevice.XAudio2->CreateSourceVoice( &music->SourceVoice, &music->MusicFormat,
					  XAUDIO2_VOICE_MUSIC, 1.0f,
					  NULL, &sendList, NULL );
  
  // Alimento los buffers
  music->CurrentBuffer = 0;
  while( music->CurrentBuffer < NUMBUFFERS )
    {
      long int bytesRead;
      int bitStream;
      // Creo el buffer
      music->MusicBuffers[music->CurrentBuffer].pAudioData = (BYTE*)malloc( BUFFERSIZE );
      // Leo la informaci�n al buffer
      bytesRead = ov_read( &music->OggFile,
			   (char*)music->MusicBuffers[music->CurrentBuffer].pAudioData,
			   BUFFERSIZE,
			   0, 2, 1,
			   &bitStream );
      // Calculo las propiedades
      music->MusicBuffers[music->CurrentBuffer].Flags      = 0;
      music->MusicBuffers[music->CurrentBuffer].AudioBytes = bytesRead;
      music->MusicBuffers[music->CurrentBuffer].PlayBegin  = 0;
      music->MusicBuffers[music->CurrentBuffer].PlayLength = 0;
      music->MusicBuffers[music->CurrentBuffer].LoopBegin  = XAUDIO2_NO_LOOP_REGION;
      music->MusicBuffers[music->CurrentBuffer].LoopLength = 0;
      music->MusicBuffers[music->CurrentBuffer].LoopCount  = 0;
      // Subo el buffer al dispositivo de sonido
      music->SourceVoice->SubmitSourceBuffer( &music->MusicBuffers[music->CurrentBuffer] );
      music->CurrentBuffer++;
    }
}

/*** Funci�n: Libera la m�sica ***/
void FreeMusic( MUSIC* music )
{
  music->SourceVoice->Stop( 0 );
  music->SourceVoice->FlushSourceBuffers();
  music->SourceVoice->DestroyVoice();
  int nBuffers = 0;
  while( nBuffers < NUMBUFFERS )
    {
      free( (void*)music->MusicBuffers[nBuffers].pAudioData );
      nBuffers++;
    }
  ov_clear( &music->OggFile );
}

/*** Funci�n: Streaming de la m�sica ***/
void StreamMusic( MUSIC* music )
{
  // Obtengo el estado de la voz
  XAUDIO2_VOICE_STATE state;
  music->SourceVoice->GetState( &state );
  while( state.BuffersQueued != NUMBUFFERS )
    {
      // Si se usaron todos los buffers, vuelvo al primero
      if( music->CurrentBuffer == NUMBUFFERS )
	music->CurrentBuffer = 0;
      // Recargo el buffer
      long int bytesRead;
      int bitStream;
      // Leo la informaci�n al buffer
      bytesRead = ov_read( &music->OggFile,
			   (char*)music->MusicBuffers[music->CurrentBuffer].pAudioData,
			   BUFFERSIZE,
			   0, 2, 1,
			   &bitStream );
      // Si la m�sica se acab�
      if( bytesRead == 0 )
	{
	  if( music->Loop )
	    ov_raw_seek( &(music->OggFile), 0 );
	  else
	    music->MusicBuffers[music->CurrentBuffer].Flags = XAUDIO2_END_OF_STREAM;
	}
      // Calculo la extensi�n del buffer
      music->MusicBuffers[music->CurrentBuffer].AudioBytes = bytesRead;
      // Subo el buffer al dispositivo de sonido
      music->SourceVoice->SubmitSourceBuffer( &music->MusicBuffers[music->CurrentBuffer] );
      state.BuffersQueued++;
      music->CurrentBuffer++;
    }
  // Si la m�sica se acaba
}

/*** Funci�n: Inicia la m�sica ***/
void PlayMusic( MUSIC* music, float volume, bool loop )
{
  music->Loop = loop;
  music->SourceVoice->SetVolume( volume );
  music->SourceVoice->Start( 0 );
}

/*** Funci�n: Para la m�sica ***/
void StopMusic( MUSIC* music )
{
  music->SourceVoice->Stop( 0 );
}
