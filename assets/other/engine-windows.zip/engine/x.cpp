/******************************/
/**       -----------        **/
/**          x.cpp           **/
/**       -----------        **/
/**  Inicializaci�n y ren-   **/
/**  derizaci�n de modelos   **/
/******************************/

/*** Estructura de datos: MODEL ***/
typedef struct model
{
  ID3DXMesh*          Mesh;         // Interaz al model
  ID3DXBuffer*        mtrlBuffer;   // Buffer de materiales
  IDirect3DTexture9** texBuffer;    // Buffer de texturas
  DWORD               numMtrls;     // N�mero de materiales en el buffer
  D3DXVECTOR3         sphereCenter; // Centro de la esfera rodeante(bounding sphere)
  float               sphereRadius; // Radio de la esfera rodeante
} MODEL;
/*________*/


/*** Funci�n: Inicializa y carga los recursos asociados del modelo ***/
void InitModel( MODEL* model, char* modelFile, IDirect3DDevice9* Device )
{
  ID3DXBuffer* adjBuffer;
  ID3DXBuffer* effectBuffer;

  /* Cargo el modelo */
  D3DXLoadMeshFromX( modelFile,
		     D3DXMESH_MANAGED,
		     Device,
		     &adjBuffer,
		     &model->mtrlBuffer,
		     &effectBuffer,
		     &model->numMtrls,
		     &model->Mesh );

  // Memoria para el buffer de texturas
  model->texBuffer = (IDirect3DTexture9**)calloc( model->numMtrls, sizeof(IDirect3DTexture9*) );

  /* Cargo las texturas(si existen) */
  if( model->mtrlBuffer )
    {
      D3DXMATERIAL* mtrls = (D3DXMATERIAL*)model->mtrlBuffer->GetBufferPointer();
      unsigned int i;
      for( i = 0; i < model->numMtrls; i++ )
	{
	  // El modelo no carga un color ambiente, lo ponemos como el difuso
	  mtrls[i].MatD3D.Ambient = mtrls[i].MatD3D.Diffuse;
	  // Cargo la textura correspondiente al material
	  if( mtrls[i].pTextureFilename != NULL )
	    D3DXCreateTextureFromFile( Device,
				       mtrls[i].pTextureFilename,
				       &model->texBuffer[i] );
	  // Si la textura no existe
	  else
	    model->texBuffer[i] = NULL;
	}
    }

  /* Optimizo el modelo */
  model->Mesh->OptimizeInplace( D3DXMESHOPT_ATTRSORT |
				D3DXMESHOPT_COMPACT  | 
				D3DXMESHOPT_VERTEXCACHE,
				(DWORD*)adjBuffer->GetBufferPointer(),
				NULL, NULL, NULL );

  /* Calculo el "Bounding Sphere" */
  BYTE* v = NULL;
  model->Mesh->LockVertexBuffer( 0, (void**)&v );
  D3DXComputeBoundingSphere( (const D3DXVECTOR3*)v,
			     model->Mesh->GetNumVertices(),
			     D3DXGetFVFVertexSize( model->Mesh->GetFVF() ),
			     &model->sphereCenter,
			     &model->sphereRadius );

  /* Libero los buffers usados */
  adjBuffer->Release();
  effectBuffer->Release();
}

/*** Funci�n: libero los recursos asocidados con el modelo ***/
void FreeModel( MODEL* model )
{
  // Libero el buffer de materiales
  model->mtrlBuffer->Release();
  // Libero las texturas
  unsigned int i;
  for( i = 0; i < model->numMtrls; i++ )
      if( model->texBuffer[i] != NULL )
	model->texBuffer[i]->Release();
  free( model->texBuffer );
  // Libero el modelo
  model->Mesh->Release();
}

/*** Funci�n: Renderiza el modelo ***/
void RenderModel( MODEL* model, IDirect3DDevice9* Device, ID3DXEffect* effect, char* matVar, char* texVar )
{
  // Puntero al buffer de materiales 
  D3DXMATERIAL* mtrls = (D3DXMATERIAL*)model->mtrlBuffer->GetBufferPointer();
  // Dibujo todas las partes del modelo
  unsigned int i = 0;
  for( i = 0; i < model->numMtrls; i++ )
    {
      // Material y Textura
      Device->SetMaterial( &mtrls[i].MatD3D );
      Device->SetTexture( 0, model->texBuffer[i] );
      if( effect )
	{
	  effect->SetFloatArray( matVar, (const float*)&(mtrls[i].MatD3D.Diffuse), 4 );
	  if( model->texBuffer[i] )
	    effect->SetTexture( texVar, model->texBuffer[i] );
	  else
	    effect->SetTexture( texVar, g_defaultTex );
	  // Mando los valores al efecto
	  effect->CommitChanges();
	}
      // Dibujo
      model->Mesh->DrawSubset( i );
    }
  // Quito la �limas textura usada
  effect->SetTexture( texVar, g_defaultTex );
  Device->SetTexture( 0, NULL );
}
