/********************************/
/**       --------------       **/
/**         shadow.cpp         **/
/**       --------------       **/
/** Interfaz para crear y red- **/
/** derizar shadow maps        **/
/********************************/


/*** Estructura de datos: SHADOWMAP ***/
typedef struct shadowmap
{
  ID3DXEffect*          shadowMapEffect;
  IDirect3DTexture9*    shadowMap;
  IDirect3DSurface9*    shadowSurface;
  ID3DXRenderToSurface* renderSurface;
  unsigned int          mapSize;
} SHADOWMAP;
/*________*/

/*** Funci�n: Crea e inicializa una estructura SHADOWMAP ***/
bool CreateShadowMap( SHADOWMAP* sm, unsigned int mapSize, IDirect3DDevice9* Device )
{
  // Guardo el tama�o del shadow map
  sm->mapSize = mapSize;

  // Creaci�n de Texturas
  Device->CreateTexture( sm->mapSize, sm->mapSize, 1,
			 D3DUSAGE_RENDERTARGET, D3DFMT_R32F,
			 D3DPOOL_DEFAULT, &sm->shadowMap, NULL );
  D3DXCreateRenderToSurface( Device, sm->mapSize, sm->mapSize, D3DFMT_R32F,
			     true, D3DFMT_D24X8, &sm->renderSurface );

  // Compilaci�n y creaci�n del efecto
  ID3DXBuffer* errors = NULL;
  HRESULT      hr     = NULL;
  hr = D3DXCreateEffectFromFile( Device, "shadow.fx", NULL, NULL, D3DXFX_NOT_CLONEABLE, NULL, &sm->shadowMapEffect, &errors );
  // Si la creaci�n del efecto falla, reporto el error
  if( hr != D3D_OK )
    {
      MessageBox( NULL, (char*)errors->GetBufferPointer(), "shadow.fx", MB_ICONERROR );
      errors->Release();
      return false;
    }
  
  return true;
}

/*** Funci�n: Destruyo la interfaz para el shadow map ***/
void FreeShadowMap( SHADOWMAP* sm )
{
  // Destruyo las texturas y superficies
  sm->shadowMap->Release();
  sm->renderSurface->Release();

  // Destuyo el efecto
  sm->shadowMapEffect->Release();
}

/*** Funci�n: Inicia la creaci�n del shadow map seg�n los par�metros ***/
void BeginShadowMap( SHADOWMAP*        sm,         // Shadow Map
		     D3DLIGHT9*        lightSpec,  // Caracter�sticas de la luz
		     float             lightRange, // Light Range
		     IDirect3DDevice9* Device )    // Device
{
  // Direcci�n de la luz
  D3DXMATRIX   lightProj, lightView;
  D3DVIEWPORT9 lightViewport;
  D3DXVECTOR4  lightVector; 
  D3DXVECTOR3  lightLook = D3DXVECTOR3( lightSpec->Position.x + lightSpec->Direction.x,
					lightSpec->Position.y + lightSpec->Direction.y,
					lightSpec->Position.z + lightSpec->Direction.z );

  // Calculo la matriz de proyecci�n de la luz
  if( lightSpec->Type == D3DLIGHT_POINT ) // Puntual
    {
      D3DXMatrixPerspectiveFovLH( &lightProj,
				  2.0f * atan( 0.5f * lightRange / lightSpec->Range ),
				  1.0f, 1.0f, lightSpec->Range );
      lightVector = D3DXVECTOR4( lightSpec->Position, 1.0f );
    }
  else // Direccional
    {
      D3DXMatrixOrthoLH( &lightProj, lightRange, lightRange, 0.0f, lightSpec->Range );
      lightVector = D3DXVECTOR4( lightSpec->Direction, 0.0f );
    }

  // Calculo la c�mara de la luz
  D3DXMatrixLookAtLH( &lightView, &D3DXVECTOR3((lightSpec->Position)), &lightLook, &D3DXVECTOR3( 0.0f, 1.0f, 0.0f ) );

  // Viewport de la luz
  lightViewport.X      = 0;
  lightViewport.Y      = 0;
  lightViewport.Width  = sm->mapSize;
  lightViewport.Height = sm->mapSize;
  lightViewport.MinZ   = 0.0f;
  lightViewport.MaxZ   = 1.0f;

  // Calculo la matriz de la textura
  // Esta matriz se encarga de crear las coordenadas
  // de textura para usar con el shadow map
  D3DXMATRIX texScale, texTranslate, texMatrix;;
  float offset = 0.5f;// + (0.5f / sm->mapSize );
  D3DXMatrixScaling( &texScale, 0.5f, -0.5f, 1.0f );
  D3DXMatrixTranslation( &texTranslate, offset, offset, 0.0f );
  texMatrix = lightView * lightProj * texScale * texTranslate;
  
  // Activo el efecto de crear un shadow map
  UINT cPass;
  sm->shadowMapEffect->SetInt( "mapSize", sm->mapSize );
  sm->shadowMapEffect->SetVector( "lightVector", &lightVector );
  sm->shadowMapEffect->SetFloatArray( "lightColor", (const float*)&(lightSpec->Diffuse), 4 );
  sm->shadowMapEffect->SetMatrix( "lightViewMatrix", &lightView );
  sm->shadowMapEffect->SetMatrix( "lightProjMatrix", &lightProj );
  sm->shadowMapEffect->SetMatrix( "texMatrix"      , &texMatrix );
  sm->shadowMapEffect->SetTechnique( "CreateShadowMap" );
  sm->shadowMapEffect->Begin( &cPass, NULL );
  sm->shadowMapEffect->BeginPass( 0 );
  sm->shadowMapEffect->CommitChanges();

  // Activo la renderizaci�n en la superficie del shadow map
  sm->shadowMap->GetSurfaceLevel( 0, &sm->shadowSurface );
  sm->renderSurface->BeginScene( sm->shadowSurface, &lightViewport );
  Device->Clear( 0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, (D3DCOLOR)BLACK, 1.0f, 0 );
}

/*** Funci�n: Termina la creaci�n del shadow map ***/
void EndShadowMap( SHADOWMAP* sm, IDirect3DDevice9* Device )
{
  // Desactivo el efecto
  sm->shadowMapEffect->EndPass();
  sm->shadowMapEffect->End();
  sm->renderSurface->EndScene( D3DX_FILTER_NONE );
  Device->Clear( 0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, (D3DCOLOR)BLACK, 1.0f, 0 );

  // Libero la superficie
  sm->shadowSurface->Release();
}

/*** Funci�n: Inicia la renderizaci�n de sombras hechas por la luz ***/
void BeginShadowRender( SHADOWMAP* sm, IDirect3DDevice9* Device )
{
  // Activo el efecto de renderizar las sombras
  UINT cPass;
  D3DXMATRIX camView, camProj;
  Device->GetTransform( D3DTS_VIEW, &camView );
  Device->GetTransform( D3DTS_PROJECTION, &camProj );
  sm->shadowMapEffect->SetMatrix( "camViewMatrix", &camView );
  sm->shadowMapEffect->SetMatrix( "camProjMatrix", &camProj );
  sm->shadowMapEffect->SetTexture( "shadowMap", sm->shadowMap );
  sm->shadowMapEffect->SetTechnique( "RenderShadowMap" );
  sm->shadowMapEffect->Begin( &cPass, NULL );
  sm->shadowMapEffect->BeginPass( 0 );
  sm->shadowMapEffect->CommitChanges();
}

/*** Funci�n: Termina la renderizaci�n de las sombras ***/
void EndShadowRender( SHADOWMAP* sm, IDirect3DDevice9* Device )
{
  // Desativo el efecto
  sm->shadowMapEffect->EndPass();
  sm->shadowMapEffect->End();
}

/*** Funci�n: Pasa el valor de la matriz de transformaci�n del mundo al efecto ***/
void SetEffectWorldMatrix( SHADOWMAP* sm, D3DXMATRIX* worldMatrix )
{
  sm->shadowMapEffect->SetMatrix( "worldMatrix", worldMatrix );
  sm->shadowMapEffect->CommitChanges();
}
