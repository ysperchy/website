/****************************/
/**        -------         **/
/**        d3d.cpp         **/
/**        -------         **/
/**  Rutinas necesarias    **/
/**  para inicializar d3d  **/
/****************************/
/////////////////////////////////////////
/// Defines para que funcione XSound2 ///
/////////////////////////////////////////
#define __out
#define __inout
#define _WIN32_DCOM

/*** INCLUDES ***/
#include <stdio.h>
#include <time.h>
#include <d3dx9.h>
#include <xaudio2.h>
#include <xaudio2fx.h>
#include <X3DAudio.h>
#include <vorbis/vorbisfile.h>

/*** Funciones del ejercicio ***/
// Implementadas en "Ejercicio.cpp" //
void Init( void );
void Free( void );
void Loop( float elapsed );

/*** Textura por defecto ***/
IDirect3DTexture9* g_defaultTex;

/*** Procedimiento de la ventana(funci�n obligatoria) ***/
LRESULT CALLBACK WndProc( HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
  switch( msg ) // Manejo el mensaje recibido por la venatana
    {
    case WM_DESTROY:            // Mensaje recibido cuando se sale(obligatorio)
      PostQuitMessage(0);
      break;

    case WM_KEYDOWN:
      if( wParam == VK_ESCAPE ) // Si presiona escape, sale
	DestroyWindow( hwnd );
      break;
    }
  return DefWindowProc(hwnd, msg, wParam, lParam); // Los dem�s mensajes que emita la ventana
                                                   // dejo que se manejen con su comportamiento
                                                   // por defecto
}


/*** Funci�n inicializadora de Direct3D ****/
bool InitD3D(int width, int height,       // Dimensiones de la ventana
	     bool fullscreen,             // Fullscreen?
	     bool hardware,               // Soporte Hardware?
	     IDirect3DDevice9** device)   // D3D device [OUT]
{
  /*** Creaci�n de la ventana para la apliaci�n ***/

  HINSTANCE hInstance = (HINSTANCE)GetModuleHandle( NULL ); // Instancia del modulo

  WNDCLASS wc; // Estructura para crear ventana

  /* Especificaciones de la ventana */
  wc.style         = CS_HREDRAW | CS_VREDRAW;
  wc.lpfnWndProc   = (WNDPROC)WndProc;
  wc.cbClsExtra    = 0;
  wc.cbWndExtra    = 0;
  wc.hInstance     = hInstance;
  wc.hIcon         = LoadIcon(0, IDI_APPLICATION);
  wc.hCursor       = LoadCursor(0, IDC_ARROW);
  wc.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
  wc.lpszMenuName  = 0;
  wc.lpszClassName = "window_class";

  /* Registro la ventana */
  if( !RegisterClass( &wc ) )
    {
      MessageBox( 0, "Cannot create window", "Error", MB_ICONERROR );
      return false;
    }

  /* Creo la ventana */
  HWND hwnd = 0; // Puntero a la venatan creada
  hwnd = CreateWindow( "window_class", // Clase de la ventana
		       "Direct3D",     // Nombre
		       WS_EX_TOPMOST,  // Siempre encima de las otras
		       0, 0,           // Posici�n
		       width, height,  // Dimensi�n
		       NULL,           // Ventana pap�(no tiene)
		       NULL,           // Men�(no tiene)
		       hInstance,      // Applicaci�n a la que pertence
		       NULL            // Extra
		       );

  /* Muestro la ventana */
  ShowWindow( hwnd, SW_SHOW);
  UpdateWindow( hwnd );

  /*** Inicializaci�n Direct3D ***/

  IDirect3D9* d3d9 = NULL;                   // Interfaz de Direct3D ver9
  d3d9 = Direct3DCreate9( D3D_SDK_VERSION ); // Creo la interfaz

  if( !d3d9 )
    MessageBox( hwnd, "Could not create Direct3D interface", "Error", MB_ICONERROR );

  /* Verificaci�n de procesamiento de v�rtices */
  D3DCAPS9 caps;
  int vp = 0; // Capacidad de procesamiento de v�rtices

  /* Obtengo las capacidades de la tarjeta de video */
  d3d9->GetDeviceCaps( D3DADAPTER_DEFAULT,                          // Tarjeta de video primaria
		       hardware ? D3DDEVTYPE_HAL : D3DDEVTYPE_REF,  // Simulado o en hardware?
		       &caps );                                     // Guardo las capacidades

  if( caps.DevCaps & D3DDEVCAPS_HWTRANSFORMANDLIGHT )
    vp = D3DCREATE_HARDWARE_VERTEXPROCESSING; // Procesamiento de v�rtices en hardware
  else
    vp = D3DCREATE_SOFTWARE_VERTEXPROCESSING; // Procesamiento de v�rtices en software

  /* Especificaciones de la inicializaci�n de Direct3D */
  D3DPRESENT_PARAMETERS d3dpp;
  d3dpp.BackBufferWidth            = width;
  d3dpp.BackBufferHeight           = height;
  d3dpp.BackBufferFormat           = D3DFMT_A8R8G8B8;               // 32 bits
  d3dpp.BackBufferCount            = 1;                             // 0=Singlebuffer, 1=Doublebuffering, 2=Triplebuffering
  d3dpp.MultiSampleType            = D3DMULTISAMPLE_NONE;           // AA
  d3dpp.MultiSampleQuality         = 0;
  d3dpp.SwapEffect                 = D3DSWAPEFFECT_DISCARD;
  d3dpp.hDeviceWindow              = hwnd;                          // Ventana a renderizar
  d3dpp.Windowed                   = !fullscreen;
  d3dpp.EnableAutoDepthStencil     = true;
  d3dpp.AutoDepthStencilFormat     = D3DFMT_D24S8;                  // Z-buffer=24bits, Stencil-Buffer=8bits
  d3dpp.Flags                      = 0;
  d3dpp.FullScreen_RefreshRateInHz = D3DPRESENT_RATE_DEFAULT;       // Taza de refrezco actual
  d3dpp.PresentationInterval       = D3DPRESENT_INTERVAL_IMMEDIATE; // Dibujado inmediato

  /* Creaci�n del dispositivo */
  HRESULT hr = NULL;
  hr = d3d9->CreateDevice( D3DADAPTER_DEFAULT,                          // Tarjeta primaria
			   hardware ? D3DDEVTYPE_HAL : D3DDEVTYPE_REF,  // Simulado o en hardware?
			   hwnd,                                        // Ventana asociada con el dispositivo
			   vp,                                          // Tipo de procesamiento de v�rtices
			   &d3dpp,                                      // Especificaciones
			   device                                       // Dispoisito [OUT]
			   );

  /* Si falla */
  if( FAILED(hr) )
    {
      d3dpp.AutoDepthStencilFormat = D3DFMT_D16;                            // Probamos con un Z-buffer de 16bits
      hr = d3d9->CreateDevice( D3DADAPTER_DEFAULT,                          // Tarjeta primaria
			       hardware ? D3DDEVTYPE_HAL : D3DDEVTYPE_REF,  // Simulado o en hardware?
			       hwnd,                                        // Ventana asociada con el dispositivo
			       vp,                                          // Tipo de procesamiento de v�rtices
			       &d3dpp,                                      // Especificaciones
			       device
			       );
    }

  /* Libero la interfaz a Direct3D9 */
  d3d9->Release();

  if( FAILED(hr) ) // Falla la creaci�n del dispositivo
    {
      MessageBox( hwnd, "Could not create Direct3D device, check specs!", "Error", MB_ICONERROR );
      return false;
    }

  /* Inicializo los n�meros aleatorios */
  srand( time(NULL) );

  /* Creo la textura por defecto */
  // Textura cuando el v�rtice no tiene niguna asociada
  (*device)->CreateTexture( 1, 1, 1, D3DUSAGE_DYNAMIC, d3dpp.BackBufferFormat, D3DPOOL_DEFAULT, &g_defaultTex, NULL );
  // Un cuadro blanco
  D3DLOCKED_RECT lr;
  g_defaultTex->LockRect( 0, &lr, NULL, 0 );
  *(LPDWORD)lr.pBits = D3DCOLOR_RGBA( 255, 255, 255, 255 );
  g_defaultTex->UnlockRect( 0 );
  
  return true; // �xito
}

/*** Funci�n liberadora de Direct3D ***/
bool FreeD3D( IDirect3DDevice9* device )
{
  /* Libero la textura por defecto */
  g_defaultTex->Release();
  /* Libero la interfaz a la tarjeta de video */
  device->Release();

  return true; // �xito
}


/*** Ciclo verificador de mensajes de la venatana ***/
void MsgLoop( void )
{
  /* Variable para medir el tiempo empleado entre frame y frame */
  static float lastTime = (float)timeGetTime();
 
  /* Recibo los mensajes de la ventana */
  MSG msg; // Mensaje
  ZeroMemory( &msg, sizeof(MSG) );

  /* Mientras el mensaje no sea salir */
  while( msg.message != WM_QUIT )
    {
      /* Verifico si hay mensajes por procesar */
      if( PeekMessage( &msg, 0, 0, 0, PM_REMOVE ) )
	{
	  TranslateMessage( &msg );
	  DispatchMessage( &msg );
	}
      else
	{
	  float currTime  = (float)timeGetTime();       // Tiempo Actual
	  float elapsed = (currTime - lastTime)*0.001f; // Delta-tiempo(en mil�simas)
	  lastTime = currTime;                          // Actualizo el �ltimo tiempo
	  Loop( elapsed );
	}
    }
}


/*** WinMain ***/
int WINAPI WinMain( HINSTANCE hInstance,
		    HINSTANCE prevInstance,
		    PSTR cmdLine,
		    int showCmd )
{
  Init();    // Inicializo recursos
  MsgLoop(); // Mensajes y Loop(video, sonido, input, etc...)
  Free();    // Libero Recursos

  return 0;
}
