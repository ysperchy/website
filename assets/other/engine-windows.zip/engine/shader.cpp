/********************************/
/**       --------------       **/
/**         shader.cpp         **/
/**       --------------       **/
/** Interfaz para crear y com- **/
/** pilar shaders. -HLSL-      **/
/********************************/

/*** Estructura de datos: VERTEX_SHADER ***/
typedef struct vertex_shader
{
  IDirect3DVertexShader9* shader; // Shader
  ID3DXConstantTable*     table;  // Constant Table
} VERTEX_SHADER;
/*________*/

typedef struct pixel_shader
{
  IDirect3DPixelShader9* shader; // Shader
  ID3DXConstantTable*    table;  // Constant Table
} PIXEL_SHADER;
/*________*/


/*** Funci�n: Inicializa y compila un vertex shader ***/
bool InitVertexShader( VERTEX_SHADER* vShader, const char* shaderFile, const char* version, IDirect3DDevice9* Device )
{
  ID3DXBuffer* shader;
  ID3DXBuffer* errors;
  HRESULT      hr = NULL;
  vShader->shader = NULL;
  vShader->table  = NULL;

  // Compilaci�n
  hr = D3DXCompileShaderFromFile( shaderFile,        // Source code
				  NULL,              // No #DEFINE's
				  NULL,              // No #INCLUDE's
				  "main",            // Entry-Point Funci�n
				  version,           // Versi�n del Shader
				  NULL,              // No Flags
				  &shader,           // shader[OUT]
				  &errors,           // errors[OUT]
				  &vShader->table ); // constable[OUT]

  // Fall� compilaci�n
  if( hr != D3D_OK )
    {
      MessageBox( NULL, (char*)errors->GetBufferPointer(), shaderFile, MB_ICONERROR );
      errors->Release();
      return false;
    }

  hr = Device->CreateVertexShader( (DWORD*)shader->GetBufferPointer(), &vShader->shader );

  if( hr != D3D_OK )
    {
      MessageBox( NULL, "Error creating vertex shader in Device", shaderFile, MB_ICONERROR );
      return false;
    }

  shader->Release();
  return true;
}

/*** Funci�n: Inicializa y compila un pixel shader ***/
bool InitPixelShader( PIXEL_SHADER* pShader, const char* shaderFile, const char* version, IDirect3DDevice9* Device )
{
  ID3DXBuffer* shader;
  ID3DXBuffer* errors;
  HRESULT      hr = NULL;
  pShader->shader = NULL;
  pShader->table  = NULL;

  // Compilaci�n
  hr = D3DXCompileShaderFromFile( shaderFile,        // Source code
				  NULL,              // No #DEFINE's
				  NULL,              // No #INCLUDE's
				  "main",            // Entry-Point Funci�n
				  version,           // Versi�n del Shader
				  NULL,              // No Flags
				  &shader,           // shader[OUT]
				  &errors,           // errors[OUT]
				  &pShader->table ); // constable[OUT]

  // Fall� compilaci�n
  if( hr != D3D_OK )
    {
      MessageBox( NULL, (char*)errors->GetBufferPointer(), shaderFile, MB_ICONERROR );
      errors->Release();
      return false;
    }

  hr = Device->CreatePixelShader( (DWORD*)shader->GetBufferPointer(), &pShader->shader );

  if( hr != D3D_OK )
    {
      MessageBox( NULL, "Error creating pixel shader in Device", shaderFile, MB_ICONERROR );
      return false;
    }

  shader->Release();
  return true;
}

/*** Funci�n: Libera un vertex shader ***/
void FreeVertexShader( VERTEX_SHADER* vShader )
{
  vShader->shader->Release();
  vShader->table->Release();
}

/*** Funci�n: Libera un pixel shader ***/
void FreePixelShader( PIXEL_SHADER* pShader )
{
  pShader->shader->Release();
  pShader->table->Release();
}
