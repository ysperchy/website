/******************************/
/**       -----------        **/
/**        fonts.cpp         **/
/**       -----------        **/
/**  Inicializaci�n y ren-   **/
/**  derizaci�n de fuentes   **/
/******************************/

/*** Interfaz al uso de la fuente ***/
ID3DXFont* Font = NULL;


/*** Funci�n: Inicia la fuente con nombre "fontName" ***/
void InitFont( char* fontName, IDirect3DDevice9* Device )
{
  D3DXFONT_DESC fd;
  ZeroMemory( &fd, sizeof(D3DXFONT_DESC) );

  fd.Height          = 25;
  fd.Width           = 12;
  fd.Weight          = FW_NORMAL;
  fd.MipLevels       = D3DX_DEFAULT;
  fd.Italic          = false;
  fd.CharSet         = DEFAULT_CHARSET;
  fd.OutputPrecision = OUT_DEFAULT_PRECIS;
  fd.Quality         = DEFAULT_QUALITY;
  fd.PitchAndFamily  = DEFAULT_PITCH | FF_DONTCARE;
  strcpy ( fd.FaceName, fontName );

  D3DXCreateFontIndirect( Device, &fd, &Font );
}

/*** Funci�n: Libera la interfaz a la fuente ***/
void FreeFont()
{
  Font->Release();
}

/*** Funci�n: Renderiza texto ***/
// text : Texto a renderizar
// pos  : Rect�ngulo en done se renderizar� el texto(en coordenadas de ventana)
// color: Color del texto
void RenderText( char* text, RECT* pos, D3DCOLOR color )
{
  Font->DrawText( NULL,
		  text,
		  -1,
		  pos,
		  DT_TOP | DT_LEFT,
		  color );
}
