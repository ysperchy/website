//
//  reseau.cpp
//  D-Spaces
//
//  Created by Salim PERCHY on 22/09/2016.
//
//

#include "ba.h"

/***********
 DISCLAIMER:
 Turn ON Target Membership ONLY on this file
 if you want to execute this demo
 ************/

int main( int argc, const char* argv[] ) {
    std::cout << "--Application Example: Social Network--" << std::endl << std::endl;
    std::cout << "Creating Boolean Algebra with comment tags..." << std::endl;
    std::cout << "\th: Personal." << std::endl;
    std::cout << "\tp: Political." << std::endl;
    std::cout << "\tr: Religious." << std::endl;
    std::cout << "\tn: News." << std::endl;
    std::cout << "\th: Sports." << std::endl;
    ba<char> ReseauSocial( { 'h', 'p', 'r', 'n', 's' }, 3 );
    std::cout << std::endl;
    ReseauSocial.m_scse.print_cons( [] (std::set<char> s) {
        std::cout << "{";
        std::for_each( s.begin(), s.end(), [] (char c) {
            std::cout << c << ",";
        } );
        std::cout << "} ";
    } );
    std::cout << std::endl << "Boolean Algebra Ordering Relation: ";
    ReseauSocial.m_scse.print_relation( true );
    bool distributive = ReseauSocial.m_scse.is_distributive();
    std::cout << std::endl << "Reseau Social IS " << ( distributive ? "" : "NOT " ) << "distributive!" << std::endl << std::endl;
    std::cout << "Creating belief profiles(3):" << std::endl;
    std::cout << "\tAgent 1: Political." << std::endl;
    std::cout << "\tAgent 2: Religious." << std::endl;
    std::cout << "\tAgent 3: Objective." << std::endl;
    auto belief_func = [] (int agent, std::set<char> comment, std::set<char> tags) {
        std::set<char> belief;
        switch( agent ) {
            case 1:
                belief = comment;
                if( belief.find( 'n' ) != belief.end() )
                    belief.insert( 'p' );
                break;
            case 2:
                belief = comment;
                if( belief.find( 'h' ) != belief.end() )
                    belief.insert( 'r' );
                break;
            case 3:
                belief = comment;
                break;
        }
        return belief;
    };
    std::cout << "Aplying agent belief profiles..." << std::endl << std::endl;
    ReseauSocial.map_s( belief_func );
    std::cout << "Creating uttering profiles(3):" << std::endl;
    std::cout << "\tAgent 1: Political and Discreet."   << std::endl;
    std::cout << "\tAgent 2: Apolitical." << std::endl;
    std::cout << "\tAgent 3: Objective."  << std::endl;
    auto utterance_func = [] (int agent, std::set<char> comment, std::set<char> tags) {
        std::set<char> utterance;
        switch( agent ) {
            case 1:
                utterance = comment;
                utterance.erase( 'h' );
                if( utterance.find( 'n' ) != utterance.end() )
                    utterance.insert( 'p' );
                break;
            case 2:
                utterance = comment;
                utterance.erase( 'p' );
                break;
            case 3:
                utterance = comment;
                break;
        }
        return utterance;
    };
    std::cout << "Aplying agent uttering profiles..." << std::endl;
    ReseauSocial.map_e( utterance_func );
    std::cout << std::endl << "Agent 1 belief function:" << std::endl;
    ReseauSocial.m_scse.print_sfunc( 1 );
    std::cout << "Agent 1 utterance function:" << std::endl;
    ReseauSocial.m_scse.print_efunc( 1 );
    std::cout << std::endl << "Agent 2 belief function:" << std::endl;
    ReseauSocial.m_scse.print_sfunc( 2 );
    std::cout << "Agent 2 utterance function:" << std::endl;
    ReseauSocial.m_scse.print_efunc( 2 );
    std::cout << std::endl << "Agent 3 belief function:" << std::endl;
    ReseauSocial.m_scse.print_sfunc( 3 );
    std::cout << "Agent 3 utterance function:" << std::endl;
    ReseauSocial.m_scse.print_efunc( 3 );
    std::set<char> comment;
    std::function<std::string(char)> tagger = [] ( char c ) {
        switch (c) {
            case 'h':
                return "personal";
            case 'p':
                return "political";
            case 'r':
                return "religious";
            case 'n':
                return "news";
            case 's':
                return "sports";
            default:
                return "";
        }
    };
    std::cout << std::endl << "--1st Scenario--" << std::endl;
    std::cout << "\tB₂(B₁(news ⨆ U₁(news))) = ";
    comment = ReseauSocial.m_scse.s( 2, ReseauSocial.m_scse.s( 1, ReseauSocial.m_scse.lub( { {'n'}, ReseauSocial.m_scse.e( 1, {'n'} ) } ) ) );
    std::for_each( comment.begin(), comment.end(), [tagger] (char c) { std::cout << tagger(c) << ", "; } );
    std::cout<< std::endl << "--2nd Scenario--" << std::endl;
    std::cout << "\tB₁(personal) → U₁(B₂(personal ⨆ sports)) ⨆ B₁(personal) = ";
    comment = ReseauSocial.m_scse.lub( {
        ReseauSocial.m_scse.imp( ReseauSocial.m_scse.s( 1, {'h'} ),
                                 ReseauSocial.m_scse.e( 1, ReseauSocial.m_scse.s( 2, ReseauSocial.m_scse.lub( { { 'h', 's'} } ) ) ) ),
        ReseauSocial.m_scse.s( 1, {'h'} ) } );
    std::for_each( comment.begin(), comment.end(), [tagger] (char c) { std::cout << tagger(c) << ", "; } );
    std::cout << std::endl << "--3rd Scenario--" << std::endl;
    std::cout << "\tB₃(¬news ⨆ ¬news --> U₃(B₁(news) ⨆ B₂(news)) ⨆ B₁(¬news) = ";
    comment = ReseauSocial.m_scse.lub( {
        ReseauSocial.m_scse.s( 3, ReseauSocial.m_scse.lub( {
            ReseauSocial.m_scse.imp( ReseauSocial.m_scse.imp( {'n'}, {ReseauSocial.m_scse.lub()} ),
                                     ReseauSocial.m_scse.e( 3, ReseauSocial.m_scse.lub( {
                ReseauSocial.m_scse.s( 1, {'n'} ),
                ReseauSocial.m_scse.s( 2, {'n'} ) } ) ) ),
            ReseauSocial.m_scse.imp( {'n'}, {ReseauSocial.m_scse.lub()} ) } ) ),
        ReseauSocial.m_scse.s( 1, ReseauSocial.m_scse.imp( {'n'}, {ReseauSocial.m_scse.lub()} ) ) } );
    std::for_each( comment.begin(), comment.end(), [tagger] (char c) { std::cout << tagger(c) << ", "; } );
    std::cout << std::endl;
    return 0;
}