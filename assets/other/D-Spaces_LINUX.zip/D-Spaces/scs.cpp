//
//  scs.cpp
//  D-Spaces
//
//  Created by Salim PERCHY on 25/11/14.
//
//

#include "scs.h"

template <class ELEM_TYPE>
scs<ELEM_TYPE>::scs( const cs<ELEM_TYPE>& CS, unsigned int n ) : cs<ELEM_TYPE>( CS ) {
    s_func.resize( n, std::map<ELEM_TYPE, ELEM_TYPE>() );
    ELEM_TYPE bottom = cs<ELEM_TYPE>::glb();
    for( int i = 0; i < n; i++ )
        s_func[i][bottom] = bottom; // S.1 (emptiness axiom)
}

template <class ELEM_TYPE>
scs<ELEM_TYPE>::scs( const scs<ELEM_TYPE>& SCS ) : cs<ELEM_TYPE>( SCS ) {
    s_func = SCS.s_func;
}

template <class ELEM_TYPE>
scs<ELEM_TYPE>::~scs( void ) = default;

template <class ELEM_TYPE>
void scs<ELEM_TYPE>::s_map( unsigned int i, std::vector<ELEM_TYPE> elems, ELEM_TYPE image ) {
    for( int j = 0; j < elems.size(); j++ )
        if( std::find( cs<ELEM_TYPE>::m_cons->begin(), cs<ELEM_TYPE>::m_cons->end(), elems[j] ) != cs<ELEM_TYPE>::m_cons->end() and
            std::find( cs<ELEM_TYPE>::m_cons->begin(), cs<ELEM_TYPE>::m_cons->end(), image    ) != cs<ELEM_TYPE>::m_cons->end() )
            s_func[i-1][elems[j]] = image;
}

template <class ELEM_TYPE>
ELEM_TYPE scs<ELEM_TYPE>::s( unsigned int i, ELEM_TYPE c ) {
    return s_func[i-1].at(c);
}

template <class ELEM_TYPE>
std::vector<ELEM_TYPE> scs<ELEM_TYPE>::s_inv( unsigned int i, ELEM_TYPE c ) {
    std::vector<ELEM_TYPE> inv_image;
    typename std::map<ELEM_TYPE,ELEM_TYPE>::const_iterator it;
    for( it = s_func[i-1].begin(); it != s_func[i-1].end(); it++ )
        if( it->second == c )
            inv_image.push_back( it->first );
    return inv_image;
}

template <class ELEM_TYPE>
bool scs<ELEM_TYPE>::f_properties( unsigned int i, std::string name, std::map<ELEM_TYPE, ELEM_TYPE> map, FUNCTION_PROPERTY property ) {
    switch( property ) {
        case FUNCTION_PROPERTY::FP_TOTAL: {
            bool total = true;
            for( int j = 0; j < cs<ELEM_TYPE>::m_cons->size(); j++ ) {
                ELEM_TYPE c = (*cs<ELEM_TYPE>::m_cons)[j];
                if( !map.count( c ) ) { // Verify if f(c) exists
                    std::cerr << name << "_" << i << "(" << j << ") NOT defined" << std::endl;
                    total = false;
                }
            }
            return total;
        }
        case FUNCTION_PROPERTY::FP_SURJECTIVE: {
            bool surjective = true;
            for( int j = 0; j < cs<ELEM_TYPE>::m_cons->size(); j++ ) {
                ELEM_TYPE c = (*cs<ELEM_TYPE>::m_cons)[j];
                // Pre-image of c
                typename std::map<ELEM_TYPE,ELEM_TYPE>::const_iterator it;
                std::vector<ELEM_TYPE> pre_img;
                for( it = map.begin(); it != map.end(); it++ )
                    if( it->second == c )
                        pre_img.push_back( it->first );
                if( pre_img.size() == 0 ) { // Verify if f^-1(c) exists
                    std::cerr << name << "_" << i << "^-1(" << j << ") NOT defined" << std::endl;
                    surjective = false;
                }
            }
            return surjective;
        }
        case FUNCTION_PROPERTY::FP_INJECTIVE: {
            bool injective = true;
            for( int j = 0; j < cs<ELEM_TYPE>::m_cons->size(); j++ ) {
                ELEM_TYPE c= (*cs<ELEM_TYPE>::m_cons)[j];
                // Pre-image of c
                typename std::map<ELEM_TYPE,ELEM_TYPE>::const_iterator it;
                std::vector<ELEM_TYPE> pre_img;
                for( it = map.begin(); it != map.end(); it++ )
                    if( it->second == c )
                        pre_img.push_back( it->first );
                if( pre_img.size() > 1 ) {
                    std::cerr << name << "_" << i << "(";
                    std::for_each( pre_img.begin(), pre_img.end(), [this] (ELEM_TYPE e) { std::cerr << cs<ELEM_TYPE>::p_getElementNum( e ) << ","; } );
                    std::cerr << ") = " << j << std::endl;
                    injective = false;
                }
            }
            return injective;
        }
        case FUNCTION_PROPERTY::FP_BIJECTIVE: {
            bool total      = f_properties( i, name, map, FUNCTION_PROPERTY::FP_TOTAL       );
            bool surjective = f_properties( i, name, map, FUNCTION_PROPERTY::FP_SURJECTIVE  );
            bool injective  = f_properties( i, name, map, FUNCTION_PROPERTY::FP_INJECTIVE   );
            return total and surjective and injective;
        }
        case FUNCTION_PROPERTY::FP_JOIN_DISTRIBUTIVE:
        case FUNCTION_PROPERTY::FP_MEET_DISTRIBUTIVE: {
            bool distributive = f_properties( i, name, map, FUNCTION_PROPERTY::FP_TOTAL ); // Check if total first
            char op = ' ';
            if( property == FUNCTION_PROPERTY::FP_MEET_DISTRIBUTIVE )
                op = 'n';
            if( property == FUNCTION_PROPERTY::FP_JOIN_DISTRIBUTIVE )
                op = 'u';
            for( int j = 0; j < cs<ELEM_TYPE>::m_cons->size(); j++ ) {
                for( int k = 0; k < cs<ELEM_TYPE>::m_cons->size(); k++ ) {
                    if( j == k ) continue;
                    ELEM_TYPE c = (*cs<ELEM_TYPE>::m_cons)[j], d = (*cs<ELEM_TYPE>::m_cons)[k];
                    ELEM_TYPE s_cd = cs<ELEM_TYPE>::glb(), sc_sd = cs<ELEM_TYPE>::glb();
                    bool defined = true;
                    if ( !map.count(c) or !map.count(d) )
                        defined = false;
                    if( defined and property == FUNCTION_PROPERTY::FP_JOIN_DISTRIBUTIVE ) {
                        if( map.count( cs<ELEM_TYPE>::lub( {c,d} ) ) ) {
                            s_cd  = map.at( cs<ELEM_TYPE>::lub( {c,d} ) );
                            sc_sd = cs<ELEM_TYPE>::lub( { map.at(c), map.at(d) } );
                        }
                    }
                    if( defined and property == FUNCTION_PROPERTY::FP_MEET_DISTRIBUTIVE ) {
                        if( map.count( cs<ELEM_TYPE>::glb( {c,d} ) ) ) {
                            s_cd  = map.at( cs<ELEM_TYPE>::glb( {c,d} ) );
                            sc_sd = cs<ELEM_TYPE>::glb( { map.at(c), map.at(d) } );
                        }
                    }
                    if( defined and s_cd != sc_sd ) {
                        std::cerr << name << "_" << i << "(" << j << " " << op << " " << k << ") = " << cs<ELEM_TYPE>::p_getElementNum( s_cd ) << " =/= " << cs<ELEM_TYPE>::p_getElementNum( sc_sd ) << " = " << name << "_" << i << "(" << j << ") " << op << " " << name << "_" << i << "(" << k << ")" << std::endl;
                        distributive = false;
                    }
                }
            }
            return distributive;
        }
        default:
            return true;
    }
}

template <class ELEM_TYPE>
bool scs<ELEM_TYPE>::s_properties( unsigned int i, S_FUNCTION_PROPERTY property ) {
    switch( property ) {
        case S_FUNCTION_PROPERTY::SP_TOTAL:
            return f_properties( i, "s", s_func[i-1], FUNCTION_PROPERTY::FP_TOTAL );
        case S_FUNCTION_PROPERTY::SP_SURJECTIVE:
            return f_properties( i, "s", s_func[i-1], FUNCTION_PROPERTY::FP_SURJECTIVE );
        case S_FUNCTION_PROPERTY::SP_INJECTIVE:
            return f_properties( i, "s", s_func[i-1], FUNCTION_PROPERTY::FP_INJECTIVE );
        case S_FUNCTION_PROPERTY::SP_BIJECTIVE:
            return f_properties( i, "s", s_func[i-1], FUNCTION_PROPERTY::FP_BIJECTIVE );
        case S_FUNCTION_PROPERTY::SP_JOIN_DISTRIBUTIVE:
            return f_properties( i, "s", s_func[i-1], FUNCTION_PROPERTY::FP_JOIN_DISTRIBUTIVE );
        case S_FUNCTION_PROPERTY::SP_MEET_DISTRIBUTIVE:
            return f_properties( i, "s", s_func[i-1], FUNCTION_PROPERTY::FP_MEET_DISTRIBUTIVE );
        default:
            return true;
    }
}

template <class ELEM_TYPE>
void scs<ELEM_TYPE>::print_func( unsigned int i, std::string name, std::map<ELEM_TYPE, ELEM_TYPE> map ) {
    std::cout << name << "_" << i << ":" << std::endl;
    typename std::map<ELEM_TYPE,ELEM_TYPE>::const_iterator it;
    for( it = map.begin(); it != map.end(); it++ )
        std::cout << "<" << cs<ELEM_TYPE>::p_getElementNum( it->first ) << "," << cs<ELEM_TYPE>::p_getElementNum( it->second ) << ">" << " ";
    std::cout << std::endl;
}

template <class ELEM_TYPE>
void scs<ELEM_TYPE>::print_sfunc( unsigned int i ) {
    print_func( i, "s", s_func[i-1] );
}

template class scs<int>;
template class scs<std::vector<int>>;
template class scs<std::set<int>>;
template class scs<char>;
template class scs<std::vector<char>>;
template class scs<std::set<char>>;
template class scs<std::string>;
template class scs<std::vector<std::string>>;
template class scs<std::set<std::string>>;
template class scs<std::pair<std::string,int>>;
template class scs<std::vector<std::pair<std::string,int>>>;
template class scs<std::set<std::pair<std::string,int>>>;
