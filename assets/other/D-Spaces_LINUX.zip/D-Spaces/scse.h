//
//  scse.h
//  D-Spaces
//
//  Created by Salim PERCHY on 27/11/14.
//
//

/*!
 *  @header Spatial Constraint System with Extrusion
 *  @abstract A Spatial Constraint System with Extrusion (SCSE for short) is a spatial constraint system equipped with n extrusion functions on its set of elements. Each map satifies one axiom; it is the right inverse of a space function (see E.1).
 *  @discussion A SCSE is a tuple ⟨SCS, e₁, ..., e<sub>n</sub>⟩ where
 *
 *  SCS     : A Spatial Constraint System.
 *
 *  eᵢ      : A self map (also called an extrusion function) on the elements of the CS satisfying
 *
 *      - E.1       eᵢ(sᵢ(c)) = c                   (right-inverse)
 *
 *  it may also satisfy
 *
 *      - E.2       eᵢ(⊥) = ⊥                       (emptiness)
 *
 *      - E.3       eᵢ(c ⨆ d) = eᵢ(c) ⨆ eᵢ(d)       (distribution)
 *  @author Salim PERCHY
 *  @updated 2016-01-25
 */

#ifndef __D_Spaces__scse__
#define __D_Spaces__scse__

#include "scs.h"

/*!
 *  @class scse
 *  @abstract The Spatial Constraint System with Extrusion class.
 *  @discussion Derived constraint systems inherit the functionality of this class. It implements extrusion functions with property-checking on them.
 *  @seealso https://hal.archives-ouvertes.fr/hal-01242971
 */
template <class ELEM_TYPE>
class scse : public scs<ELEM_TYPE> {
protected:
    /*!
     *  @var e_func
     *  Vector containing the extrusion functions of the CS.
     */
    std::vector< std::map<ELEM_TYPE, ELEM_TYPE> > e_func;
    
public:
    /*!
     *  @typedef E_CHOICE_FUNCTION
     *  @abstract Enumeration of possible canonical ways of constructing the extrusion functions.
     *  @discussion can be
     *
     *      - EC_SUPREMA: eᵢ(c) = ⨆(sᵢ<sup>-1</sup>(c)) (i.e. each element is mapped to the LUB of its fiber in the corresponding space function).
     *
     *      - EC_INFIMA: eᵢ(c) = ⨅(sᵢ<sup>-1</sup>(c)) (i.e. each element is mapped to the GLB of its fiber in the corresponding space function).
     *
     *      - EC_MANUAL: elements are mapped manually using @link e_map @/link.
     *
     *      - EC_RANDOM: elements are mapped to a random element of their respective fibers in the corresponding space function.
     */
    enum class E_CHOICE_FUNCTION { EC_SUPREMA, EC_INFIMA, EC_MANUAL, EC_RANDOM };
    
    /*!
     *  @function scse
     *  @abstract Constructor.
     *  @discussion This constructor will create n extrusion functions and map them according to <code>e_choice</code>
     *  @attribute Complexity
     *      O(n) where n is the number of elements in the SCS.
     *  @param SCS
     *      a SCS
     *  @param e_choice
     *      one of @link E_CHOICE_FUNCTION @/link
     */
    scse ( const scs<ELEM_TYPE>& SCS, E_CHOICE_FUNCTION e_choice );
    
    /*!
     *  @function scse
     *  @abstract Copy Constructor.
     *  @attribute Complexity
     *      Constant.
     *  @param SCSE
     *      already instantiated SCSE.
     */
    scse ( const scse<ELEM_TYPE>& SCSE );
    
    /*!
     *  @function ~scse
     *  @abstract Destructor.
     *  @attribute Complexity
     *      Constant.
     */
    ~scse( void );
    
    
    /*!
     *  @function e_map
     *  @abstract eᵢ(<code>elems</code>) = <code>image</code>
     *  @discussion The function will do nothing if the elements or the image are not in the elements of the SCS.
     *  @attribute Complexity
     *      O(n) where n is the number of elements to map.
     *  @param i
     *      index of the extrusion function.
     *  @param elems
     *      elements to map.
     *  @param image
     *      image to map elements to.
     */
    void e_map( unsigned int i, std::vector<ELEM_TYPE> elems, ELEM_TYPE image );
    
    /*!
     *  @function e
     *  @abstract Gets the image of element <code>c</code> in the extrusion function <code>i</code>.
     *  @attribute Complexity
     *      Constant.
     *  @param i
     *      index of the extrusion function.
     *  @param c
     *      element to retrieve its image.
     *  @result
     *      eᵢ(c)
     */
    ELEM_TYPE e( unsigned int i, ELEM_TYPE c );
    
    /*!
     *  @function e_inv
     *  @abstract Gets the inverse image of element <code>c</code> in the extrusion function <code>i</code>.
     *  @attribute Complexity
     *      O(n) where n is the number of elements of the SCS.
     *  @param i
     *      index of the extrusion function.
     *  @param c
     *      element to retrieve its fiber.
     *  @result
     *      eᵢ<sup>-1</sup>(c)
     */
    std::vector<ELEM_TYPE> e_inv( unsigned int i, ELEM_TYPE c );
    
    /*!
     *  @typedef E_FUNCTION_PROPERTY
     *  @abstract Enumeration of possible properties of a space function.
     *  @discussion each property has a one-on-one correspondance with the properties of @link FUNCTION_PROPERTY @/link(specified in SCS) with one adition
     *
     *      -EP_RIGHT_INVERSE_S: function is the right inverse of its corresponding space function (i.e. it satisfies E.1).
     */
    enum class E_FUNCTION_PROPERTY { EP_TOTAL, EP_SURJECTIVE, EP_INJECTIVE, EP_BIJECTIVE, EP_JOIN_DISTRIBUTIVE, EP_MEET_DISTRIBUTIVE, EP_RIGHT_INVERSE_S };
    
    /*!
     *  @function e_properties
     *  @abstract Checks whether the extrusion function <code>i</code> satisfies certain property.
     *  @attribute Complexity
     *      O(n) if <code>property = EP_TOTAL</code> or <code>property = EP_RIGHT_INVERSE_S</code> and O(n²) otherwise.
     *  @param i
     *      the index of the eztrusion function.
     *  @param property
     *      one of @link E_FUNCTION_PROPERTY @/link.
     *  @result
     *      <code>true</code> if the extrusion function satisfies the property, <code>false</code> otherwise. Prints to <code>std::cerr</code> the troublesome elements' ID's.
     */
    bool e_properties( unsigned int i, E_FUNCTION_PROPERTY property );
    
    /*!
     *  @function print_efunc
     *  @abstract Prints (on <code>std::cout</code>) the extrusion function <code>i</code> using elements' ID's.
     *  @attribute Complexity
     *      O(n) where n is the number of elements of the SCS.
     *  @param i
     *      the index of the extrusion function.
     */
    void print_efunc( unsigned int i );
};

#endif /* defined(__D_Spaces__scse__) */
