//
//  cs.cpp
//  D-Spaces
//
//  Created by Salim PERCHY on 07/11/14.
//
//

#include "cs.h"

template <class ELEM_TYPE>
cs<ELEM_TYPE>::cs( ELEM_TYPE bottom, ELEM_TYPE top ) {
    ELEM_TYPE elems[] = { bottom, top };
    // Add top and bottom to cons
    m_cons = new std::deque<ELEM_TYPE>( elems, elems + sizeof(elems) / sizeof(ELEM_TYPE) );
    // Create relation
    m_rel = new t_relation;
    // Add top and bottom to relation
    t_elem bottomIndex = boost::add_vertex( bottom, *m_rel );
    t_elem topIndex    = boost::add_vertex( top, *m_rel );
    // Add their relation
    boost::add_edge( bottomIndex, bottomIndex, *m_rel ); // Reflexive
    boost::add_edge( topIndex, topIndex, *m_rel );       // Reflexive
    boost::add_edge( bottomIndex, topIndex, *m_rel );    // Bottom --> Top
}

template <class ELEM_TYPE>
cs<ELEM_TYPE>::cs( const cs<ELEM_TYPE>& CS ) {
    m_cons   = new std::deque<ELEM_TYPE>( *(CS.m_cons) );
    m_rel    = new t_relation( *(CS.m_rel) );
}

template <class ELEM_TYPE>
cs<ELEM_TYPE>::~cs( void ) {
    delete m_cons;
    delete m_rel;
}

template <class ELEM_TYPE>
int cs<ELEM_TYPE>::p_getElementNum( ELEM_TYPE elem ) {
    typename std::deque<ELEM_TYPE>::iterator it = std::find( m_cons->begin(), m_cons->end(), elem );
    if( it != m_cons->end() ) // Found
        return std::distance( m_cons->begin(), it );
    else // Not found
        return -1;
}

template <class ELEM_TYPE>
ELEM_TYPE cs<ELEM_TYPE>::bound( const std::set<t_elem>& elems, bool lower ) {
    // Types
    typedef typename boost::graph_traits<t_relation>::adjacency_iterator adj_it;
    typedef typename boost::inv_adjacency_iterator_generator<t_relation>::type inv_adj_it;
    typedef typename boost::property_map<t_relation, boost::vertex_name_t>::type v_names;
    // Vertex names
    v_names vertexNames = boost::get( boost::vertex_name, *m_rel );
    // Global?
    if( elems.size() == 0 )
        return vertexNames[(lower ? 0 : 1)]; // Bottom (and top) is the default GLB (LUB respectively)
    // One element?
    if( elems.size() == 1 )
        return vertexNames[*elems.begin()];
    // Calculate S^l (or S^u)
    typename std::set<t_elem>::iterator it_set;
    std::vector<t_elem> s( m_cons->size() );
    std::iota( s.begin(), s.end(), 0 );
    std::set<t_elem> S( s.begin(), s.end() );
    for( it_set = elems.begin(); it_set != elems.end(); it_set++ ) {
        // Calculate si^l (or si^u)
        std::pair<inv_adj_it, inv_adj_it> sj_l = boost::inv_adjacent_vertices( *it_set, *m_rel );
        std::pair<adj_it, adj_it> sj_u = boost::adjacent_vertices( *it_set, *m_rel );
        std::set<t_elem> sj = ( lower ? std::set<t_elem>( sj_l.first, sj_l.second ) : std::set<t_elem>( sj_u.first, sj_u.second ) );
        std::set<t_elem> intersection;
        std::set_intersection( S.begin(), S.end(), sj.begin(), sj.end(), std::inserter( intersection, intersection.end() ) );
        S = intersection;
    }
    // Calculate the least edges (incoming or outgoing)
    t_elem bound = *S.begin();
    for( it_set = std::next( S.begin() ); it_set != S.end(); it_set++ ) {
        if( ( lower and boost::out_degree( *it_set, *m_rel ) < boost::out_degree( bound, *m_rel ) ) or
           ( ( not lower ) and boost::in_degree( *it_set, *m_rel ) < boost::in_degree( bound, *m_rel ) ) )
            bound = *it_set;
    }
    return vertexNames[bound];
}

template <class ELEM_TYPE>
void cs<ELEM_TYPE>::add_element( ELEM_TYPE elem, const std::vector<ELEM_TYPE>& lower, const std::vector<ELEM_TYPE>& upper ) {
     // Elements are a set (no duplicates)
    if( p_getElementNum( elem ) >= 0 )
        return;
    // Add the new element
    m_cons->push_back( elem );
    t_elem elemID = boost::add_vertex( elem, *m_rel );
    // Add its order relation
    // Same element
    boost::add_edge( elemID, elemID,  *m_rel );
    // Lower elements
    boost::add_edge( p_getElementNum( glb() ), elemID, *m_rel ); // bottom
    for( int i = 0; i < lower.size(); i++ )
        boost::add_edge( p_getElementNum( lower[i] ), elemID, *m_rel );
    // Upper elements
    boost::add_edge( elemID, p_getElementNum( lub() ), *m_rel ); // top
    for( int i = 0; i < upper.size(); i++ )
        boost::add_edge( elemID, p_getElementNum( upper[i] ), *m_rel );
    // Transitive closure
    t_relation trans_closure;
    boost::transitive_closure( *m_rel, trans_closure );
    // Copy properties (name of elements) to transitive closure
    for( int i = 0; i < m_cons->size(); i++ )
        boost::put( boost::vertex_name, trans_closure, i, (*m_cons)[i] );
    m_rel->clear();
    boost::copy_graph( trans_closure, *m_rel );
}

template <class ELEM_TYPE>
bool cs<ELEM_TYPE>::leq( ELEM_TYPE elem1, ELEM_TYPE elem2 ) {
    return boost::edge( p_getElementNum( elem1 ), p_getElementNum( elem2 ), *m_rel ).second;
}

template <class ELEM_TYPE>
ELEM_TYPE cs<ELEM_TYPE>::glb( const std::vector<ELEM_TYPE>& elems ) {
    std::set<t_elem> D;
    std::for_each( elems.begin(), elems.end(), [&D,this] (ELEM_TYPE e) { D.insert( p_getElementNum( e ) ); } );
    return bound( D, true );
}

template <class ELEM_TYPE>
ELEM_TYPE cs<ELEM_TYPE>::lub( const std::vector<ELEM_TYPE>& elems ) {
    std::set<t_elem> D;
    std::for_each( elems.begin(), elems.end(), [&D,this] (ELEM_TYPE e) { D.insert( p_getElementNum( e ) ); } );
    return bound( D, false );
}

template <class ELEM_TYPE>
ELEM_TYPE cs<ELEM_TYPE>::imp( ELEM_TYPE elem1, ELEM_TYPE elem2 ) {
    // Trivial case
    if( leq( elem2, elem1 ) ) // c >= d
        return glb(); // true
    // Types
    typedef typename boost::graph_traits<t_relation>::adjacency_iterator adj_it;
    typedef typename boost::inv_adjacency_iterator_generator<t_relation>::type inv_adj_it;
    typename std::set<t_elem>::iterator it;
    // Elements
    t_elem c  = p_getElementNum( elem1 );
    t_elem d  = p_getElementNum( elem2 );
    // Cons (all elements must be handled as ID's)
    std::vector<t_elem> V( m_cons->size() );
    std::iota( std::begin(V), std::end(V), 0 );
    std::set<t_elem> cons( V.begin(), V.end() );
    // S, D and E
    std::set<t_elem> S, D, E;
    E.insert( d ); // d is always considered
    // Calculate D -- d^u if it's not a negation and (c^u - false)^l otherwise --
    if( d != p_getElementNum( lub() ) ) { // d =/= false
        // d_u
        std::pair<adj_it, adj_it> d_u = boost::adjacent_vertices( d, *m_rel );
        D = std::set<t_elem>( d_u.first, d_u.second );
    } else { // it's a negation
        std::pair<adj_it, adj_it> c_u = boost::adjacent_vertices( c, *m_rel );
        std::set<t_elem> C_U = std::set<t_elem>( c_u.first, c_u.second );
        C_U.erase( d ); // c^u - false
        for( it = C_U.begin(); it != C_U.end(); it++ ) {
            std::pair<inv_adj_it, inv_adj_it> eu = boost::inv_adjacent_vertices( *it, *m_rel );
            std::set<t_elem> E;
            std::set_union( D.begin(), D.end(), eu.first, eu.second,  std::inserter( E, E.end() ) );
            D = E;
        }
    }
    // S = Cons - D
    std::set_difference( cons.begin(), cons.end(), D.begin(), D.end(), std::inserter( S, S.end() ) );
    // E = { e | e ⨆ c >= d }
    for( it = S.begin(); it != S.end(); it++ )
        if( leq( elem2, bound( { c, *it }, false ) ) )
            E.insert( *it );
    return bound( E, true );
}

template <class ELEM_TYPE>
bool cs<ELEM_TYPE>::is_distributive( void ) {
    bool distributive = true;
    for( int a = 0; a < m_cons->size(); a++ ) {
	for( int b = 0; b < m_cons->size(); b++ ) {
	    if( a == b ) // Absortion law a ⨆ (a ⨅ b) = a
		continue;
	    for( int c = b + 1; c < m_cons->size(); c++ ) { // Commutative law a ⨅ b = b ⨅ a and Idempotency law a ⨅ a = a
		if( a == c ) // Absortion law
		    continue;
		ELEM_TYPE A = m_cons->at( a );
		ELEM_TYPE B = m_cons->at( b );
		ELEM_TYPE C = m_cons->at( c );
		ELEM_TYPE A_BC  = lub({A, glb({B, C}) });
		ELEM_TYPE AB_AC = glb({lub({A, B}), lub({A, C})});
		if( A_BC != AB_AC ) {
		    std::cerr << a << " u (" << b << " n " << c << ") = " << p_getElementNum( A_BC ) << " =/= " << p_getElementNum( AB_AC ) << " = (" << a << " u " << b << ") n (" << a << " u " << c << ")" << std::endl;
		    distributive = false;
		}
	    }
	}
    }
    return distributive;
}

template <class ELEM_TYPE>
void cs<ELEM_TYPE>::print_cons( const std::function<void(ELEM_TYPE)>& printer ) { // std::function<return_type(param1,param2,...)>
    int i = 0;
    std::cout << "Cons:" << std::endl;
    std::for_each( m_cons->begin(), m_cons->end(), [&printer, &i] (ELEM_TYPE e) { std::cout << "(" << i++ << ")"; printer(e); std::cout << " "; } ); // [values_to_capture] (param1,param2) -> return_type { function_body; }
    std::cout << std::endl;
}

template <class ELEM_TYPE>
void cs<ELEM_TYPE>::print_relation( bool inverted ) {
    std::cout << "Relation" << ( inverted ? "_inv:" : ":" ) << std::endl;
    if( inverted )
        boost::print_graph( boost::make_reverse_graph( *m_rel ), boost::get( boost::vertex_index, *m_rel ) );
    else
        boost::print_graph( *m_rel, boost::get( boost::vertex_index, *m_rel ) );
}

// Each instance of CS has to be declared
template class cs<int>;
template class cs<std::vector<int>>;
template class cs<std::set<int>>;
template class cs<char>;
template class cs<std::vector<char>>;
template class cs<std::set<char>>;
template class cs<std::string>;
template class cs<std::vector<std::string>>;
template class cs<std::set<std::string>>;
template class cs<std::pair<std::string,int>>;
template class cs<std::vector<std::pair<std::string,int>>>;
template class cs<std::set<std::pair<std::string,int>>>;
