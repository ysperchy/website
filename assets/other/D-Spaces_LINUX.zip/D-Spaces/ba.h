//
//  ba.h
//  D-Spaces
//
//  Created by Salim PERCHY on 18/02/2016.
//
//

/*!
 *  @header Powerset Boolean Algebra
 *  @abstract A Boolean Algebra (BA for short) is a distributive lattice with operations for conjunction, disjunction and negation. A Powerset BA is a specific case of a BA where its lattice is the powerset lattice of a set of elements called 'atoms'.
 *  @discussion A BA is a tuple ⟨B, ∧, ∨, ', 1, 0⟩ where
 *
 *  ⟨B, ∧, ∨⟩     : A distributive lattice
 *
 *  a ∨ 0  = a   and     a ∧ 1  = a                   (for all a ∈ B)
 *
 *  a ∨ a' = 1   and     a ∧ a' = 0                   (for all a ∈ B)
 *
 *  The Powerset BA is also a specific case of a @link //apple_ref/cpp/cl/scse SCSE @/link where
 *
 *  B = P(atoms)                                        (atoms is a set of elements)
 *
 *  ∧ = ⨆ = ∪ (or ∩ if the powerset lattice is inverted)
 *
 *  ∨ = ⨅ = ∩ (or ∪ if inverted)
 *
 *  ' = → ⊤
 *
 *  1 = ⊤ = atoms (or ∅ if inverted)
 *
 *  0 = ⊥ = ∅ (or atoms if inverted)
 *  @author Salim PERCHY
 *  @updated 2016-03-04
 */

#ifndef __D_Spaces__ba__
#define __D_Spaces__ba__

#include "scse.h"

/*!
 *  @class ba
 *  @abstract The Powerset Boolean Algebra
 *  @discussion Class implementing a Powerset Boolean Algebra. It uses an @link //apple_ref/cpp/cl/scse SCSE @/link object as its underlying distributive lattice.
 *  @seealso https://en.wikipedia.org/wiki/Boolean_algebra_(structure)
 */
template <class ELEM_TYPE>
class ba {
    
public:
    /*!
     *  @var m_n
     *  Number of space/extrusion functions.
     */
    unsigned int m_n;
    
    /*!
     *  @var m_atoms
     *  Set of elements constructing the powerset lattice.
     */
    std::set<ELEM_TYPE> m_atoms;
    
    /*!
     *  @var m_elems
     *  Elements of the powerset lattice (Cons).
     */
    std::set< std::set<ELEM_TYPE> > m_elems;
    
    /*!
     *  @var m_scse
     *  SCSE representing the underlying distributive lattice of the Powerset BA.
     */
    scse< std::set<ELEM_TYPE> > m_scse;
    
    /*!
     *  @function ba
     *  @abstract Constructor.
     *  @discussion This constructor will build a Powerset BA (inverted depending on the last parameter) from the set <code>atoms</code> with <code>n</code> space/extrusion functions.
     *  @attribute Complexity
     *      2<sup>n</sup> where n is the number of atoms.
     *  @param atoms
     *      set of elements to build the powerset lattice.
     *  @param n
     *      number of space/extrusion functions.
     *  @param inverted
     *      <code>true</code> ⊥ = atoms, ⊤ = ∅, ⨆ = ∩, ⨅ = ∪ and <code>false</code> ⊥ = ∅, ⊤ = atoms, ⨆ = ∪, ⨅ = ∩
     */
    ba( std::vector<ELEM_TYPE> atoms, unsigned int n = 1, bool inverted = false );

    /*!
     *  @function ba
     *  @abstract Copy Constructor.
     *  @attribute Complexity
     *      Constant.
     *  @param BA
     *      already instantiated BA.
     */
    ba( const ba<ELEM_TYPE>& BA );
    
    /*!
     *  @function ~ba
     *  @abstract Destructor.
     *  @attribute Complexity
     *      Constant.
     */
    ~ba( void );

    /*!
     *  @function map_s
     *  @abstract Mapping of the space function.
     *  @discussion Maps the elements of the powerset according to a user-defined space function.
     *  @attribute Complexity
     *      2<sup>n</sup> where n is the number of atoms.
     *  @attribute s_func
     *      a function with three parameters; an integer representing the index of the space function, a set representing the element to map and a set representing the atoms. The result is a set (the image of the element being mapped).
     *  @param e_func
     *      one of @link E_CHOICE_FUNCTION @/link. The elements will be mapped according to the extrusion function option given here.
     */
    void map_s( const std::function<std::set<ELEM_TYPE>(int, std::set<ELEM_TYPE>, std::set<ELEM_TYPE>)>& s_func, typename scse< std::set<ELEM_TYPE> >::E_CHOICE_FUNCTION e_func = scse< std::set<ELEM_TYPE> >::E_CHOICE_FUNCTION::EC_MANUAL );

    /*!
     *  @function map_e
     *  @abstract Mapping of the extrusion function.
     *  @discussion Maps the elements of the powerset according to a user-defined extrusion function.
     *  @attribute Complexity
     *      2<sup>n</sup> where n is the number of atoms.
     *  @attribute e_func
     *      a function with three parameters; an integer representing the index of the extrusion function, a set representing the element to map and a set representing the atoms. The result is a set (the image of the element being mapped).
     */
    void map_e( const std::function<std::set<ELEM_TYPE>(int, std::set<ELEM_TYPE>, std::set<ELEM_TYPE>)>& e_func );
};

#endif /* defined(__D_Spaces__ba__) */

