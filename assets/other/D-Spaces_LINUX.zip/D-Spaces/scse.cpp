//
//  scse.cpp
//  D-Spaces
//
//  Created by Salim PERCHY on 27/11/14.
//
//

#include "scse.h"

template <class ELEM_TYPE>
scse<ELEM_TYPE>::scse( const scs<ELEM_TYPE>& SCS, E_CHOICE_FUNCTION e_choice ) : scs<ELEM_TYPE>( SCS ) {
    e_func.resize( scs<ELEM_TYPE>::s_func.size(), std::map<ELEM_TYPE, ELEM_TYPE>() );
    for( int i = 0; i < scs<ELEM_TYPE>::s_func.size(); i++ )
        for( int j = 0; j < cs<ELEM_TYPE>::m_cons->size(); j++ ) {
            ELEM_TYPE c = (*cs<ELEM_TYPE>::m_cons)[j];
            switch( e_choice ) {
                case E_CHOICE_FUNCTION::EC_SUPREMA:
                    e_func[i][c] = cs<ELEM_TYPE>::lub( scs<ELEM_TYPE>::s_inv( i+1, c ) );
                    continue;
                case E_CHOICE_FUNCTION::EC_INFIMA:
                    e_func[i][c] = cs<ELEM_TYPE>::glb( scs<ELEM_TYPE>::s_inv( i+1, c ) );
                    continue;
                case E_CHOICE_FUNCTION::EC_RANDOM: {
                    std::vector<ELEM_TYPE> pre_img = scs<ELEM_TYPE>::s_inv( i+1, c ); // Pre-image
                    if( pre_img.size() == 0 ) continue; // No elements to choose from
                    // Choose a random element
                    std::random_device rd; // device
                    std::default_random_engine re(rd()); // engine
                    std::uniform_int_distribution<int> rg( 0, pre_img.size() - 1 ); // generator
                    e_func[i][c] = pre_img[rg(re)];
                    continue;
                }
                case E_CHOICE_FUNCTION::EC_MANUAL:
                    return;
                default:
                    return;
            }
        }
}

template <class ELEM_TYPE>
scse<ELEM_TYPE>::scse( const scse<ELEM_TYPE>& SCSE ) : scs<ELEM_TYPE>( SCSE ) {
    e_func = SCSE.e_func;
}

template <class ELEM_TYPE>
scse<ELEM_TYPE>::~scse( void ) = default;

template <class ELEM_TYPE>
void scse<ELEM_TYPE>::e_map( unsigned int i, std::vector<ELEM_TYPE> elems, ELEM_TYPE image ) {
    for( int j = 0; j < elems.size(); j++ )
        if( std::find( cs<ELEM_TYPE>::m_cons->begin(), cs<ELEM_TYPE>::m_cons->end(), elems[j] ) != cs<ELEM_TYPE>::m_cons->end() and
            std::find( cs<ELEM_TYPE>::m_cons->begin(), cs<ELEM_TYPE>::m_cons->end(), image    ) != cs<ELEM_TYPE>::m_cons->end() )
            e_func[i-1][elems[j]] = image;
}

template <class ELEM_TYPE>
ELEM_TYPE scse<ELEM_TYPE>::e( unsigned int i, ELEM_TYPE c ) {
    return e_func[i-1].at(c);
}

template <class ELEM_TYPE>
std::vector<ELEM_TYPE> scse<ELEM_TYPE>::e_inv( unsigned int i, ELEM_TYPE c ) {
    std::vector<ELEM_TYPE> inv_image;
    typename std::map<ELEM_TYPE,ELEM_TYPE>::const_iterator it;
    for( it = e_func[i-1].begin(); it != e_func[i-1].end(); it++ )
        if( it->second == c )
            inv_image.push_back( it->first );
    return inv_image;
}

template <class ELEM_TYPE>
bool scse<ELEM_TYPE>::e_properties( unsigned int i, E_FUNCTION_PROPERTY property ) {
    switch( property ) {
        case E_FUNCTION_PROPERTY::EP_TOTAL:
            return scs<ELEM_TYPE>::f_properties( i, "e", e_func[i-1], scs<ELEM_TYPE>::FUNCTION_PROPERTY::FP_TOTAL );
        case E_FUNCTION_PROPERTY::EP_SURJECTIVE:
            return scs<ELEM_TYPE>::f_properties( i, "e", e_func[i-1], scs<ELEM_TYPE>::FUNCTION_PROPERTY::FP_SURJECTIVE );
        case E_FUNCTION_PROPERTY::EP_INJECTIVE:
            return scs<ELEM_TYPE>::f_properties( i, "e", e_func[i-1], scs<ELEM_TYPE>::FUNCTION_PROPERTY::FP_INJECTIVE );
        case E_FUNCTION_PROPERTY::EP_BIJECTIVE:
            return scs<ELEM_TYPE>::f_properties( i, "e", e_func[i-1], scs<ELEM_TYPE>::FUNCTION_PROPERTY::FP_BIJECTIVE );
        case E_FUNCTION_PROPERTY::EP_JOIN_DISTRIBUTIVE:
            return scs<ELEM_TYPE>::f_properties( i, "e", e_func[i-1], scs<ELEM_TYPE>::FUNCTION_PROPERTY::FP_JOIN_DISTRIBUTIVE );
        case E_FUNCTION_PROPERTY::EP_MEET_DISTRIBUTIVE:
            return scs<ELEM_TYPE>::f_properties( i, "e", e_func[i-1], scs<ELEM_TYPE>::FUNCTION_PROPERTY::FP_MEET_DISTRIBUTIVE );
        case E_FUNCTION_PROPERTY::EP_RIGHT_INVERSE_S: {
            bool right_inverse = true;
            for( int j = 0; j < cs<ELEM_TYPE>::m_cons->size(); j++ ) {
                ELEM_TYPE c = (*cs<ELEM_TYPE>::m_cons)[j];
                if( !e_func[i-1].count( c ) ) {
                    std::cerr << "e_" << i << "(" << j << ") NOT defined" << std::endl;
                    right_inverse = false;
                } else {
                    ELEM_TYPE ec = e( i, c );
                    if( !scs<ELEM_TYPE>::s_func[i-1].count( ec ) ) {
                        std::cerr << "s_" << i << "(e_" << i << "(" << j << ")=" << cs<ELEM_TYPE>::p_getElementNum( ec ) << ") NOT defined" << std::endl;
                        right_inverse = false;
                    } else {
                        ELEM_TYPE sec = scs<ELEM_TYPE>::s( i, ec );
                        if( sec != c ) {
                            std::cerr << "s_" << i << "(e_" << i << "(" << j << ")=" << cs<ELEM_TYPE>::p_getElementNum( ec ) << ") = " << cs<ELEM_TYPE>::p_getElementNum( sec ) << " =/= " << j << std::endl;
                            right_inverse = false;
                        }
                    }
                }
            }
            return right_inverse;
        }
        default:
            return true;
    }
}

template <class ELEM_TYPE>
void scse<ELEM_TYPE>::print_efunc( unsigned int i ) {
    scs<ELEM_TYPE>::print_func( i, "e", e_func[i-1] );
}

template class scse<int>;
template class scse<std::vector<int>>;
template class scse<std::set<int>>;
template class scse<char>;
template class scse<std::vector<char>>;
template class scse<std::set<char>>;
template class scse<std::string>;
template class scse<std::vector<std::string>>;
template class scse<std::set<std::string>>;
template class scse<std::pair<std::string,int>>;
template class scse<std::vector<std::pair<std::string,int>>>;
template class scse<std::set<std::pair<std::string,int>>>;
