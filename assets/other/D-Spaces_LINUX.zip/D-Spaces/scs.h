//
//  scs.h
//  D-Spaces
//
//  Created by Salim PERCHY on 25/11/14.
//
//

/*!
 *  @header Spatial Constraint System
 *  @abstract A Spatial Constraint System (SCS for short) is a constraint system equipped with n spatial functions on its set of elements. Each map satifies two axioms; it is strict (see S.1) and it distributes over finite joins (see S.2).
 *  @discussion A SCS is a tuple ⟨CS, s₁, ..., s<sub>n</sub>⟩ where
 *
 *  CS      : A Constraint System.
 *
 *  sᵢ      : A strict ⨆-distributive self map (also called a space function) on the elements of the CS satisfying
 *
 *      - S.1       sᵢ(⊥) = ⊥                   (emptiness)
 *
 *      - S.2       sᵢ(c ⨆ d) = sᵢ(c) ⨆ sᵢ(d)   (distribution)
 *  @author Salim PERCHY
 *  @updated 2016-01-25
 */

#ifndef __D_Spaces__scs__
#define __D_Spaces__scs__

#include "cs.h"

/*!
 *  @class scs
 *  @abstract The Spatial Constraint System class.
 *  @discussion Derived constraint systems inherit the functionality of this class. It implements spatial functions with property-checking on them. (Note: Function indexes are positive non-zero numbers).
 *  @seealso https://hal.archives-ouvertes.fr/hal-00761116/document
 */
template <class ELEM_TYPE>
class scs : public cs<ELEM_TYPE> {
protected:
    /*!
     *  @var s_func
     *  Vector containing the space functions of the CS.
     */
    std::vector< std::map<ELEM_TYPE, ELEM_TYPE> > s_func; // > > need to be separated for HeaderDoc to work!
    
    /*!
     *  @typedef FUNCTION_PROPERTY
     *  @abstract Enumeration of possible properties of a function.
     *  @discussion can be
     *
     *      - FP_TOTAL: function is total (i.e. every domain element is mapped).
     *
     *      - FP_SURJECTIVE: function is surjective (i.e. every codomain element is mapped to, also called onto).
     *
     *      - FP_INJECTIVE: function is injective (i.e. at most one element of the domain is mapped to an element of the codamin, also called a one-to-one function).
     *
     *      - FP_BIJECTIVE: function is bijective (i.e. function is injective and surjective, a one-to-one correspondence).
     *
     *      - FP_JOIN_DISTRIBUTIVE: function distributes over finite joins (i.e. it satisfies S.2).
     *
     *      - FP_MEET_DISTRIBUTIVE: function distributes over finite meets (i.e. it satisfies sᵢ(c ⨅ d) = sᵢ(c) ⨅ sᵢ(d) for every element c and d of the CS).
     */
    enum class FUNCTION_PROPERTY { FP_TOTAL, FP_SURJECTIVE, FP_INJECTIVE, FP_BIJECTIVE, FP_JOIN_DISTRIBUTIVE, FP_MEET_DISTRIBUTIVE };
    
    /*!
     *  @function f_properties
     *  @abstract Checks whether a function satisfies a certain property.
     *  @attribute Complexity
     *      O(n) if <code>property = FP_TOTAL</code> and O(n²) otherwise.
     *  @param i
     *      the index of the function.
     *  @param name
     *      the name (for message output purposes) of the function.
     *  @param map
     *      the function as a map structure.
     *  @param property
     *      one of @link FUNCTION_PROPERTY @/link.
     *  @result
     *      <code>true</code> if the function satisfies the property, <code>false</code> otherwise.
     */
    bool f_properties( unsigned int i, std::string name, std::map<ELEM_TYPE, ELEM_TYPE> map, FUNCTION_PROPERTY property );
    
    /*!
     *  @function print_func
     *  @abstract Generic printer for an STL map structure.
     *  @attribute Complexity
     *      O(n) where n is the number of elements of the CS.
     *  @param i
     *      the index of the function.
     *  @param name
     *      the name (for message output purposes) of the function.
     *  @param map
     *      the function as a map structure.
     */
    void print_func( unsigned int i, std::string name, std::map<ELEM_TYPE, ELEM_TYPE> map );
    
public:
    /*!
     *  @function scs
     *  @abstract Constructor.
     *  @discussion This constructor will automatically map the global infima to itself in all space functions. This means that the axiom of emptiness S.1 will be automtically satisfied at creation.
     *  @attribute Complexity
     *      Constant.
     *  @param CS
     *      a CS
     *  @param n
     *      number of space functions
     */
    scs ( const cs<ELEM_TYPE>& CS, unsigned int n = 1 );
    
    /*!
     *  @function scs
     *  @abstract Copy Constructor.
     *  @attribute Complexity
     *      Constant.
     *  @param SCS
     *      already instantiated SCS.
     */
    scs ( const scs<ELEM_TYPE>& SCS );
    
    /*!
     *  @function ~scs
     *  @abstract Destructor.
     *  @attribute Complexity
     *      Constant.
     */
    ~scs( void );
    
    /*!
     *  @function s_map
     *  @abstract sᵢ(<code>elems</code>) = <code>image</code>.
     *  @discussion The function will do nothing if the elements or the image are not in the elements of the CS.
     *  @attribute Complexity
     *      O(n) where n is the number of elements to map.
     *  @param i
     *      index of the space function.
     *  @param elems
     *      elements to map.
     *  @param image
     *      image to map elements to.
     */
    void s_map( unsigned int i, std::vector<ELEM_TYPE> elems, ELEM_TYPE image );
    
    /*!
     *  @function s
     *  @abstract Gets the image of element <code>c</code> in the space function <code>i</code>.
     *  @attribute Complexity
     *      Constant.
     *  @param i
     *      index of the space function.
     *  @param c
     *      element to retrieve its image.
     *  @result
     *      sᵢ(c)
     */
    ELEM_TYPE s( unsigned int i, ELEM_TYPE c );
    
    /*!
     *  @function s_inv
     *  @abstract Gets the inverse image of element <code>c</code> in the space function <code>i</code>.
     *  @attribute Complexity
     *      O(n) where n is the number of elements of the CS.
     *  @param i
     *      index of the space function startin
     *  @param c
     *      element to retrieve its fiber.
     *  @result
     *      sᵢ<sup>-1</sup>(c)
     */
    std::vector<ELEM_TYPE> s_inv( unsigned int i, ELEM_TYPE c );
    
    /*!
     *  @typedef S_FUNCTION_PROPERTY
     *  @abstract Enumeration of possible properties of a space function.
     *  @discussion each property has a one-on-one correspondance with the properties specified in @link FUNCTION_PROPERTY @/link
     */
    enum class S_FUNCTION_PROPERTY { SP_TOTAL, SP_SURJECTIVE, SP_INJECTIVE, SP_BIJECTIVE, SP_JOIN_DISTRIBUTIVE, SP_MEET_DISTRIBUTIVE };
    
    /*!
     *  @function s_properties
     *  @abstract Checks whether the space function <code>i</code> satisfies certain property.
     *  @attribute Complexity
     *      O(n) if <code>property = SP_TOTAL</code> and O(n²) otherwise.
     *  @param i
     *      the index of the space function.
     *  @param property
     *      one of @link S_FUNCTION_PROPERTY @/link.
     *  @result
     *      <code>true</code> if the space function satisfies the property, <code>false</code> otherwise. Prints to <code>std::cerr</code> the troublesome elements' ID's.
     */
    bool s_properties( unsigned int i, S_FUNCTION_PROPERTY property );
    
    /*!
     *  @function print_sfunc
     *  @abstract Prints (on <code>std::cout</code>) the space function <code>i</code> using elements' ID's.
     *  @attribute Complexity
     *      O(n) where n is the number of elements of the CS.
     *  @param i
     *      the index of the space function.
     */
    void print_sfunc( unsigned int i );
};

#endif /* defined(__D_Spaces__scs__) */
