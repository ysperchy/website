//
//  cs.h
//  D-Spaces
//
//  Created by Salim PERCHY on 07/11/14.
//
//

/*!
 *  @header Constraint System
 *  @abstract A Constraint System (CS for short) is a complete algebraic lattice, where its elements represent information.
 *  @discussion A CS is a tuple ⟨cons, cons₀, ⊑, ⨆, ⨅, true, false⟩ where
 *
 *  cons    : Set of elements of the CS.
 *
 *  cons₀   : Set of compact elements of the CS. Cons₀ ⊆ Cons. -- NOT YET IMPLEMENTED --
 *
 *  ⊑       : Ordering binary relation (reflexive, antisymmetric and transitive). When c ⊑ d we say c is entailed by d and d entails c.
 *
 *  ⨆       : Join set operator. Least Upper Bound (LUB) between elements of the CS.
 *
 *  ⨅       : Meet set operator. Greatest lower bound (GLB) between elements of the CS.
 *
 *  ⊥       : Global infima of CS, also called the bottom. All elements entail it.
 *
 *  ⊤       : Global suprema of CS, also called the top. All elements are entailed by it.
 *  @author Salim PERCHY
 *  @updated 2016-01-25
 */

#ifndef __D_Spaces__cs__
#define __D_Spaces__cs__

#include <iostream>
#include <vector>
#include <deque>
#include <map>
#include <algorithm>
#include <functional>
#include <random>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/transitive_closure.hpp>
#include <boost/graph/graph_utility.hpp>
#include <boost/graph/copy.hpp>

/*!
 *  @class cs
 *  @abstract The Constraint System base class.
 *  @discussion Other derived constraint systems inherit the functionality of this class. It implements the entailment, meet, join and implication operators. It heavily relies on the boost graph implementation.
 *  @seealso http://www.boost.org/doc/libs/1_60_0/libs/graph/doc/index.html
 */
template <class ELEM_TYPE>
class cs {
protected:
    /*!
     *  @typedef t_relation
     *  Type for the ordering relation. Basically it is a graph representing the ordering relation's transitive closure.
     *  @seealso http://www.boost.org/doc/libs/1_60_0/libs/graph/doc/adjacency_list.html
     */
    typedef typename boost::adjacency_list< boost::listS, boost::vecS, boost::bidirectionalS, boost::property<boost::vertex_name_t, ELEM_TYPE> > t_relation; // > > need to be separated for HeaderDoc to work!
    
    /*!
     *  @typedef t_elem
     *  Type for the identifiers of the elements in the constraint system. Currently, it is equivalent to <code>int</code>.
     */
    typedef typename boost::graph_traits<t_relation>::vertex_descriptor t_elem;
    
    /*!
     *  @var m_cons
     *  Queue of the elements of the constraint system.
     */
    std::deque<ELEM_TYPE>* m_cons;
    
    /*!
     *  @var m_rel
     *  Graph representing the ordering relation.
     */
    t_relation* m_rel;
    
    /*!
     *  @function p_getElementNum
     *  @abstract Retrives the identifier of an element in the constraint system.
     *  @attribute Complexity
     *      O(n) where n is the number of elements of the CS.
     *  @param elem
     *      element of the constraint system.
     *  @result
     *      element's identifier, negative if not found.
     */
    int p_getElementNum( ELEM_TYPE elem );
    
    /*!
     *  @function bound
     *  @abstract Calculates either GLB( <code>elems</code> ) or LUB( <code>elems</code> ).
     *  @attribute Complexity
     *      O(n²) where n is the number of elements of the CS.
     *  @param elems
     *      set of elements for bound calculation.
     *  @param lower
     *      <code>true</code> to calculate GLB, <code>false</code> to calculate LUB.
     *  @result
     *      calculated bound.
     */
    ELEM_TYPE bound( const std::set<t_elem>& elems, bool lower );
    
public:
    /*!
     *  @function cs
     *  @abstract Constructor.
     *  @attribute Complexity
     *      Constant.
     *  @param bottom
     *      bottom of the CS.
     *  @param top
     *      top of the CS.
     */
    cs ( ELEM_TYPE bottom, ELEM_TYPE top );
    
    /*!
     *  @function cs
     *  @abstract Copy Constructor.
     *  @attribute Complexity
     *      Constant.
     *  @param CS
     *      already instantiated CS.
     */
    cs ( const cs<ELEM_TYPE>& CS );

    /*!
     *  @function ~cs
     *  @abstract Destructor.
     *  @attribute Complexity
     *      Constant.
     */
    ~cs ( void );
    
    /*!
     *  @function add_element
     *  @abstract Adds an element to the CS where <code>lower</code> ⊑ <code>elem</code> ⊑ <code>upper</code>.
     *  @discussion This function adds an element to the constraint system where the set of elements <code>lower</code> is directly related to the element and the element itself is related to the set of elements <code>upper</code>. It performs a transitive closure on the ordering relation for complexity advantages in the operators of the CS.
     *  @attribute Complexity
     *      O(n³) where n is the number of elements in the CS.
     *  @param elem
     *      element to add to the CS.
     *  @param lower
     *      elements immediately entailed (in the ordering relation) by the element to be added. If none are given, the global infima of the CS is entailed by the element.
     *  @param upper
     *      elements immediately entailing (in the ordering relation) the element to be added. If none are given, the element is entiled by the global suprema of the CS.
     */
    void add_element( ELEM_TYPE elem, const std::vector<ELEM_TYPE>& lower = std::vector<ELEM_TYPE>(), const std::vector<ELEM_TYPE>& upper = std::vector<ELEM_TYPE>() );

    /*!
     *  @function leq
     *  @abstract Tests if <code>elem1</code> ⊑ <code>elem2</code>.
     *  @attribute Complexity
     *      Constant.
     *  @param elem1
     *      element to be tested againts the other.
     *  @param elem2
     *      element to be tested against the other.
     *  @result
     *      <code>true</code> if <code>elem1</code> ⊑ <code>elem2</code>, <code>false</code> otherwise.
     */
    bool leq( ELEM_TYPE elem1, ELEM_TYPE elem2 );
    
    /*!
     *  @function lub
     *  @abstract Calculates LUB( <code>elems</code> )
     *  @attribute Complexity
     *      Same as @link bound @/link.
     *  @param elems
     *      elements to calculate their Least Upper Bound. If none are given then the global suprema is calculated.
     *  @result
     *      ⨆(<code>elems</code>). If <code>elems</code> = ∅, the result is ⊤.
     */
    ELEM_TYPE lub( const std::vector<ELEM_TYPE>& elems = std::vector<ELEM_TYPE>() );
    
    /*!
     *  @function glb
     *  @abstract Calculates GLB( <code>elems</code> )
     *  @attribute Complexity
     *      Same as @link bound @/link.
     *  @param elems
     *      elements to calculate their Greatest Lower Bound. If none are given then the global infima is calculated.
     *  @result
     *      ⨅(<code>elems</code>). If <code>elems</code> = ∅, the result is ⊥.
     */
    ELEM_TYPE glb( const std::vector<ELEM_TYPE>& elems = std::vector<ELEM_TYPE>() );
    
    /*!
     *  @function imp
     *  @abstract Calculates the element <code>elem1</code> → <code>elem2</code> in the CS.
     *  @discussion The definition of implication used here is the Heyting implication defined as c → d = ⨅{ e | c ⨆ e ⊒ d }. If d = ⊤ the result of the implication is ~c.
     *  @attribute Complexity
     *      O(n³) where n is the number of elements of the CS.
     *  @param elem1
     *      antecedent.
     *  @param elem2
     *      consequent.
     *  @result
     *      <code>elem1</code> → <code>elem2</code>.
     */
    ELEM_TYPE imp( ELEM_TYPE elem1, ELEM_TYPE elem2 );

    /*!
     *  @function is_distributive
     *  @abstract Checks if the lattice is distributive.
     *  @discussion A lattice is distributive iff for all elements a, b and c the following holds; a ⨆ (b ⨅ c) = (a ⨆ b) ⨅ (a ⨆ c). Distributivity is necessary for <i>modus ponens</i> (i.e. c ⨆ (c → d) ⊒ d).
     *  @attribute Complexity
     *      O(n³) where n is the number of elements of the CS.
     *  @result
     *      <code>true</code> if the lattice is distributive and <code>false</code> otherwise.
     */
    bool is_distributive( void );
    
    /*!
     *  @function print_cons
     *  @abstract Prints (on the standard output) the elements of the CS along with its identifier (in parenthesis).
     *  @attribute Complexity
     *      O(n) where n is the number of elements of the CS.
     *  @attribute printer
     *      a process that takes one element of the CS and prints it. it is mean to be passed as a parameter.
     */
    void print_cons( const std::function<void(ELEM_TYPE)>& printer );
    
    /*!
     *  @function print_relation
     *  @abstract Prints (on the standard output) the ordering relation or its inverse.
     *  @attribute Complexity
     *      O(n²) where n is the number of elements of the CS.
     *  @param inverse
     *      <code>false</code> to print the ordering relation, <code>true</code> to print its inverse
     */
    void print_relation( bool inverse = false );
};

#endif /* defined(__D_Spaces__cs__) */
