//
//  ltl.cpp
//  D-Spaces
//
//  Created by Salim PERCHY on 28/03/2017.
//
//

#include "ba.h"

/***********
 DISCLAIMER:
 Turn ON Target Membership ONLY on this file
 if you want to execute this demo
 ************/

typedef std::set<std::pair<std::string,int>> CS_TYPE; // Herbrand cs element type: (var, val) where var = val

// Stepping function: Updates the run on the Herbrand cs
void step( scse<CS_TYPE>& hcs, int run, // Herbrand cs and run id
	   CS_TYPE& s,                  // Previous state
	   CS_TYPE& n,                  // Following state
	   std::string var, int val ) { // Variable assignment (i.e., var = val )
  // Remove previous assignment
  for( auto pair : n ) {
    if( pair.first == var )
      n.erase( pair );
  }
  n.insert( std::make_pair(var, val) );      // Modify following state according to assignment
  hcs.s_map( run, {s}, n );                  // Update next operation
  hcs.e_map( run, {n}, s) ;                  // Update previous operation
  s = n;                                     // Previous and following states are the same
}

template<typename... ArgTypes>
void evaluate( scse<CS_TYPE>& hcs, int run, ArgTypes... args ) {

  CS_TYPE state; // Current state
  CS_TYPE next;  // Following state

  #define STEP( Var ) step( hcs, run, state, next, #Var, (Var) )   // Necessesary macro to 'stringify' the variable name (i.e., #Var)
 

  ///////////// Program to test with LTL semantics ///////////
  //                                                        //
  // after every variable assigment, STEP should be called  //
  std::function<void(int,int)> program = [&hcs, run, &state, &next] ( int incr1, int incr2 ) {
    int a = 1;
    STEP(a);
    int b = 4;
    STEP(b);
    while( a < b ) {
      if( a % 2 == 0 )
	a = a + incr1;
      else
	a = a + incr2;
      STEP(a);
    }
    int c;
    if( a == b)
      c = 1;
    else
      c = 0;
    STEP(c);
  };
  //////////////////////////////////////////////////////////

  program( args... );
  hcs.s_map( run, {next}, next );
}

// Create the herbrand CS
cs<CS_TYPE> herbrand( std::vector<std::string> vars, std::pair<int,int> range ) {
  // Create the cs atoms
  std::vector<std::pair<std::string,int>> atoms;
  for( auto var : vars ) {
    for( int val = range.first; val <= range.second; val++ )
      atoms.push_back( std::make_pair(var, val) );
  }
  cs<std::set<std::pair<std::string,int>>> CS( CS_TYPE(),
					       CS_TYPE( atoms.begin(), atoms.end() ) );
    
  // Recursive Lambda Function to calculate positions from the atoms set to produce an element of the powerset
  std::function<void(std::vector<int>&,int,int)> next = [&next] ( std::vector<int>& v, int i, int n ) -> void {
    v[i]++;
    if( v[i] > ( n - 1 ) - ( v.size() - (i + 1) ) ) {
      next( v, i - 1, n );
      v[i] = v[i-1] + 1;
    }
  };
  // Function to determine if an element is already inconsistent
  std::function<bool(CS_TYPE&)> consistent = [] ( CS_TYPE& elem ) -> bool {
    std::set<std::string> vars;
    for( auto pair : elem ) {
      if( vars.find( pair.first) != vars.end() )
	return false; // found double assignment
      else
	vars.insert( pair.first );
    }
    return true; // no double assigments found
  };
  
  std::set<CS_TYPE> Si;       // Elements of length i-1 of powerset
  std::set<CS_TYPE> Sj;       // Elements of length i of powerset
  std::sort( atoms.begin(), atoms.end() );                 // Each element of the powerset is produced orderded by its positions in the atoms set (this avoids further sorting when determining bounds)
  std::vector<CS_TYPE> S = { CS_TYPE( atoms.begin(), atoms.end() ) };   // Top element
    
  // Produce the power set. Each iteration produces the elements of length i
  for( int i = 0; i <= atoms.size(); i++ ) { // i = 0 and i = len(atoms) won't be added to the lattice (they are repeated) but will be added to the elements
    std::vector<int> v(i); // Example (length 3, 5 elements) v = [0,1,2], [0,1,3], [0,1,4], [0,2,3], ..., [2,3,4]
    std::vector<int> w(i); // Example (length 3, 5 elements) w = [2,3,4]
    std::iota( std::begin(v), std::end(v), 0 );
    std::iota( std::begin(w), std::end(w), atoms.size() - i );
    while( true ) {
      CS_TYPE elem;
      std::vector<CS_TYPE> Se; // bounds (lower or upper) of element
      std::for_each( v.begin(), v.end(), [atoms,&elem] (int e) { elem.insert( atoms.at(e) ); } ); // actual element (not the positions in the atoms vector)
      if( consistent( elem ) ) {
	Sj.insert( elem );
	// Find the included elements of length i-1, i.e lower or upper (if lattice is inverted) bounds
	std::for_each( Si.begin(), Si.end(), [&Se,elem] (CS_TYPE e) {
	    if( std::includes( elem.begin(), elem.end(), e.begin(), e.end() ) )
	      Se.push_back( e );
	  } );
	  CS.add_element( elem, Se, S ); // Add to lattice
      }
      if( v != w ) // Next element of length i in powerset
	next( v, i - 1, atoms.size() );
      else // No elements of length i left to produce after last one
	break;
    }
    Si = Sj;
    Sj.clear();
  }
  return CS;
}

int main( int argc, const char* argv[] ) {
    std::cout << "--Application Example: Temporal Logic--" << std::endl << std::endl;
    int nRuns = 2;
    std::cout << "Number of runs:" << nRuns << std::endl;
    std::vector<std::string> vars = {"a", "b", "c"};
    std::cout << "Variables: ";
    std::for_each( vars.begin(), vars.end(), [] (std::string var) { std::cout << var << ", "; } );
    std::pair<int,int> range( 0, 5 );
    std::cout << std::endl << "Variable range: " << range.first << " - " << range.second << std::endl;
    std::cout << "Constructing the Herbrand constraint system..." << std::endl;
    scse<CS_TYPE> HCS(scs<CS_TYPE>( herbrand( vars, range ), nRuns ), scse<CS_TYPE>::E_CHOICE_FUNCTION::EC_MANUAL );
    HCS.print_cons( [] (CS_TYPE s) {
	std::cout << "{"; std::for_each( s.begin(), s.end(), [] (std::pair<std::string,int> p) {
	    std::cout << p.first << "=" << p.second << ","; } ); std::cout << "} "; } );
    HCS.print_relation();
    std::cout << "=====================" << std::endl;
    std::cout << "program (arg1, arg2):" << std::endl;
    std::cout << "\ta = 1" << std::endl;
    std::cout << "\tb = 4" << std::endl;
    std::cout << "\twhile (a < b)" << std::endl;
    std::cout << "\t\tif even(a) then" << std::endl;
    std::cout << "\t\t\ta = a + arg1" << std::endl;
    std::cout << "\t\tend" << std::endl;
    std::cout << "\t\tif odd(a) then" << std::endl;
    std::cout << "\t\t\ta = a + arg2" << std::endl;
    std::cout << "\t\tend" << std::endl;
    std::cout << "\tend" << std::endl;
    std::cout << "\tif (a == b) then" << std::endl;
    std::cout << "\t\tc = 1" << std::endl;
    std::cout << "\telse" << std::endl;
    std::cout << "\t\tc = 0" << std::endl;
    std::cout << "\tend" << std::endl;
    std::cout << "endprog" << std::endl;
    std::cout << "=====================" << std::endl;
    int cRun = 1;
    std::cout << "Run #" << cRun << " ... ";
    evaluate( HCS, cRun, 1, 2 ); // program arguments: 1, 2
    std::cout << "program(1,2) [done]" << std::endl;
    HCS.print_sfunc( cRun );
    HCS.print_efunc( cRun );
    
    // 1st property
    std::cout << std::endl << "1st Property:" << std::endl << "☐(b = 4)" << std::endl;
    CS_TYPE proposition;
    proposition.insert( std::make_pair("b", 4) );
    CS_TYPE answer = HCS.glb();
    CS_TYPE current_state;
    CS_TYPE next_state = HCS.s( cRun, HCS.s( cRun, HCS.glb() ) ); // The state when b is create
    do {
      current_state = next_state;
      answer = HCS.lub( { answer, ( HCS.leq( proposition, current_state ) ? HCS.glb() : HCS.lub() ) } );
      next_state = HCS.s( cRun, current_state );
    } while( next_state != current_state );
    std::cout << "Property '☐(b = 4)' is " << (answer == HCS.glb() ? "TRUE" : "FALSE") << std::endl;
    
    // 2nd property
    std::cout << std::endl << "2nd Property:" << std::endl << "⋄(c = 1)" << std::endl;
    proposition.clear();
    proposition.insert( std::make_pair("c", 1) );
    answer = HCS.lub();
    current_state.clear();
    next_state = HCS.glb(); // Initial state of execution
    do {
      current_state = next_state;
      answer = HCS.glb( { answer, ( HCS.leq( proposition, current_state ) ? HCS.glb() : HCS.lub() ) } );
      next_state = HCS.s( cRun, current_state );
    } while( next_state != current_state );
    std::cout << "Property '⋄(c = 1)' is " << (answer == HCS.glb() ? "TRUE" : "FALSE") << std::endl;
    
    // 2nd property - revisited
    std::cout << std::endl << "2nd Property - Revisited:" << std::endl << "⋄(c = 1)" << std::endl;
    cRun = 2;
    std::cout << "Run #" << cRun << " ... ";
    evaluate( HCS, cRun, 1, 1 ); // program arguments: 1, 1
    std::cout << "program(1,1) [done]" << std::endl;
    HCS.print_sfunc( cRun );
    HCS.print_efunc( cRun );
    proposition.clear();
    proposition.insert( std::make_pair("c", 1) );
    answer = HCS.lub();
    current_state.clear();
    next_state = HCS.glb(); // Initial state of execution
    do {
      current_state = next_state;
      answer = HCS.glb( { answer, ( HCS.leq( proposition, current_state ) ? HCS.glb() : HCS.lub() ) } );
      next_state = HCS.s( cRun, current_state );
    } while( next_state != current_state );
    std::cout << "Property '⋄(c = 1)' is " << (answer == HCS.glb() ? "TRUE" : "FALSE") << std::endl;
    return 0;
}
