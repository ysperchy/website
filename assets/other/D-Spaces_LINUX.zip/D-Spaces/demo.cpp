//
//  main.cpp
//  ESCCP
//
//  Created by Salim PERCHY on 07/11/14.
//
//


#include "ba.h"

/***********
 DISCLAIMER: 
 Turn ON Target Membership ONLY on this 
 file if you want to execute this demo
************/

int main( int argc, const char * argv[] ) {
    // cs
    std::cout << "#### Testing of Constraint Systems ####" << std::endl;
    std::cout << "\ncreating a constraint system..." << std::endl;
    cs<int> CS( 0, 8 );
    CS.add_element( 1 );
    CS.add_element( 2 );
    CS.add_element( 3, {1} );
    CS.add_element( 4, {2} );
    CS.add_element( 5, {3,4} );
    CS.add_element( 6, {5} );
    CS.add_element( 7, {5} );
    CS.print_cons( [] (int e) { std::cout << e; } );
    std::cout << std::endl;
    CS.print_relation( );
    std::cout << "\ntesting ordering..." << std::endl;
    std::cout << "\t3 ⊑ 4 : " << ( CS.leq( 3, 4 ) ? "true" : "false " ) << std::endl;
    std::cout << "\ncalculating some meet and join operations..." << std::endl;
    std::cout << "\t1 ⨆ 2 = " << CS.lub( {1, 2} ) << std::endl;
    std::cout << "\t6 ⨅ 7 = " << CS.glb( {6, 7} ) << std::endl;
    std::cout << "\ncalculating some implication operations..." << std::endl;
    std::cout << "\t4 → 2 = " << CS.imp( 4, 2 ) << std::endl;
    std::cout << "\t3 → 6 = " << CS.imp( 3, 6 ) << std::endl;
    std::cout << "\t1 → 4 = " << CS.imp( 1, 4 ) << std::endl;
    std::cout << "\t6 → 8 = " << CS.imp( 6, 8 ) << std::endl;
    std::cout << "\ntesting distributivity on the lattice...." << std::endl;
    bool distributive = CS.is_distributive();
    std::cout << "\tL is " << ( distributive ? "" : "NOT " ) << "distributive" << std::endl;
    // scs
    std::cout << "\n#### Testing of Spatial Constraint Systems ####" << std::endl;
    std::cout << "\ncreating a spatial constraint system..." << std::endl;
    scs<int> SCS( CS );
    std::cout << "\nmapping elements..." << std::endl;
    SCS.s_map( 1, {1}, 3 );
    SCS.s_map( 1, {2}, 4 );
    SCS.s_map( 1, {3,4,5}, 5 );
    SCS.s_map( 1, {5}, 9 ); // won't do anything
    SCS.print_sfunc( 1 );
    std::cout << "\ntesting the space function..." << std::endl;
    std::cout << "\ts₁(2) = " << SCS.s( 1, 2 ) << std::endl;
    std::cout << "\ts₁^-1(3) = ";
    std::vector<int> inv = SCS.s_inv( 1, 5 );
    for( int i = 0; i < inv.size(); i++ )
        std::cout << inv[i] << ",";
    std::cout << std::endl;
    std::cout << "\noverwriting the mapping of some elements..." << std::endl;
    SCS.s_map( 1, {6}, 6 );
    SCS.s_map( 1, {7}, 7 );
    SCS.s_map( 1, {8}, 8 );
    SCS.print_sfunc( 1 );
    std::cout << "\ntesting properties on the space functions..." << std::endl;
    bool s_total = SCS.s_properties( 1, scs<int>::S_FUNCTION_PROPERTY::SP_TOTAL );
    std::cout << "\ts₁ is " << ( s_total ? "" : "NOT " ) << "total" << std::endl;
    std::cout << "\noverwriting the mapping of some elements..." << std::endl;
    SCS.s_map( 1, {1}, 1 );
    SCS.s_map( 1, {2}, 2 );
    SCS.s_map( 1, {3}, 3 );
    SCS.s_map( 1, {4}, 4 );
    SCS.print_sfunc( 1 );
    std::cout << "\ntesting properties on the space function..." << std::endl;
    bool s_surjective = SCS.s_properties( 1, scs<int>::S_FUNCTION_PROPERTY::SP_SURJECTIVE );
    std::cout << "\ts₁ is " << ( s_surjective ? "" : "NOT " ) << "surjective" << std::endl;
    SCS.s_map( 1, {4}, 5 );
    bool s_injective = SCS.s_properties( 1, scs<int>::S_FUNCTION_PROPERTY::SP_INJECTIVE );
    std::cout << "\ts₁ is " << ( s_injective ? "" : "NOT " ) << "injective" << std::endl;
    bool s_bijective = SCS.s_properties( 1, scs<int>::S_FUNCTION_PROPERTY::SP_INJECTIVE );
    std::cout << "\ts₁ is " << ( s_bijective ? "" : "NOT " ) << "bijective" << std::endl;
    bool s_join_dist = SCS.s_properties( 1, scs<int>::S_FUNCTION_PROPERTY::SP_JOIN_DISTRIBUTIVE);
    std::cout << "\ts₁ is " << ( s_join_dist ? "" : "NOT " ) << "join distributive" << std::endl;
    SCS.s_map( 1, {4}, 4 );
    bool s_meet_dist = SCS.s_properties( 1, scs<int>::S_FUNCTION_PROPERTY::SP_MEET_DISTRIBUTIVE);
    std::cout << "\ts₁ is " << ( s_meet_dist ? "" : "NOT " ) << "meet distributive" << std::endl;
    // scse
    std::cout << "\n#### Testing of Spatial Constraint Systems with Extrusion ####" << std::endl;
    std::cout << "\ncreating a spatial constraint system with extrusion -e₁(c) = ⨆(s₁^-1(c))-..." << std::endl;
    SCS.s_map( 1, {4,5}, 5 );
    SCS.print_sfunc( 1 );
    scse<int> SCSE( SCS, scse<int>::E_CHOICE_FUNCTION::EC_SUPREMA );
    std::cout << "\ntesting properties on the extrusion function..." << std::endl;
    bool e_total = SCSE.e_properties( 1, scse<int>::E_FUNCTION_PROPERTY::EP_TOTAL );
    std::cout << "\te₁ is " << ( e_total ? "" : "NOT " ) << "total" << std::endl;
    bool e_surjective = SCSE.e_properties( 1, scse<int>::E_FUNCTION_PROPERTY::EP_SURJECTIVE );
    std::cout << "\te₁ is " << ( e_surjective ? "" : "NOT " ) << "surjective" << std::endl;
    std::cout << "\t e₁(4) = 4" << std::endl;
    SCSE.e_map( 1, {4}, 4 );
    bool e_injective = SCSE.e_properties( 1, scse<int>::E_FUNCTION_PROPERTY::EP_INJECTIVE );
    std::cout << "\te₁ is " << ( e_injective ? "" : "NOT " ) << "injective" << std::endl;
    bool e_bijective = SCSE.e_properties( 1, scse<int>::E_FUNCTION_PROPERTY::EP_BIJECTIVE );
    std::cout << "\te₁ is " << ( e_bijective ? "" : "NOT " ) << "bijective" << std::endl;
    std::cout << "\ts₁(4) = 4" << std::endl;
    SCSE.s_map( 1, {4}, 4 );
    bool e_right_inv = SCSE.e_properties( 1, scse<int>::E_FUNCTION_PROPERTY::EP_RIGHT_INVERSE_S );
    std::cout << "\te₁ is " << ( e_right_inv ? "" : "NOT " ) << "the right inverse of s₁" << std::endl;
    std::cout << "\noverwriting the mapping of some elements..." << std::endl;
    SCSE.e_map( 1, {0}, 0 );
    SCSE.e_map( 1, {1,2,3,4}, 5 );
    SCSE.e_map( 1, {6,7,8}, 8 );
    SCSE.print_efunc( 1 );
    bool e_join_dist = SCSE.e_properties( 1, scse<int>::E_FUNCTION_PROPERTY::EP_JOIN_DISTRIBUTIVE );
    std::cout << "\te₁ is " << ( e_join_dist ? "" : "NOT " ) << "join distributive" << std::endl;
    std::cout << "\noverwriting the mapping of some elements..." << std::endl;
    SCSE.e_map( 1, {1,2,3,4}, 0 );
    SCSE.e_map( 1, {6,7,8}, 5 );
    SCSE.print_efunc( 1 );
    bool e_meet_dist = SCSE.e_properties( 1, scse<int>::E_FUNCTION_PROPERTY::EP_MEET_DISTRIBUTIVE );
    std::cout << "\te₁ is " << ( e_meet_dist ? "" : "NOT " ) << "meet distributive" << std::endl;
    // ba
    std::cout << "\n##### Testing of Boolean Algebras #####" << std::endl;
    std::cout << "\ncreating a boolean algebra (3 space functions)..." << std::endl;
    ba<char> BA( {'c', 'a', 'b'}, 3, true );
    BA.m_scse.print_cons( [] (std::set<char> s) { std::cout << "{"; std::for_each( s.begin(), s.end(), [] (char c) { std::cout << c << ","; } ); std::cout << "} "; } );
    BA.m_scse.print_relation( true );
    std::cout << "\ntesting properties on the boolean algebra..." << std::endl;
    distributive = BA.m_scse.is_distributive();
    std::cout << "\tBA is " << ( distributive ? "" : "NOT " ) << "distributive" << std::endl;
    // space functions
    auto s = [] (int i, std::set<char> e, std::set<char> atoms) {
        std::set<char> s_e;
        switch( i ) {
            case 1:
                s_e = e;
                break;
            case 2:
                std::set_difference( atoms.begin(), atoms.end(), e.begin(), e.end(), std::inserter( s_e, s_e.end() ) );
                break;
            case 3:
                s_e = atoms;
                break;
        }
        return s_e;
    };
    std::cout << "\napplying functions to the boolean algebra" << std::endl;
    std::cout << "s₁(c) = c, s₂(c) = c', s₃(c) = atoms, eᵢ(c) = ⨆(sᵢ^-1(c))... " << std::endl;
    BA.map_s( s, scse<std::set<char>>::E_CHOICE_FUNCTION::EC_SUPREMA );
    BA.m_scse.print_sfunc( 1 );
    BA.m_scse.print_sfunc( 2 );
    BA.m_scse.print_sfunc( 3 );
    BA.m_scse.print_efunc( 1 );
    BA.m_scse.print_efunc( 2 );
    BA.m_scse.print_efunc( 3 );
    return 0;
}