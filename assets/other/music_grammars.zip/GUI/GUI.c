/********************* GUI para el programa Musi-k **********************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>

/*** Rutas ***/
char VisorPDF[1000] = "xpdf";
char VisorPNG[1000] = "gwenview";
char RepMIDI[1000]  = "timidity";

/*** Escalas ***/
char* EscalasMayores[] = { "do", "sol", "re", "la", "mi", "si", "fasos",
			   "fa", "sibem", "mibem", "labem", "rebem", "solbem" };
char* EscalasMenores[] = { "la", "mi", "si", "fasos", "dosos", "solsos",
			   "resos", "re", "sol", "do", "fa", "sibem", "mibem" };

/*** Numeradores y Denominadores(Compás) ***/
char* Numeradores[]   = { "1", "2", "3", "4", "5", "6", "7", "8", "9" };
char* Denominadores[] = { "2", "4", "8", "16" };

/*** Estructura para leer los parámetros iniciales */
typedef struct _Parametros
{
    GtkWidget* Mayor,* Menor;           // Color
    GtkWidget* Tonalidad;               // Tonalidad
    GtkWidget* Numerador,* Denominador; // Compás
    GtkWidget* BPM;                     // BPM
    GtkWidget* NoCompases;              // Número de Compases
    GtkWidget* PDF,* PNG,* MIDI;        // Archivos de salida
    GtkWidget* Output;                  // Archivo lilypond de salida
} Parametros;

/*** Callbacks ***/

/* Callback para la señal destroy */
void destroy( GtkWidget* widget, gpointer data )
{
    gtk_main_quit(); // Salimos de gtk
}

/* Callback para el evento delete(quit) */
gint delete_event( GtkWidget* widget, GdkEvent* event, gpointer data )
{
    /* Dialogo */
    GtkWidget* dialog;
    
    /* Lo creo */
    dialog = gtk_dialog_new_with_buttons( "Desea salir?", GTK_WINDOW(gtk_widget_get_toplevel( widget )),
					  GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
					  GTK_STOCK_OK, GTK_RESPONSE_ACCEPT,
					  GTK_STOCK_CANCEL, GTK_RESPONSE_REJECT,
					  NULL );

    /* Lo muestro */
    gint result = gtk_dialog_run( GTK_DIALOG(dialog) );
    switch( result )
    {
	case GTK_RESPONSE_ACCEPT:
	    destroy( widget, NULL );
	    return FALSE;
	case GTK_RESPONSE_REJECT:
	    gtk_widget_destroy( dialog );
	    return TRUE;
    }
    return TRUE;
}

/* Callback para preguntar */
int Preguntar( char* pregunta )
{
    /* Dialogo */
    GtkWidget* dialog,* label;
    
    /* Lo creo */
    dialog = gtk_dialog_new_with_buttons( pregunta, NULL,
					  GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
					  GTK_STOCK_OK, GTK_RESPONSE_ACCEPT,
					  GTK_STOCK_CANCEL, GTK_RESPONSE_REJECT,
					  NULL );
    label = gtk_label_new( pregunta );

    gtk_container_add( GTK_CONTAINER(GTK_DIALOG(dialog)->vbox), label );

    /* Lo muestro */
    gtk_widget_show_all( dialog );
    gint result = gtk_dialog_run( GTK_DIALOG(dialog) );
    switch( result )
    {
	case GTK_RESPONSE_ACCEPT:
	    gtk_widget_destroy( dialog );
	    return 1;
	case GTK_RESPONSE_REJECT:
	    gtk_widget_destroy( dialog );
	    return 0;
    }
    return 0;
}

/* Callbacks para los botones del color de la escala */
void Mayor( GtkWidget* widget, gpointer data )
{
    /* Borro las anteriores opciones */
    int x;
    for( x = 0; x < (sizeof(EscalasMenores) / sizeof(char*)); x++ )
	gtk_combo_box_remove_text( GTK_COMBO_BOX(data), 0 );
    /* Ingreso las posibles escalas */
    for( x = 0; x < (sizeof(EscalasMayores) / sizeof(char*)); x++ )
	gtk_combo_box_append_text( GTK_COMBO_BOX(data), EscalasMayores[x] );
    /* Selecciono una */
    gtk_combo_box_set_active( GTK_COMBO_BOX(data), 0 );
}
void Menor( GtkWidget* widget, gpointer data )
{
    /* Borro las anteriores opciones */
    int x;
    for( x = 0; x < (sizeof(EscalasMayores) / sizeof(char*)); x++ )
	gtk_combo_box_remove_text( GTK_COMBO_BOX(data), 0 );
    /* Ingreso las posibles escalas */
    for( x = 0; x < (sizeof(EscalasMenores) / sizeof(char*)); x++ )
	gtk_combo_box_append_text( GTK_COMBO_BOX(data), EscalasMenores[x] );
    /* Selecciono una */
    gtk_combo_box_set_active( GTK_COMBO_BOX(data), 0 );
}

/* Callback para el boton "Ok" del selector de archivos */
void FileSet( GtkWidget* widget, gpointer data )
{
    /* Pongo el nombre del archivo seleccionado en la caja de texto */
    gtk_entry_set_text( GTK_ENTRY(data),
			gtk_file_selection_get_filename( GTK_FILE_SELECTION(gtk_widget_get_toplevel( widget ) ) ) );
    /* Cierro la ventana de selección */
    gtk_widget_destroy( gtk_widget_get_toplevel( widget ) );
}

/* Callback para la selección de archivo */
void Seleccion( GtkWidget* widget, gpointer data )
{
    /* Selector de archivos */
    GtkWidget* FileSel;

    /* Creación y propiedades */
    FileSel = gtk_file_selection_new( "Output Sugenrencia" );
    gtk_file_selection_set_filename( GTK_FILE_SELECTION(FileSel), "Sugerencia" );

    /* Señales */
    /* Cancel */
    g_signal_connect_swapped( G_OBJECT(GTK_FILE_SELECTION(FileSel)->cancel_button),
			      "clicked", G_CALLBACK(gtk_widget_destroy), G_OBJECT(FileSel) );
    /* Ok */
    g_signal_connect( G_OBJECT(GTK_FILE_SELECTION(FileSel)->ok_button),
		      "clicked", G_CALLBACK(FileSet), data );

    /* Lo Muestro */
    gtk_widget_show( FileSel );
}

/* Callback para el menú "Configuración" */
void Configuracion( GtkWidget* widget, gpointer data )
{
    /* Widgets */
    GtkWidget* dialog;
    GtkWidget* LabelPrincipal;
    GtkWidget* BoxPDF,* BoxPNG,* BoxMIDI;
    GtkWidget* LabelPDF,* LabelPNG,* LabelMIDI;
    GtkWidget* TextPDF,* TextPNG,* TextMIDI;

    /* Creación */
    /* Dialogo */
    dialog = gtk_dialog_new_with_buttons( "Configuración de Comandos",
					  GTK_WINDOW(gtk_widget_get_toplevel(widget)),
					  GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
					  GTK_STOCK_OK, GTK_RESPONSE_ACCEPT,
					  GTK_STOCK_CANCEL, GTK_RESPONSE_REJECT,
					  NULL );
    /* Boxes */
    BoxPDF  = gtk_hbox_new( FALSE, 2 );
    BoxPNG  = gtk_hbox_new( FALSE, 2 );
    BoxMIDI = gtk_hbox_new( FALSE, 2 );
    /* Labels */
    LabelPrincipal = gtk_label_new( "\nEstablezca los comandos de visores y reproductores\n" );
    LabelPDF  = gtk_label_new( "Visor PDF: " );
    LabelPNG  = gtk_label_new( "Visor PNG: " );
    LabelMIDI = gtk_label_new( "Reproductor MIDI: " );
    /* Textos */
    TextPDF  = gtk_entry_new(); gtk_entry_set_text( GTK_ENTRY(TextPDF), VisorPDF );
    TextPNG  = gtk_entry_new(); gtk_entry_set_text( GTK_ENTRY(TextPNG), VisorPNG );
    TextMIDI = gtk_entry_new(); gtk_entry_set_text( GTK_ENTRY(TextMIDI), RepMIDI );

    /* Empaco */
    gtk_container_add( GTK_CONTAINER(GTK_DIALOG(dialog)->vbox), LabelPrincipal );
    gtk_container_add( GTK_CONTAINER(GTK_DIALOG(dialog)->vbox), BoxPDF );
    gtk_container_add( GTK_CONTAINER(GTK_DIALOG(dialog)->vbox), BoxPNG );
    gtk_container_add( GTK_CONTAINER(GTK_DIALOG(dialog)->vbox), BoxMIDI );

    gtk_box_pack_end( GTK_BOX(BoxPDF), TextPDF, FALSE, TRUE, 3 );
    gtk_box_pack_end( GTK_BOX(BoxPNG), TextPNG, FALSE, TRUE, 3 );
    gtk_box_pack_end( GTK_BOX(BoxMIDI), TextMIDI, FALSE, TRUE, 3 );

    gtk_box_pack_end( GTK_BOX(BoxPDF), LabelPDF, FALSE, TRUE, 3 );
    gtk_box_pack_end( GTK_BOX(BoxPNG), LabelPNG, FALSE, TRUE, 3 );
    gtk_box_pack_end( GTK_BOX(BoxMIDI), LabelMIDI, FALSE, TRUE, 3 );

    /* Muestro */
    gtk_widget_show_all( dialog );
    /* Lo muestro */
    gint result = gtk_dialog_run( GTK_DIALOG(dialog) );

    switch( result )
    {
	/* Cambio los valores de las rutas o comandos */
	case GTK_RESPONSE_ACCEPT:	    
	    /* Copio los valores */
	    strcpy( VisorPDF, gtk_entry_get_text( GTK_ENTRY(TextPDF) ) );
	    strcpy( VisorPNG, gtk_entry_get_text( GTK_ENTRY(TextPNG) ) );
	    strcpy( RepMIDI, gtk_entry_get_text( GTK_ENTRY(TextMIDI) ) );
	    gtk_widget_destroy( dialog );
	    break;
	/* Desago los cambios */
	case GTK_RESPONSE_REJECT:
	    gtk_widget_destroy( dialog );
	    break;
    }    
}

/* Callback para el menú "About" */
void About( GtkWidget* widget, gpointer data )
{
    /* Creación de la ventana del "About */
    GtkWidget* AboutDialog = gtk_about_dialog_new();

    /* Obtención del texto de la licencia */
    FILE* ArchivoLicencia;
    char* Licencia;
    ArchivoLicencia = fopen( "gpl.txt", "r" );
    Licencia = malloc( 50000 * sizeof(char) );
    fread( Licencia, sizeof(char), 50000, ArchivoLicencia );
    fclose( ArchivoLicencia );

    /* Nombre, versión y licencia */
    gtk_about_dialog_set_name( GTK_ABOUT_DIALOG(AboutDialog), "Musi-K" );
    gtk_about_dialog_set_version( GTK_ABOUT_DIALOG(AboutDialog), "1.0" );
    gtk_about_dialog_set_license( GTK_ABOUT_DIALOG(AboutDialog), Licencia );

    /* Autores */
    const gchar* Autores[] = { "Yamil Salim Perchy(ysperchy@puj.edu.co)",
			       "Bryan Uribe Angel(buribe@puj.edu.co)", NULL };
    gtk_about_dialog_set_authors( GTK_ABOUT_DIALOG(AboutDialog), Autores );

    /* La Muestro */
    gtk_dialog_run( GTK_DIALOG(AboutDialog) );
    
    free( Licencia );
}

/* Función auxiliar para comprobar la validez de los parámetros */
int ComprobarParametros( Parametros* param )
{
    int res = 1;
    g_print( "Comprobando parámetros...\n" );

    /* Compruebo la validez de los parámetros */
    g_print( "\tEscala\t\t: %s ", gtk_combo_box_get_active_text( GTK_COMBO_BOX(param->Tonalidad) ) );
    if( gtk_toggle_button_get_active( GTK_TOGGLE_BUTTON(param->Mayor) ) )
	g_print( "mayor\n" );
    if( gtk_toggle_button_get_active( GTK_TOGGLE_BUTTON(param->Menor) ) )
	g_print( "menor\n" );    
    g_print( "\tCompás\t\t: %s/%s\n",
	     gtk_combo_box_get_active_text( GTK_COMBO_BOX(param->Numerador) ),
	     gtk_combo_box_get_active_text( GTK_COMBO_BOX(param->Denominador) ) );
    g_print( "\tBPM\t\t: %d\n", gtk_spin_button_get_value_as_int( GTK_SPIN_BUTTON(param->BPM) ) );
    g_print( "\tNo. de Compases\t: %d\n", gtk_spin_button_get_value_as_int( GTK_SPIN_BUTTON(param->NoCompases) ) );
    if( gtk_toggle_button_get_active( GTK_TOGGLE_BUTTON(param->PDF) ) )
	g_print( "\tPDF\t\t: Sí\n" );
    else
	g_print( "\tPDF\t\t: No\n" );
    if( gtk_toggle_button_get_active( GTK_TOGGLE_BUTTON(param->PNG) ) )
	g_print( "\tPNG\t\t: Sí\n" );
    else
	g_print( "\tPNG\t\t: No\n" );
    if( gtk_toggle_button_get_active( GTK_TOGGLE_BUTTON(param->MIDI) ) )
	g_print( "\tMIDI\t\t: Sí\n" );
    else
	g_print( "\tMIDI\t\t: No\n" );
    g_print( "\tArchivo Salida\t: %s\n", gtk_entry_get_text(GTK_ENTRY(param->Output) ) );

    g_print( "Parámetros comprobados [OK]\n\n" );
    return res;
}

/* Función auxiliar que escribe los parámetros en un archivo temporal */
void EscribirParametros( Parametros* param )
{
    FILE* archivo;
    archivo = fopen( "param.tmp", "w" );

    /* Escribo todos los parámetros */
    fprintf( archivo, "escala=%s\n", gtk_combo_box_get_active_text( GTK_COMBO_BOX(param->Tonalidad) ) );
    if( gtk_toggle_button_get_active( GTK_TOGGLE_BUTTON(param->Mayor) ) )
	fprintf( archivo, "color=Mayor\n" );
    if( gtk_toggle_button_get_active( GTK_TOGGLE_BUTTON(param->Menor) ) )
	fprintf( archivo, "color=Menor\n" );
    fprintf( archivo, "compas=%d/%d\n",
	     atoi( gtk_combo_box_get_active_text( GTK_COMBO_BOX(param->Numerador) ) ),
	     atoi( gtk_combo_box_get_active_text( GTK_COMBO_BOX(param->Denominador) ) ) );
    fprintf( archivo, "BPM=%d\n", gtk_spin_button_get_value_as_int( GTK_SPIN_BUTTON(param->BPM) ) );
    
    fprintf( archivo, "NoCompases=%d\n", gtk_spin_button_get_value_as_int( GTK_SPIN_BUTTON(param->NoCompases) ) );
    if( gtk_toggle_button_get_active( GTK_TOGGLE_BUTTON(param->MIDI) ) )
	fprintf( archivo, "MIDI=si\n" );
    else
	fprintf( archivo, "MIDI=no\n" );
    char salida[1000];
    sprintf( salida, "%s.ly", gtk_entry_get_text(GTK_ENTRY(param->Output) ) );
    fprintf( archivo, "salida=%s\n", salida );

    fclose( archivo );
}    

/* Callback para el boton de componer */
void Componer( GtkWidget* widget, gpointer data )
{
    if( ComprobarParametros( (Parametros*)data) )
    {
	g_print( "Componiendo...\n" );
	g_print( "\tEscribiendo parámetros\n" );
	EscribirParametros( (Parametros*)data );
	g_print( "\tLlamando python\n" );
	system( "python Musik.py" );
	g_print( "Componiendo [OK]\n\n" );
	g_print( "Llamando Lilypond...\n" );
	g_print( "\tConstruyendo comando\n" );
	char comando[1000];
	comando[0] = '\0';
	strcat( comando, "lilypond " );
	if( gtk_toggle_button_get_active( GTK_TOGGLE_BUTTON(((Parametros*)data)->PDF) ) )
	    strcat( comando, "--pdf " );
	if( gtk_toggle_button_get_active( GTK_TOGGLE_BUTTON(((Parametros*)data)->PNG) ) )
	    strcat( comando, "--png " );
	strcat( comando, gtk_entry_get_text(GTK_ENTRY(((Parametros*)data)->Output) ) );
	strcat( comando, ".ly" );
	g_print( "\tComando: %s", comando );
	system( comando );
	g_print( "\nLlamado Lilypond [OK]\n\n" );
	g_print( "Borrando archivo de parámetros...\n" );
	system( "rm param.tmp" );
	g_print( "Archivo Borrado[OK]\n\n" );
	g_print( "¡PROGRAMA FINALIZÓ!\n\n" );
	/* Reproducciones y visualizaciones */
	if( gtk_toggle_button_get_active( GTK_TOGGLE_BUTTON(((Parametros*)data)->PDF) ) )
	{
	    if( Preguntar( "Deseea visualizar el PDF" ) )
	    {
		sprintf( comando, "%s %s.pdf &", VisorPDF, gtk_entry_get_text(GTK_ENTRY(((Parametros*)data)->Output) ) );
		system( comando );
	    }
	}
	if( gtk_toggle_button_get_active( GTK_TOGGLE_BUTTON(((Parametros*)data)->PNG) ) )
	{
	    if( Preguntar( "Deseea visualizar el PNG" ) )
	    {
		sprintf( comando, "%s %s.png &", VisorPNG, gtk_entry_get_text(GTK_ENTRY(((Parametros*)data)->Output) ) );
		system( comando );
	    }
	}
	if( gtk_toggle_button_get_active( GTK_TOGGLE_BUTTON(((Parametros*)data)->MIDI) ) )
	{
	    if( Preguntar( "Deseea reproducir el MIDI" ) )
	    {
		sprintf( comando, "%s %s.midi &", RepMIDI, gtk_entry_get_text(GTK_ENTRY(((Parametros*)data)->Output) ) );
		system( comando );
	    }
	}
    }
    else
    {
	g_print( "Error: Parámetros Inválidos!\n" );
    }
}


/*** Main ***/
int main( int argc, char* argv[] )
{
    /*** Objetos ***/

    /* Ventana */
    GtkWidget* window;
    /* Tabla */
    GtkWidget* tabla;

    /* Boxes */

    /* Box principal */
    GtkWidget* BoxPrincipal;
    /* Campo de tonalidad */
    GtkWidget* BoxTonalidad,* BoxEscala,* BoxColor;
    /* Campo de Ritmo */
    GtkWidget* BoxRitmo,* BoxCompas,* BoxBps;
    /* Campo de Misc */
    GtkWidget* BoxMisc,* BoxCompases,* BoxOutput1,* BoxOutput2;

    /* Frames */
    GtkWidget* FrameTonalidad,* FrameRitmo,* FrameMisc;

    /* Radio Botones */
    GtkWidget* BotonMayor,* BotonMenor;

    /* Combo-Box para las escalas y el compás*/
    GtkWidget* Escalas;
    GtkWidget* Numerador,* Denominador;

    /* Labels */
    GtkWidget* LabelCompas,* LabelDivisor;
    GtkWidget* LabelBps;
    GtkWidget* LabelNoCompases;
    GtkWidget* LabelArchivo;

    /* Spin-Button */
    GtkWidget* BotonBps;
    GtkWidget* BotonNoCompases;
    GtkAdjustment* spinner;

    /* Check-Button */
    GtkWidget* BotonPDF,* BotonPNG,* BotonMIDI;

    /* Botones */
    GtkWidget* BotonComponer;
    GtkWidget* BotonSeleccionar;
    
    /* Texto */
    GtkWidget* TextOutput;

    /* Menu */
    GtkWidget* MenuBar,* MenuFile,* MenuHelp;
    GtkWidget* MenuConfig,* MenuQuit,* MenuAbout;
    GtkWidget* MenuFileItem,* MenuHelpItem;

    /* Parámetros */
    Parametros param;

    /*** Iniciación de GTK ***/
    gtk_init( &argc, &argv );

    /*** Creación de Objetos ***/
    
    /* Ventana */
    window = gtk_window_new( GTK_WINDOW_TOPLEVEL );
    /* Tabla */
    tabla  = gtk_table_new( 2, 2, TRUE );

    /* Boxes */
    BoxPrincipal = gtk_vbox_new( FALSE, 0 );

    BoxTonalidad = gtk_hbox_new( TRUE, 10 );
    BoxEscala    = gtk_vbox_new( FALSE, 5 );
    BoxColor     = gtk_vbox_new( FALSE, 5 );

    BoxRitmo     = gtk_vbox_new( TRUE, 5 );
    BoxCompas    = gtk_hbox_new( FALSE, 2 );
    BoxBps       = gtk_hbox_new( FALSE, 2 );

    BoxMisc      = gtk_vbox_new( TRUE, 4 );
    BoxCompases  = gtk_hbox_new( FALSE, 2 );
    BoxOutput1   = gtk_hbox_new( FALSE, 5 );
    BoxOutput2   = gtk_hbox_new( FALSE, 2 );

    /* Frames */
    FrameTonalidad = gtk_frame_new( "Tonalidad" );
    FrameRitmo     = gtk_frame_new( "Ritmo" );
    FrameMisc      = gtk_frame_new( "Misc" );

    /* RadioBotones */
    BotonMayor = gtk_radio_button_new_with_label( NULL, "Mayor" );
    BotonMenor = gtk_radio_button_new_with_label_from_widget( GTK_RADIO_BUTTON(BotonMayor), "Menor" );

    /* Combo-Box */
    Escalas     = gtk_combo_box_new_text();
    Numerador   = gtk_combo_box_new_text();
    Denominador = gtk_combo_box_new_text();

    /* Labels */
    LabelCompas     = gtk_label_new( "Compás: " );
    LabelDivisor    = gtk_label_new( " / " );
    LabelBps        = gtk_label_new( "BPM: " );
    LabelNoCompases = gtk_label_new( "No. Compases: " );
    LabelArchivo    = gtk_label_new( "Output: " );

    /* Spin-Buttons */
    spinner         = (GtkAdjustment*)gtk_adjustment_new( 100.0, 1.0, 300.0, 1.0, 20.0, 20.0 );
    BotonBps        = gtk_spin_button_new( spinner, 1.0, 0 );
    spinner         = (GtkAdjustment*)gtk_adjustment_new( 20.0, 1.0, 1000.0, 1.0, 5.0, 5.0 );
    BotonNoCompases = gtk_spin_button_new( spinner, 1.0, 0 );

    /* Check-Buttons */
    BotonPDF  = gtk_check_button_new_with_label( "PDF" );
    BotonPNG  = gtk_check_button_new_with_label( "PNG" );
    BotonMIDI = gtk_check_button_new_with_label( "MIDI" );

    /* Botones */
    BotonComponer    = gtk_button_new_with_label( "Componer!" );
    BotonSeleccionar = gtk_button_new_with_label( "Seleccionar" );

    /* Texto */
    TextOutput = gtk_entry_new();

    /* Menus */
    MenuBar  = gtk_menu_bar_new();
    MenuFile = gtk_menu_new();
    MenuHelp = gtk_menu_new();

    MenuFileItem = gtk_menu_item_new_with_label( "Archivo" );
    MenuHelpItem = gtk_menu_item_new_with_label( "Ayuda" );
    
    MenuConfig = gtk_menu_item_new_with_label( "Configuración" );
    MenuQuit   = gtk_menu_item_new_with_label( "Salir" );
    MenuAbout  = gtk_menu_item_new_with_label( "Acerca" );

    /* Guardo los widgets que contienen los parámetros iniciales */
    param.Mayor       = BotonMayor;
    param.Menor       = BotonMenor;
    param.Tonalidad   = Escalas;
    param.Numerador   = Numerador;
    param.Denominador = Denominador;
    param.BPM         = BotonBps;
    param.NoCompases  = BotonNoCompases;
    param.PDF         = BotonPDF;
    param.PNG         = BotonPNG;
    param.MIDI        = BotonMIDI;
    param.Output      = TextOutput;

    /*** Propiedades ***/

    /* Ventana */
    gtk_container_set_border_width( GTK_CONTAINER(window), 0 ); // Borde
    gtk_window_set_title( GTK_WINDOW(window), "Musi-K" );       // Nombre
    
    /* Tabla */
    gtk_table_set_col_spacings( GTK_TABLE(tabla), 10 ); // Espacio entre columnas
    gtk_table_set_row_spacings( GTK_TABLE(tabla), 10 ); // Espacio entre filas

    /* Texto */
    gtk_editable_set_editable( GTK_EDITABLE(TextOutput), FALSE );

    /* Menus */
    gtk_menu_shell_append( GTK_MENU_SHELL(MenuFile), MenuConfig );
    gtk_menu_shell_append( GTK_MENU_SHELL(MenuFile), MenuQuit );
    gtk_menu_shell_append( GTK_MENU_SHELL(MenuHelp), MenuAbout );

    gtk_menu_item_set_submenu( GTK_MENU_ITEM(MenuFileItem), MenuFile );
    gtk_menu_item_set_submenu( GTK_MENU_ITEM(MenuHelpItem), MenuHelp );

    gtk_menu_bar_append( GTK_MENU_BAR(MenuBar), MenuFileItem );
    gtk_menu_bar_append( GTK_MENU_BAR(MenuBar), MenuHelpItem );

    /* Combo-Box */
    int x;
    for( x = 0; x < sizeof(Numeradores) / sizeof(char *); x++ )
	gtk_combo_box_append_text( GTK_COMBO_BOX(Numerador), Numeradores[x] );
    for( x = 0; x < sizeof(Denominadores) / sizeof(char *); x++ )
	gtk_combo_box_append_text( GTK_COMBO_BOX(Denominador), Denominadores[x] );

    /*** Asociaciones ***/
    
    /* window-box */
    gtk_container_add( GTK_CONTAINER(window), BoxPrincipal );

    /* Box-Menu,Tabla */
    gtk_box_pack_start( GTK_BOX(BoxPrincipal), MenuBar, FALSE, TRUE, 0 );
    gtk_box_pack_start( GTK_BOX(BoxPrincipal), tabla, FALSE, TRUE, 5 );

    /* tabla-frames */
    gtk_table_attach_defaults( GTK_TABLE(tabla), FrameTonalidad, 0, 1, 0, 1 );
    gtk_table_attach_defaults( GTK_TABLE(tabla), FrameRitmo, 1, 2, 0, 1 );
    gtk_table_attach_defaults( GTK_TABLE(tabla), FrameMisc, 0, 2, 1, 2 );

    /* frames-Boxes */
    gtk_container_add( GTK_CONTAINER(FrameTonalidad), BoxTonalidad );
    gtk_container_add( GTK_CONTAINER(FrameRitmo), BoxRitmo );
    gtk_container_add( GTK_CONTAINER(FrameMisc), BoxMisc );

    /* Boxes */
    /* Tonalidad */
    gtk_box_pack_start( GTK_BOX(BoxTonalidad), BoxEscala, TRUE, TRUE, 0 );
    gtk_box_pack_start( GTK_BOX(BoxTonalidad), BoxColor, TRUE, TRUE, 0 );
    /* Ritmo */
    gtk_box_pack_start( GTK_BOX(BoxRitmo), BoxCompas, TRUE, TRUE, 0 );
    gtk_box_pack_start( GTK_BOX(BoxRitmo), BoxBps, TRUE, TRUE, 0 );
    /* Misc */ 
    gtk_box_pack_start( GTK_BOX(BoxMisc), BoxCompases, TRUE, TRUE, 0 );
    gtk_box_pack_start( GTK_BOX(BoxMisc), BoxOutput1, TRUE, TRUE, 0 );
    gtk_box_pack_start( GTK_BOX(BoxMisc), BoxOutput2, TRUE, TRUE, 0 );

    /* Combo-box */
    gtk_box_pack_start( GTK_BOX(BoxEscala), Escalas, FALSE, TRUE, 0 );

    /* BoxColor-RadioBotones */
    gtk_box_pack_start( GTK_BOX(BoxColor), BotonMayor, FALSE, TRUE, 0 );
    gtk_box_pack_start( GTK_BOX(BoxColor), BotonMenor, FALSE, TRUE, 0 );

    /* BoxCompas-Labels,RadioBotones */
    gtk_box_pack_start( GTK_BOX(BoxCompas), LabelCompas, FALSE, TRUE, 3 );
    gtk_box_pack_start( GTK_BOX(BoxCompas), Numerador, FALSE, TRUE, 3 );
    gtk_box_pack_start( GTK_BOX(BoxCompas), LabelDivisor, FALSE, TRUE, 3 );
    gtk_box_pack_start( GTK_BOX(BoxCompas), Denominador, FALSE, TRUE, 3 );

    /* BoxBps-Labels,SpinButton */
    gtk_box_pack_start( GTK_BOX(BoxBps), LabelBps, FALSE, TRUE, 3 );
    gtk_box_pack_start( GTK_BOX(BoxBps), BotonBps, FALSE, TRUE, 3 );
    
    /* BoxCompases-Lables,SpinButton,Botones */
    gtk_box_pack_start( GTK_BOX(BoxCompases), LabelNoCompases, FALSE, TRUE, 3 );
    gtk_box_pack_start( GTK_BOX(BoxCompases), BotonNoCompases, FALSE, TRUE, 3 );
    gtk_box_pack_end( GTK_BOX(BoxCompases), BotonComponer, FALSE, TRUE, 3 );

    /* BoxOutput1-CheckButton */
    gtk_box_pack_start( GTK_BOX(BoxOutput1), BotonPDF, FALSE, TRUE, 3 );
    gtk_box_pack_start( GTK_BOX(BoxOutput1), BotonPNG, FALSE, TRUE, 3 );
    gtk_box_pack_start( GTK_BOX(BoxOutput1), BotonMIDI, FALSE, TRUE, 3 );

    /* BoxOutput2-Labels,Text,Boton */
    gtk_box_pack_start( GTK_BOX(BoxOutput2), LabelArchivo, FALSE, TRUE, 3 );
    gtk_box_pack_start( GTK_BOX(BoxOutput2), TextOutput, FALSE, TRUE, 3 );
    gtk_box_pack_start( GTK_BOX(BoxOutput2), BotonSeleccionar, FALSE, TRUE, 3 );

    /*** Señales y eventos ***/
    
    /* Ventana */
    g_signal_connect( G_OBJECT(window), "delete_event", G_CALLBACK(delete_event), NULL );
    g_signal_connect( G_OBJECT(window), "destroy", G_CALLBACK(destroy), NULL );

    /* RadioBotones */
    g_signal_connect( G_OBJECT(BotonMayor), "pressed", G_CALLBACK(Mayor), (gpointer)Escalas );
    g_signal_connect( G_OBJECT(BotonMenor), "pressed", G_CALLBACK(Menor), (gpointer)Escalas );

    /* Boton */
    g_signal_connect( G_OBJECT(BotonComponer), "clicked", G_CALLBACK(Componer), &param );
    g_signal_connect( G_OBJECT(BotonSeleccionar), "clicked", G_CALLBACK(Seleccion), (gpointer)TextOutput );

    /* Menus */
    g_signal_connect( G_OBJECT(MenuConfig), "activate", G_CALLBACK(Configuracion), NULL );
    g_signal_connect( G_OBJECT(MenuQuit), "activate", G_CALLBACK(delete_event), NULL );
    g_signal_connect( G_OBJECT(MenuAbout), "activate", G_CALLBACK(About), NULL );

    /*** Renderización ***/

    /* Ventana */
    gtk_widget_show_all( window );

    /* Selecciones por defecto */
    gtk_button_pressed( GTK_BUTTON(BotonMayor) );
    gtk_button_clicked( GTK_BUTTON(BotonPDF) );
    gtk_button_clicked( GTK_BUTTON(BotonMIDI) );
    gtk_combo_box_set_active( GTK_COMBO_BOX(Numerador), 3 );
    gtk_combo_box_set_active( GTK_COMBO_BOX(Denominador), 1 );
    gtk_entry_set_text( GTK_ENTRY(TextOutput), "Sugerencia" );

    /* Ciclo GTK */
    gtk_main();

    return 0;
}
