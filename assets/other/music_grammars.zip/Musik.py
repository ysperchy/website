# -*- coding: UTF-8 -*-

# Funciones necesarias
execfile( "Progresion.py" )
execfile( "BajoMelodia.py" )
execfile( "Transcripcion.py" )
execfile( "Partitura.py" )

# Parámetros iniciales

Color      = ""
Tonalidad  = ""
NoCompases = 0
Compas     = []
BPM        = 0
Midi       = False
Output     = ""

# Abro el archivo
archivo = open( "param.tmp", "r" )

# Leo los parámetros del archivo "param.tmp"
while True :
    # Siguiente línea
    linea = archivo.readline()
    # Acabó
    if linea == '':
        break
    # Linea
    izq, der = linea.strip().split("=")
    if izq == "escala":
        Tonalidad = der[:]
    if izq == "color":
        Color = der[:]
    if izq == "compas":
        n, d = der.strip().split("/")
        Compas = [int(n),int(d)]
    if izq == "BPM":
        BPM = int(der)
    if izq == "NoCompases":
        NoCompases = int(der)
    if izq == "MIDI":
        if der == "si":
            Midi = True
        elif der == "no":
            Midi = False
    if izq == "salida":
        Output = der[:]

# Realizo la sugerencia
Progresion = GenerarProgresionTotal( Color, NoCompases )
RitmoBajo = GenerarRitmoCompletoBajo( Compas, Progresion, Color )
RitmoMelodia = GenerarRitmoCompletoMelodia( Compas, Progresion, Color )
Bajo = GenerarTranscripcionBajo( RitmoBajo, Color, Tonalidad, BPM )
Melodia = GenerarTranscripcionMelodia( RitmoMelodia, Color, Tonalidad, BPM )
Generar_Partitura( Bajo, Melodia, Compas, BPM, Midi, Output )
