# -*- coding: UTF-8 -*-

###
### Archivo para las funciones de adjudicacion de notas
### Contiene las funciones que adjudicarán las notas
### tanto para el bajo como para la melodía
###

# Probabilidad para los intérvalos en la melodía
ProbabilidadIntervalos = []

# Leo las probabilidades para los intérvalos
Leer_Intervalos( "intervalos.txt" )
ProbabilidadIntervalos[:] = In[:]


# Función Auxiliar:
# Saca n elementos aleatorios de una lista L
def ElementosAleatorios( L, n ):
    if n == len(L):
        return L
    else:
        Rango = range( len(L) )
        Res = []
        while( len(Res) != n ):
            r = randrange(0, len(Rango) )
            Res = Res + [L[Rango[r]]]
            Rango.pop(r)
        return Res


##
## Funciones de adjudiación de notas a ritmos
##    AdjudicacionBajo    = Función para adjudicar notas al bajo de la partitura
##    AdjudicacionMelodia = Función para adjudicar notas a la melodía de la partitura
##

# Función que adjudica notas por cada compás a la melodía
def AdjudicacionMelodia( Duraciones, Ritmo, Acorde, Color ):
    Compas = []
    Mayor = 0
    NotasAcorde = []
    c = 0
    # Hallo la nota más larga o la primera
    while( c < len(Ritmo) ):
        if Ritmo[c] > Ritmo[Mayor]:
            Mayor = c
        c = c + 1
    # Hallo las notas que componen el acorde del compás
    if Color == "Mayor":
        N = ["I", "ii", "iii", "IV", "V", "V7", "vi", "viidis"]
        A = [ I_mayor, ii_mayor, iii_mayor, IV_mayor, V_mayor, V7_mayor, vi_mayor, viidis_mayor ]
        NotasAcorde = A[N.index( Acorde )]
    elif Color == "Menor":
        N = [ "i", "iidis", "III", "iv", "IV", "v", "V", "V7", "VI", "VII" ]
        A = [ i_menor, iidis_menor, III_menor, iv_menor, IV_menor, v_menor, V_menor, V7_menor, VI_menor, VII_menor ]
        NotasAcorde = A[N.index( Acorde )]
    
    # Modo de intervalos
    # "des" = Intervalos descendientes
    # "asc" = Intervalos ascendientes
    Modo = ""
    r = randrange(0, 100)
    if r < 50:
        Modo = "asc"
    elif r >= 50:
        Modo = "des"

    # Decido que nota llevará el tiempo embajador
    DuracionNotaEmbajadora = []
    for x in Duraciones:
        if x[0] == Ritmo[Mayor]:
            DuracionNotaEmbajadora = x[1]
            break
    EL = ElementosAleatorios( NotasAcorde, 1 )
    # Guardo la nota usada
    NotaEmbajadora = EL[0][0]

    # Notas para cada tiempo en el compás
    global ProbabilidadIntervalos
    # Antes de la nota mayor
    c = Mayor - 1
    NotaActual = NotaEmbajadora
    while( c >= 0 ):
        # Ubico el tiempo
        Duracion = []
        for x in Duraciones:
            if x[0] == Ritmo[c]:
                Duracion = x[1]
                break
        # Genero el intervalo
        i = Generar_Intervalo( ProbabilidadIntervalos )
        # Modo Ascendente
        if Modo == "asc":
            if NotaActual + i > 14:
                Modo = "des"
                NotaActual = NotaActual - i
            else:
                NotaActual = NotaActual + i
        # Modo Descendente
        elif Modo == "des":
            if NotaActual - i < 1:
                Modo = "asc"
                NotaActual = NotaActual + i
            else:
                NotaActual = NotaActual - i
        # Averiguo su alteración
        Alt= "nat"
        for x in NotasAcorde:
            if NotaActual == x[0]:
                Alt = x[1]
        Compas = Compas + [[ [[NotaActual, Alt]], Duracion ]]
        c = c - 1
    # La nota mayor
    Compas = Compas + [[ EL, DuracionNotaEmbajadora ]]
    # Antes de la nota mayor
    c = Mayor + 1
    NotaActual = NotaEmbajadora
    while( c < len(Ritmo) ):
        # Ubico el tiempo
        Duracion = []
        for x in Duraciones:
            if x[0] == Ritmo[c]:
                Duracion = x[1]
                break
        # Genero el intervalo
        i = Generar_Intervalo( ProbabilidadIntervalos )
        # Modo Ascendente
        if Modo == "asc":
            if NotaActual + i > 14:
                Modo = "des"
                NotaActual = NotaActual - i
            else:
                NotaActual = NotaActual + i
        # Modo Descendente
        elif Modo == "des":
            if NotaActual - i < 1:
                Modo = "asc"
                NotaActual = NotaActual + i
            else:
                NotaActual = NotaActual - i
        # Averiguo su alteración
        Alt= "nat"
        for x in NotasAcorde:
            if NotaActual == x[0]:
                Alt = x[1]
        Compas = Compas + [[ [[NotaActual, Alt]], Duracion ]]
        c = c + 1
    return Compas


# Función que adjudica notas por cada compás al bajo
def AdjudicacionBajo( Duraciones, Ritmo, Acorde, Color ):
    Compas = []
    Mayor = 0
    NotasAcorde = []
    c = 0
    # Hallo la nota más larga o la primera
    while( c < len(Ritmo) ):
        if Ritmo[c] > Ritmo[Mayor]:
            Mayor = c
        c = c + 1
    # Hallo las notas que componen el acorde del compás
    if Color == "Mayor":
        N = ["I", "ii", "iii", "IV", "V", "V7", "vi", "viidis"]
        A = [ I_mayor, ii_mayor, iii_mayor, IV_mayor, V_mayor, V7_mayor, vi_mayor, viidis_mayor ]
        NotasAcorde = A[N.index( Acorde )]
    elif Color == "Menor":
        N = [ "i", "iidis", "III", "iv", "IV", "v", "V", "V7", "VI", "VII" ]
        A = [ i_menor, iidis_menor, III_menor, iv_menor, IV_menor, v_menor, V_menor, V7_menor, VI_menor, VII_menor ]
        NotasAcorde = A[N.index( Acorde )]
    # Notas para cada tiempo en el compás
    c = 0
    while( c < len(Ritmo) ):
        # Hallo el tiempo que demora la notas
        Duracion = []
        for x in Duraciones:
            if x[0] == Ritmo[c]:
                Duracion = x[1]
                break
        # Adjudico las notas
        # Si es la nota más importante del compás
        if False: #c == Mayor:
            Compas = Compas + [[ NotasAcorde, Duracion]]
        else:
            # Elijo el numero de notas a poner
            n = int(round( float(Ritmo[c]) / float(Ritmo[Mayor]) * float(len(NotasAcorde)) ))
            if n == 0:
                n = 1
            n = randrange(1, n + 1)
            Compas = Compas + [[ ElementosAleatorios( NotasAcorde, n ), Duracion ]]
        c = c + 1
    #print str(Ritmo), Acorde, "--->", str(Compas)
    return Compas
