# -*- coding: UTF-8 -*-

###
### Archivo que lee y procesa una gramática musical
###
### La forma de gramática es:
### No Terminal (tabs) -> (tab) No Terminales, Terminales o Eventos (tabs) [Probabilidad]
### Si no tiene terminal a la derecha es porque pertence al último evaluado
### Probabilidades de un solo No terminal deben sumar 1.0 exáctamente
###
### Es llevada a la siguiente lista en python:
### [ No Terminal,  Rango Mínimo de probabilidad, Rango Máximo de probabiliad, [ Lista de posibles reglas ] ]
### Lista de posibles reglas:
### [ No Terminales, Terminales o Eventos ]
### Ej: S    ->    T S1 D T S    [0.5]
###          ->    T D T S       [0.3]
### [ S, 0, 50, [ T, S1, D, T, S ] ] 
### [ S, 50, 70, [ T, D, T, S ] ] 
###


Terminales = []
Eventos    = []
Reglas     = []

# Variable temporal que tiene el No terminal siendo analizado
NT = ""
# Variable temporal que tiene la probabiliad acumulada de las reglas anteriores
PNT = 0

# Función de entrada que lee cada línea de la gramática
def Leer_Gramatica( nombre_archivo ):
    # Abro el archivo
    archivo = open( nombre_archivo, "r" )

    # Proceso cada línea
    linea = " "
    while True :
        # Siguiente línea
        linea = archivo.readline()
        # Acabó
        if linea == '':
            break
        # Comentario
        if linea[0] == '\n' or linea[0] == '#':
            continue
        # Linea
        Procesar_Linea( linea[:-1] )
    archivo.close()

# Función que procesa cada línea de la gramática
def Procesar_Linea( cadena ):
    # Terminales
    if cadena[:3] == "T =":
        global Terminales
        Terminales = cadena[3:].strip().split( " " )
        return

    # Eventos
    if cadena[:3] == "E =":
        global Eventos
        Eventos = cadena[3:].strip().split( " " )
        return

    # Linea de la gramática

    # Parto la cadena
    derecho, izquierdo = cadena.strip().split( "->" )
    derecho   = derecho.strip().split( "\t" )
    izquierdo = izquierdo.strip().split( "\t" )

    global PNT
    # Analizo lado derecho
    if derecho[0] != '': # Si es un nuevo No terminal
        global NT
        NT = derecho[0]  # Se guarda
        PNT = 0          # Reseteo la probabilidad
        
    regla = [ NT ]

    # Analizo el lado izquierdo
    # Probabilidad
    prob  = float (izquierdo[-1][1:-1])       # Le quito los [] a la probabilidad
    lista = [ PNT, PNT + int (prob * 100.0) ] # Calculo el rango en base 100
    PNT = PNT + int (prob * 100.0)            # Agrego a la probabilidad acumulada
    # Lado izquierdo
    lista = lista + [ izquierdo[0].strip().split( " " ) ]
    regla = regla + lista

    # Agrego la nueva regla al conjutno de reglas
    global Reglas
    Reglas = Reglas + [ regla ]


## Ejemplo

## Leer_Gramatica( "gramatica mayor.txt" )
## print "Terminales: ", Terminales, "\n"
## print "Eventos: ", Eventos, "\n"
## print "----------Reglas----------"
## for x in Reglas:
##     print x

