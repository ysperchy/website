# -*- coding: UTF-8 -*-

###
### Archivo que genera una progresión
### Parámetros a usar:
###   -Tipo de escala(Mayor o Menor)
###   -Número de compases a componer
###

# Generador de números aleatórios
from random import randrange

## Funciones
execfile( "Gramatica.py" )

# De un conjunto de reglas, saca las que tiene el NoTerminal(NT) a la derecha
def ReglasdeTerminal( R, NT ):
    l = []
    for x in R:
        if x[0] == NT:
            l = l + [x]
    return l

# Terminales, eventos y reglas de la gramática para escalas Mayores
TerminalesMayor = []
EventosMayor    = []
ReglasMayor     = []

# Terminales, eventos y reglas de la gramática para escalas Menores
TerminalesMenor = []
EventosMenor    = []
ReglasMenor     = []

# Leo la gramática de escalas Mayores y la guardo
Leer_Gramatica( "gramatica mayor.txt" )
TerminalesMayor[:] = Terminales[:]
EventosMayor[:]    = Eventos[:]
ReglasMayor[:]     = Reglas[:]

Reglas = []
# Leo la gramática de escalas Menores y la guardo
Leer_Gramatica( "gramatica menor.txt" )
TerminalesMenor[:] = Terminales[:]
EventosMenor[:]    = Eventos[:]
ReglasMenor[:]     = Reglas[:]

# Variable que lleva la cuenta del número de compases aproximado realizados
NumeroCompases = 0
# Varibale que lleva el color
EA = "Mayor"

# Genera una progresión con el NoTerminal(NTA) inicial y el tipo de escala actual(EA)
def GenerarProgresion( NTA ):
    global EA
    # Clarifico que reglas, eventos y terminales debo utilizar(Mayores o Menores)
    Regl = []
    Term   = []
    Even   = []
    # Si estoy en una escala Mayor
    if EA == "Mayor":
        global ReglasMayor
        global TerminalesMayor
        global EventosMayor
        Regl = ReglasdeTerminal( ReglasMayor, NTA )
        Term = TerminalesMayor
        Even = EventosMayor
    #Si estoy en una escala Menor
    elif EA == "Menor":
        global ReglasMenor
        global TerminalesMenor
        global EventosMenor
        Regl = ReglasdeTerminal( ReglasMenor, NTA )
        Term = TerminalesMenor
        Even = EventosMenor

    num = randrange( 0, 99 ) # Regla aleatoria

    # Decido que regla utilizar dado el número aleatorio
    Regla = []
    for x in Regl:
        if num >= x[1] and num < x[2]:
            Regla = x[3]
            break

    #print Regla

    # Agrego la regla a la progresión siendo compuesta
    P = []

    for x in Regla:
        # Si es evento se anota en la progresión y verifico si de cambiado de tipo de escala
        if x in Even:
            if EA == "Mayor" and x in [ "mod3", "mod4", "mod61", "mod71" ]:
                EA = "Menor"
            elif EA == "Menor" and x in [ "mod11", "mod3", "mod4", "mod62", "mod72" ]:
                EA = "Mayor"
            P = P + [x]
        # Si es un terminal lo agrego y disminuyo el número de compases
        elif x in Term:
            global NumeroCompases
            NumeroCompases = NumeroCompases - 1
            P = P + [x]
        # Si es un no terminal generamos la parte que signifique
        else:
            # Debo verificar si el número de compases ya ha llegado a su límite
            # Si es así, entonces no genero más frases en la progresión
            if x == "S" and NumeroCompases < 0:
                continue
            else:
                P = P + GenerarProgresion( x )

    # Devuelvo la progresión generada
    return P 

# Genera la progresión completa, recibe el color de la tonalidad inicial y el número de compases a componer
def GenerarProgresionTotal( Color, NoCompases ):
    global EA
    EA = Color
    global NumeroCompases
    NumeroCompases = NoCompases
    return GenerarProgresion( "S'" )


### Ejemplo
## Progresion = GenerarProgresionTotal( "Mayor", 20 )

## a = 0
## for x in Progresion:
##     if x in EventosMayor or x in EventosMenor:
##         continue
##     else:
##         a = a + 1
        
## print "Número de compases:" + str(a)
## print Progresion
