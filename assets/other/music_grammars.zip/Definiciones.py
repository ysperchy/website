# -*- coding: UTF-8 -*-

###
### Archivo que contiene las definciones básicas de la música temperada incluye las
### escalas y la formación de acordes respecto a su grado en escala mayor o menor.
### También pre-define las modulaciones que puede realizar cada escala en sabe a la gramática
###


## Escalas

# Mayores

Do_mayor     = [ ["do","nat"], ["re","nat"], ["mi","nat"], ["fa","nat"], ["sol","nat"], ["la","nat"], ["si","nat"] ]
Sol_mayor    = [ ["sol","nat"], ["la","nat"], ["si","nat"], ["do","nat"], ["re","nat"], ["mi","nat"], ["fa","sos"] ]
Re_mayor     = [ ["re","nat"], ["mi","nat"], ["fa","sos"], ["sol","nat"], ["la","nat"], ["si","nat"], ["do","sos"] ]
La_mayor     = [ ["la","nat"], ["si","nat"], ["do","sos"], ["re","nat"], ["mi","nat"], ["fa","sos"], ["sol","sos"] ]
Mi_mayor     = [ ["mi","nat"], ["fa","sos"], ["sol","sos"], ["la","nat"], ["si","nat"], ["do","sos"], ["re","sos"] ]
Si_mayor     = [ ["si","nat"], ["do","sos"], ["re","sos"], ["mi","nat"], ["fa","sos"], ["sol","sos"], ["la","sos"] ]
Fasos_mayor  = [ ["fa","sos"], ["sol","sos"], ["la","sos"], ["si","nat"], ["do","sos"], ["re","sos"], ["mi","sos"] ]
Fa_mayor     = [ ["fa","nat"], ["sol","nat"], ["la","nat"], ["si","bem"], ["do","nat"], ["re","nat"], ["mi","nat"] ]
Sibem_mayor  = [ ["si","bem"], ["do","nat"], ["re","nat"], ["mi","bem"], ["fa","nat"], ["sol","nat"], ["la","nat"] ]
Mibem_mayor  = [ ["mi","bem"], ["fa","nat"], ["sol","nat"], ["la","bem"], ["si","bem"], ["do","nat"], ["re","nat"] ]
Labem_mayor  = [ ["la","bem"], ["si","bem"], ["do","nat"], ["re","bem"], ["mi","bem"], ["fa","nat"], ["sol","nat"] ]
Rebem_mayor  = [ ["re","bem"], ["mi","bem"], ["fa","nat"], ["sol","bem"], ["la","bem"], ["si","bem"], ["do","nat"] ]
Solbem_mayor = [ ["sol","bem"], ["la","bem"], ["si","bem"], ["do","bem"], ["re","bem"], ["mi","bem"], ["fa","nat"] ]

# Menores

La_menor     = [ ["la","nat"], ["si","nat"], ["do","nat"], ["re","nat"], ["mi","nat"], ["fa","nat"], ["sol","nat"] ]
Mi_menor     = [ ["mi","nat"], ["fa","sos"], ["sol","nat"], ["la","nat"], ["si","nat"], ["do","nat"], ["re","nat"] ]
Si_menor     = [ ["si","nat"], ["do","sos"], ["re","nat"], ["mi","nat"], ["fa","sos"], ["sol","nat"], ["la","nat"] ]
Fasos_menor  = [ ["fa","sos"], ["sol","sos"], ["la","nat"], ["si","nat"], ["do","sos"], ["re","nat"], ["mi","nat"] ]
Dosos_menor  = [ ["do","sos"], ["re","sos"], ["mi","nat"], ["fa","sos"], ["sol","sos"], ["la","nat"], ["si","nat"] ]
Solsos_menor = [ ["sol","sos"], ["la","sos"], ["si","nat"], ["do","sos"], ["re","sos"], ["mi","nat"], ["fa","sos"] ]
Resos_menor  = [ ["re","sos"], ["mi","sos"], ["fa","sos"], ["sol","sos"], ["la","sos"], ["si","nat"], ["do","sos"] ]
Re_menor     = [ ["re","nat"], ["mi","nat"], ["fa","nat"], ["sol","nat"], ["la","nat"], ["si","bem"], ["do","nat"] ]
Sol_menor    = [ ["sol","nat"], ["la","nat"], ["si","bem"], ["do","nat"], ["re","nat"], ["mi","bem"], ["fa","nat"] ]
Do_menor     = [ ["do","nat"], ["re","nat"], ["mi","bem"], ["fa","nat"], ["sol","nat"], ["la","bem"], ["si","bem"] ]
Fa_menor     = [ ["fa","nat"], ["sol","nat"], ["la","bem"], ["si","bem"], ["do","nat"], ["re","bem"], ["mi","bem"] ]
Sibem_menor  = [ ["si","bem"], ["do","nat"], ["re","bem"], ["mi","bem"], ["fa","nat"], ["sol","bem"], ["la","bem"] ]
Mibem_menor  = [ ["mi","bem"], ["fa","nat"], ["sol","bem"], ["la","bem"], ["si","bem"], ["do","bem"], ["re","bem"] ]

## Acordes

# Mayores

I_mayor      = [ [1,"nat"], [3,"nat"], [5,"nat"] ]
ii_mayor     = [ [2,"nat"], [4,"nat"], [6,"nat"] ]
iii_mayor    = [ [3,"nat"], [5,"nat"], [7,"nat"] ]
IV_mayor     = [ [4,"nat"], [6,"nat"], [8,"nat"] ]
V_mayor      = [ [5,"nat"], [7,"nat"], [9,"nat"] ]
V7_mayor     = [ [5,"nat"], [7,"nat"], [9,"nat"], [11,"nat"] ]
vi_mayor     = [ [6,"nat"], [8,"nat"], [10,"nat"] ]
viidis_mayor = [ [7,"nat"], [9,"nat"], [11,"nat"] ]

# Menores

i_menor      = [ [1,"nat"], [3,"nat"], [5,"nat"] ]
iidis_menor  = [ [2,"nat"], [4,"nat"], [6,"nat"] ]
III_menor    = [ [3,"nat"], [5,"nat"], [7,"nat"] ]
iv_menor     = [ [4,"nat"], [6,"nat"], [8,"nat"] ]
IV_menor     = [ [4,"nat"], [6,"sos"], [8,"nat"] ]
v_menor      = [ [5,"nat"], [7,"nat"], [9,"nat"] ]
V_menor      = [ [5,"nat"], [7,"sos"], [9,"nat"] ]
V7_menor     = [ [5,"nat"], [7,"sos"], [9,"nat"], [11,"nat"] ]
VI_menor     = [ [6,"nat"], [8,"nat"], [10,"nat"] ]
VII_menor    = [ [7,"nat"], [9,"nat"], [11,"nat"] ]

## Modulaciones

# Mayores

Modulaciones_Do_mayor     = [ ["mod11", "sol"   , "Mayor"],
                              ["mod2" , "fa"    , "Mayor"],
                              ["mod3" , "do"    , "Menor"],
                              ["mod4" , "la"    , "Menor"],
                              ["mod51", "re"    , "Mayor"],
                              ["mod52", "sibem" , "Mayor"],
                              ["mod61", "mi"    , "Menor"],
                              ["mod71", "re"    , "Menor"] ]

Modulaciones_Sol_mayor    = [ ["mod11", "re"    , "Mayor"],
                              ["mod2" , "do"    , "Mayor"],
                              ["mod3" , "sol"   , "Menor"],
                              ["mod4" , "mi"    , "Menor"],
                              ["mod51", "la"    , "Mayor"],
                              ["mod52", "fa"    , "Mayor"],
                              ["mod61", "si"    , "Menor"],
                              ["mod71", "la"    , "Menor"] ]

Modulaciones_Re_mayor     = [ ["mod11", "la"    , "Mayor"],
                              ["mod2" , "sol"   , "Mayor"],
                              ["mod3" , "re"    , "Menor"],
                              ["mod4" , "si"    , "Menor"],
                              ["mod51", "mi"    , "Mayor"],
                              ["mod52", "do"    , "Mayor"],
                              ["mod61", "fasos" , "Menor"],
                              ["mod71", "mi"    , "Menor"] ]

Modulaciones_La_mayor     = [ ["mod11", "mi"    , "Mayor"],
                              ["mod2" , "re"    , "Mayor"],
                              ["mod3" , "la"    , "Menor"],
                              ["mod4" , "fasos" , "Menor"],
                              ["mod51", "si"    , "Mayor"],
                              ["mod52", "sol"   , "Mayor"],
                              ["mod61", "dosos" , "Menor"],
                              ["mod71", "si"    , "Menor"] ]

Modulaciones_Mi_mayor     = [ ["mod11", "si"    , "Mayor"],
                              ["mod2" , "la"    , "Mayor"],
                              ["mod3" , "mi"    , "Menor"],
                              ["mod4" , "dosos" , "Menor"],
                              ["mod51", "fasos" , "Mayor"],
                              ["mod52", "re"    , "Mayor"],
                              ["mod61", "solsos", "Menor"],
                              ["mod71", "fasos" , "Menor"] ]

Modulaciones_Si_mayor     = [ ["mod11", "fasos" , "Mayor"],
                              ["mod2" , "mi"    , "Mayor"],
                              ["mod3" , "si"    , "Menor"],
                              ["mod4" , "solsos", "Menor"],
                              ["mod51", "rebem" , "Mayor"],
                              ["mod52", "la"    , "Mayor"],
                              ["mod61", "resos" , "Menor"],
                              ["mod71", "dosos" , "Menor"] ]

Modulaciones_Fasos_mayor  = [ ["mod11", "rebem" , "Mayor"],
                              ["mod2" , "si"    , "Mayor"],
                              ["mod3" , "fa"    , "Menor"],
                              ["mod4" , "resos" , "Menor"],
                              ["mod51", "labem" , "Mayor"],
                              ["mod52", "mi"    , "Mayor"],
                              ["mod61", "sibem" , "Menor"],
                              ["mod71", "solsos", "Menor"] ]

Modulaciones_Fa_mayor     = [ ["mod11", "do"    , "Mayor"],
                              ["mod2" , "sibem" , "Mayor"],
                              ["mod3" , "fa"    , "Menor"],
                              ["mod4" , "re"    , "Menor"],
                              ["mod51", "sol"   , "Mayor"],
                              ["mod52", "mibem" , "Mayor"],
                              ["mod61", "la"    , "Menor"],
                              ["mod71", "sol"   , "Menor"] ]

Modulaciones_Sibem_mayor  = [ ["mod11", "fa"    , "Mayor"],
                              ["mod2" , "mibem" , "Mayor"],
                              ["mod3" , "sibem" , "Menor"],
                              ["mod4" , "sol"   , "Menor"],
                              ["mod51", "do"    , "Mayor"],
                              ["mod52", "labem" , "Mayor"],
                              ["mod61", "re"    , "Menor"],
                              ["mod71", "do"    , "Menor"] ]

Modulaciones_Mibem_mayor  = [ ["mod11", "sibem" , "Mayor"],
                              ["mod2" , "labem" , "Mayor"],
                              ["mod3" , "mibem" , "Menor"],
                              ["mod4" , "do"    , "Menor"],
                              ["mod51", "fa"    , "Mayor"],
                              ["mod52", "rebem" , "Mayor"],
                              ["mod61", "sol"   , "Menor"],
                              ["mod71", "fa"    , "Menor"] ]

Modulaciones_Labem_mayor  = [ ["mod11", "mibem" , "Mayor"],
                              ["mod2" , "rebem" , "Mayor"],
                              ["mod3" , "solsos", "Menor"],
                              ["mod4" , "fa"    , "Menor"],
                              ["mod51", "sibem" , "Mayor"],
                              ["mod52", "solbem", "Mayor"],
                              ["mod61", "do"    , "Menor"],
                              ["mod71", "sibem" , "Menor"] ]

Modulaciones_Rebem_mayor  = [ ["mod11", "labem" , "Mayor"],
                              ["mod2" , "solbem", "Mayor"],
                              ["mod3" , "dosos" , "Menor"],
                              ["mod4" , "sibem" , "Menor"],
                              ["mod51", "mibem" , "Mayor"],
                              ["mod52", "si"    , "Mayor"],
                              ["mod61", "mibem" , "Menor"],
                              ["mod71", "fa"    , "Menor"] ]

Modulaciones_Solbem_mayor = [ ["mod11", "rebem" , "Mayor"],
                              ["mod2" , "si"    , "Mayor"],
                              ["mod3" , "fasos" , "Menor"],
                              ["mod4" , "mibem" , "Menor"],
                              ["mod51", "labem" , "Mayor"],
                              ["mod52", "mi"    , "Mayor"],
                              ["mod61", "sibem" , "Menor"],
                              ["mod71", "labem" , "Menor"] ]

# Menores

Modulaciones_La_menor     = [ ["mod11", "mi"    , "Mayor"],
                              ["mod12", "mi"    , "Menor"],
                              ["mod2" , "re"    , "Menor"],
                              ["mod3" , "la"    , "Mayor"],
                              ["mod4" , "do"    , "Mayor"],
                              ["mod51", "si"    , "Menor"],
                              ["mod52", "sol"   , "Menor"],
                              ["mod62", "sol"   , "Mayor"],
                              ["mod72", "fa"    , "Mayor"] ]

Modulaciones_Mi_menor     = [ ["mod11", "si"    , "Mayor"],
                              ["mod12", "si"    , "Menor"],
                              ["mod2" , "la"    , "Menor"],
                              ["mod3" , "mi"    , "Mayor"],
                              ["mod4" , "sol"   , "Mayor"],
                              ["mod51", "fasos" , "Menor"],
                              ["mod52", "re"    , "Menor"],
                              ["mod62", "re"    , "Mayor"],
                              ["mod72", "do"    , "Mayor"] ]

Modulaciones_Si_menor     = [ ["mod11", "fasos" , "Mayor"],
                              ["mod12", "fasos" , "Menor"],
                              ["mod2" , "mi"    , "Menor"],
                              ["mod3" , "si"    , "Mayor"],
                              ["mod4" , "re"    , "Mayor"],
                              ["mod51", "dosos" , "Menor"],
                              ["mod52", "la"    , "Menor"],
                              ["mod62", "la"    , "Mayor"],
                              ["mod72", "sol"   , "Mayor"] ]

Modulaciones_Fasos_menor  = [ ["mod11", "rebem" , "Mayor"],
                              ["mod12", "dosos" , "Menor"],
                              ["mod2" , "si"    , "Menor"],
                              ["mod3" , "fasos" , "Mayor"],
                              ["mod4" , "la"    , "Mayor"],
                              ["mod51", "solsos", "Menor"],
                              ["mod52", "mi"    , "Menor"],
                              ["mod62", "mi"    , "Mayor"],
                              ["mod72", "re"    , "Mayor"] ]

Modulaciones_Dosos_menor  = [ ["mod11", "labem" , "Mayor"],
                              ["mod12", "solsos", "Menor"],
                              ["mod2" , "fasos" , "Menor"],
                              ["mod3" , "rebem" , "Mayor"],
                              ["mod4" , "mi"    , "Mayor"],
                              ["mod51", "resos" , "Menor"],
                              ["mod52", "si"    , "Menor"],
                              ["mod62", "si"    , "Mayor"],
                              ["mod72", "la"    , "Mayor"] ]

Modulaciones_Solsos_menor = [ ["mod11", "mibem" , "Mayor"],
                              ["mod12", "resos" , "Menor"],
                              ["mod2" , "dosos" , "Menor"],
                              ["mod3" , "labem" , "Mayor"],
                              ["mod4" , "si"    , "Mayor"],
                              ["mod51", "sibem" , "Menor"],
                              ["mod52", "fasos" , "Menor"],
                              ["mod62", "fasos" , "Mayor"],
                              ["mod72", "mi"    , "Mayor"] ]

Modulaciones_Resos_menor  = [ ["mod11", "sibem" , "Mayor"],
                              ["mod12", "sibem" , "Menor"],
                              ["mod2" , "solsos", "Menor"],
                              ["mod3" , "mibem" , "Mayor"],
                              ["mod4" , "fasos" , "Mayor"],
                              ["mod51", "fa"    , "Menor"],
                              ["mod52", "dosos" , "Menor"],
                              ["mod62", "rebem" , "Mayor"],
                              ["mod72", "si"    , "Mayor"] ]

Modulaciones_Re_menor     = [ ["mod11", "la"    , "Mayor"],
                              ["mod12", "la"    , "Menor"],
                              ["mod2" , "sol"   , "Menor"],
                              ["mod3" , "re"    , "Mayor"],
                              ["mod4" , "fa"    , "Mayor"],
                              ["mod51", "mi"    , "Menor"],
                              ["mod52", "do"    , "Menor"],
                              ["mod62", "do"    , "Mayor"],
                              ["mod72", "sibem" , "Mayor"] ]

Modulaciones_Sol_menor    = [ ["mod11", "re"    , "Mayor"],
                              ["mod12", "re"    , "Menor"],
                              ["mod2" , "do"    , "Menor"],
                              ["mod3" , "sol"   , "Mayor"],
                              ["mod4" , "sibem" , "Mayor"],
                              ["mod51", "la"    , "Menor"],
                              ["mod52", "fa"    , "Menor"],
                              ["mod62", "fa"    , "Mayor"],
                              ["mod72", "mibem" , "Mayor"] ]

Modulaciones_Do_menor     = [ ["mod11", "sol"   , "Mayor"],
                              ["mod12", "sol"   , "Menor"],
                              ["mod2" , "fa"    , "Menor"],
                              ["mod3" , "do"    , "Mayor"],
                              ["mod4" , "mibem" , "Mayor"],
                              ["mod51", "re"    , "Menor"],
                              ["mod52", "sibem" , "Menor"],
                              ["mod62", "sibem" , "Mayor"],
                              ["mod72", "labem" , "Mayor"] ]

Modulaciones_Fa_menor     = [ ["mod11", "do"    , "Mayor"],
                              ["mod12", "do"    , "Menor"],
                              ["mod2" , "sibem" , "Menor"],
                              ["mod3" , "fa"    , "Mayor"],
                              ["mod4" , "labem" , "Mayor"],
                              ["mod51", "sol"   , "Menor"],
                              ["mod52", "mibem" , "Menor"],
                              ["mod62", "mibem" , "Mayor"],
                              ["mod72", "rebem" , "Mayor"] ]

Modulaciones_Sibem_menor  = [ ["mod11", "fa"    , "Mayor"],
                              ["mod12", "fa"    , "Menor"],
                              ["mod2" , "mibem" , "Menor"],
                              ["mod3" , "sibem" , "Mayor"],
                              ["mod4" , "rebem" , "Mayor"],
                              ["mod51", "do"    , "Menor"],
                              ["mod52", "solsos", "Menor"],
                              ["mod62", "labem" , "Mayor"],
                              ["mod72", "solbem", "Mayor"] ]

Modulaciones_Mibem_menor  = [ ["mod11", "sibem" , "Mayor"],
                              ["mod12", "sibem" , "Menor"],
                              ["mod2" , "solsos", "Menor"],
                              ["mod3" , "mibem" , "Mayor"],
                              ["mod4" , "solbem", "Mayor"],
                              ["mod51", "fa"    , "Menor"],
                              ["mod52", "dosos" , "Menor"],
                              ["mod62", "rebem" , "Mayor"],
                              ["mod72", "si"    , "Mayor"] ]


# Alturas

# Bajo
Bajo_Do  = [ -1, -1, -1, -1, -1, -1, -1 ]
Bajo_Re  = [ -1, -1, -1, -1, -1, -1,  0 ]
Bajo_Mi  = [ -1, -1, -1, -1, -1,  0,  0 ]
Bajo_Fa  = [ -1, -1, -1, -1,  0,  0,  0 ]
Bajo_Sol = [ -1, -1, -1,  0,  0,  0,  0 ]
Bajo_La  = [ -1, -1,  0,  0,  0,  0,  0 ]
Bajo_Si  = [ -1,  0,  0,  0,  0,  0,  0 ]

# Melodía
Alto_Do  = [  1,  1,  1,  1,  1,  1,  1 ]
Alto_Re  = [  1,  1,  1,  1,  1,  1,  2 ]
Alto_Mi  = [  1,  1,  1,  1,  1,  2,  2 ]
Alto_Fa  = [  1,  1,  1,  1,  2,  2,  2 ]
Alto_Sol = [  1,  1,  1,  2,  2,  2,  2 ]
Alto_La  = [  1,  1,  2,  2,  2,  2,  2 ]
Alto_Si  = [  1,  2,  2,  2,  2,  2,  2 ]


## Listas para manipulación de acordes y escalas

# Escalas
# Forma: [ Nota, Lista_Escala, Lista_Modulaciones ]

Escalas_mayores = [ ["do"     ,Do_mayor    , Modulaciones_Do_mayor    , Bajo_Do , Alto_Do  ],
                    ["sol"    ,Sol_mayor   , Modulaciones_Sol_mayor   , Bajo_Sol, Alto_Sol ],
                    ["re"     ,Re_mayor    , Modulaciones_Re_mayor    , Bajo_Re , Alto_Re  ],
                    ["la"     ,La_mayor    , Modulaciones_La_mayor    , Bajo_La , Alto_La  ],
                    ["mi"     ,Mi_mayor    , Modulaciones_Mi_mayor    , Bajo_Mi , Alto_Mi  ],
                    ["si"     ,Si_mayor    , Modulaciones_Si_mayor    , Bajo_Si , Alto_Si  ],
                    ["fasos"  ,Fasos_mayor , Modulaciones_Fasos_mayor , Bajo_Fa , Alto_Fa  ],
                    ["fa"     ,Fa_mayor    , Modulaciones_Fa_mayor    , Bajo_Fa , Alto_Fa  ],
                    ["sibem"  ,Sibem_mayor , Modulaciones_Sibem_mayor , Bajo_Si , Alto_Si  ],
                    ["mibem"  ,Mibem_mayor , Modulaciones_Mibem_mayor , Bajo_Mi , Alto_Mi  ],
                    ["labem"  ,Labem_mayor , Modulaciones_Labem_mayor , Bajo_La , Alto_La  ],
                    ["rebem"  ,Rebem_mayor , Modulaciones_Rebem_mayor , Bajo_Re , Alto_Re  ],
                    ["solbem" ,Solbem_mayor, Modulaciones_Solbem_mayor, Bajo_Sol, Alto_Sol ] ]

Escalas_menores = [ ["la"     ,La_menor    , Modulaciones_La_menor    , Bajo_La , Alto_La  ],
                    ["mi"     ,Mi_menor    , Modulaciones_Mi_menor    , Bajo_Mi , Alto_Mi  ],
                    ["si"     ,Si_menor    , Modulaciones_Si_menor    , Bajo_Si , Alto_Si  ],
                    ["fasos"  ,Fasos_menor , Modulaciones_Fasos_menor , Bajo_Fa , Alto_Fa  ],
                    ["dosos"  ,Dosos_menor , Modulaciones_Dosos_menor , Bajo_Do , Alto_Do  ],
                    ["solsos" ,Solsos_menor, Modulaciones_Solsos_menor, Bajo_Sol, Alto_Sol ],
                    ["resos"  ,Resos_menor , Modulaciones_Resos_menor , Bajo_Re , Alto_Re  ],
                    ["re"     ,Re_menor    , Modulaciones_Re_menor    , Bajo_Re , Alto_Re  ],
                    ["sol"    ,Sol_menor   , Modulaciones_Sol_menor   , Bajo_Sol, Alto_Sol ],
                    ["do"     ,Do_menor    , Modulaciones_Do_menor    , Bajo_Do , Alto_Do  ],
                    ["fa"     ,Fa_menor    , Modulaciones_Fa_menor    , Bajo_Fa , Alto_Fa  ],
                    ["sibem"  ,Sibem_menor , Modulaciones_Sibem_menor , Bajo_Si , Alto_Si  ],
                    ["mibem"  ,Mibem_menor , Modulaciones_Mibem_menor , Bajo_Mi , Alto_Mi  ] ]

# Acordes

Acordes_mayores = [ ["I"     ,I_mayor      ],
                    ["ii"    ,ii_mayor     ],
                    ["iii"   ,iii_mayor    ],
                    ["IV"    ,IV_mayor     ],
                    ["V"     ,V_mayor      ],
                    ["V7"    ,V7_mayor     ],
                    ["vi"    ,vi_mayor     ],
                    ["viidis",viidis_mayor ] ]

Acordes_menores = [ ["i"     ,i_menor      ],
                    ["iidis" ,iidis_menor  ],
                    ["III"   ,III_menor    ],
                    ["iv"    ,iv_menor     ],
                    ["IV"    ,IV_menor     ],
                    ["v"     ,v_menor      ],
                    ["V"     ,V_menor      ],
                    ["V7"    ,V7_menor     ],
                    ["VI"    ,VI_menor     ],
                    ["VII"   ,VII_menor    ] ]

# Equivalencias en tiempos

# En 2(Blanca)
Tiempos_2 = [ [ 0.25, [ 8.0 ]      ],
              [ 0.50, [ 4.0 ]      ],
              [ 0.75, [ 4.5 ]      ],
              [ 1.00, [ 2.0 ]      ],
              [ 1.50, [ 2.5 ]      ],
              [ 2.00, [ 1.0 ]      ],
              [ 2.50, [ 1.0, 4.0 ] ],
              [ 3.00, [ 1.5      ] ],
              [ 3.50, [ 1.5, 4.0 ] ],
              [ 4.00, [ 1.0, 1.0 ] ],
              [ 4.50, [ 1.0, 1.0, 4.0 ] ],
              [ 5.00, [ 1.0, 1.0, 2.0 ] ],
              [ 5.50, [ 1.0, 1.0, 2.5 ] ],
              [ 6.00, [ 1.5, 1.5      ] ],
              [ 7.00, [ 1.0, 1.0, 1.5      ] ],
              [ 8.00, [ 1.0, 1.0, 1.0, 1.0 ] ] ]

# En 4(Negra)
Tiempos_4 = [ [ 0.25, [ 16.0 ]      ],
              [ 0.50, [  8.0 ]      ],
              [ 0.75, [  8.5 ]      ],
              [ 1.00, [  4.0 ]      ],
              [ 1.50, [  4.5 ]      ],
              [ 2.00, [  2.0 ]      ],
              [ 2.50, [  2.0, 8.0 ] ],
              [ 3.00, [  2.5 ]      ],
              [ 3.50, [  2.5, 8.0 ] ],
              [ 4.00, [  1.0 ]      ],
              [ 4.50, [  1.0, 8.0 ] ],
              [ 5.00, [  1.0, 4.0 ] ],
              [ 5.50, [  1.0, 4.5 ] ],
              [ 6.00, [  1.5      ] ],
              [ 7.00, [  1.0, 2.5 ] ],
              [ 8.00, [  1.0, 1.0 ] ] ]

# En 8(Corchea)
Tiempos_8 = [ [ 0.25, [ 32.0 ]     ],
              [ 0.50, [ 16.0 ]     ],
              [ 0.75, [ 16.5 ]     ],
              [ 1.00, [  8.0 ]     ],
              [ 1.50, [  8.5 ]     ],
              [ 2.00, [  4.0 ]     ],
              [ 2.50, [  4.0, 16.0 ] ],
              [ 3.00, [  4.5 ]     ],
              [ 3.50, [  4.5, 16.0 ] ],
              [ 4.00, [  2.0 ]     ],
              [ 4.50, [  2.0, 16.0 ] ],
              [ 5.00, [  2.0, 8.0  ] ],
              [ 5.50, [  2.0, 8.5  ] ],
              [ 6.00, [  2.5       ] ],
              [ 7.00, [  2.0, 4.5  ] ],
              [ 8.00, [  1.0       ] ] ]

# En 16(Semicorchea)
Tiempos_16 = [ [ 0.25, [ 64.0 ]     ],
               [ 0.50, [ 32.0 ]     ],
               [ 0.75, [ 32.5 ]     ],
               [ 1.00, [ 16.0 ]     ],
               [ 1.50, [ 16.5 ]     ],
               [ 2.00, [  8.0 ]     ],
               [ 2.50, [  8.0, 32.0 ] ],
               [ 3.00, [  8.5 ]     ],
               [ 3.50, [  8.5, 32.0 ] ],
               [ 4.00, [  4.0 ]     ],
               [ 4.50, [  4.0, 32.0 ] ],
               [ 5.00, [  4.0, 16.0 ] ],
               [ 5.50, [  4.0, 16.5 ] ],
               [ 6.00, [  4.5       ] ],
               [ 7.00, [  4.0, 8.5  ] ],
               [ 8.00, [  2.0       ] ] ]
