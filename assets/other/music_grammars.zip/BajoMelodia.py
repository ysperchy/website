# -*- coding: UTF-8 -*-

###
### Archivo que genera las notas de la
### partitura a partir de la progresión
### y probabilidades de cada duración de nota
###
### El ritmo final quedá así(tanto para bajo como para melodía)
### Partitura es compuesta de compases:
###   P  = [ C1, C2, ..., Cn]
### Cada compás está compuesto de eventos:
###   Cx = [ E1, E2, ..., En]
### Pueden haber compases especiales que no denotan nota sino eventos en la partitura
###   Ej: ['A'] = Anacrusa, ['modxx'] = Modulación xx
### Cada evento costa de su conjunto de notas y la duración del evento
###   Ex = [ Notas, Duración ]
### Las notas son el número relativo a su escala y su "alteración"
### Ej: Si estamos en La menor, [1, "nat"] = La, [5, "sos"] = Mi sostenido
###   Notas = [ N1, N2, ..., Nn]
### La duración es los tiempos que sumados dan la duración exacta de las notas
###   Duración = [ D1, D2, ..., Dn]
### La mayoría son solo una duración, cuando hay más de una se usa ligaduras
###

# Generador de números aleatorios
from random import randrange

## Funciones
execfile( "Ritmos.py" )
execfile( "Definiciones.py" )
execfile( "Adjudicacion.py" )

# Probabilidad de las notas en el bajo
ProbabilidadNormalBajo   = []  # Usada para ritmos normales
ProbabilidadEspecialBajo = []  # Usada para ritmos en compases importantes(ej:climax, I, V)
ProbabilidadFinalBajo    = []  # Usada para compaces que enmarcan finales
EventosBajo              = []  # Probabilidades usadas en el cambio de un ritmo

# Probabilidad de las notas en la melodia
ProbabilidadNormalMelodia   = []  # Usada para ritmos normales
ProbabilidadEspecialMelodia = []  # Usada para ritmos en compases importantes(ej:climax, I, V)
ProbabilidadFinalMelodia    = []  # Usada para compaces que enmarcan finales
EventosMelodia              = []  # Probabilidades usadas en el cambio de un ritmo

# Leo las probabilidades del bajo y las guardo
Leer_Prob( "ritmos bajo.txt" )
ProbabilidadNormalBajo[:]   = Pn[:]
ProbabilidadEspecialBajo[:] = Pe[:]
ProbabilidadFinalBajo[:]    = Pf[:]
EventosBajo[:]              = Ev[:]

# Leo las probabilidades de la melodia y las guardo
Leer_Prob( "ritmos melodia.txt" )
ProbabilidadNormalMelodia[:]   = Pn[:]
ProbabilidadEspecialMelodia[:] = Pe[:]
ProbabilidadFinalMelodia[:]    = Pf[:]
EventosMelodia[:]              = Ev[:]


##
## Funciones de creacion de ritmos para la sugerencia
##

# Función que genera el ritmo completo de la partitura a partir de una progresión
# N = Numerador en el compás( cuantas unidades de tiempo contiene el compás )
def GenerarRitmoCompleto( N, Progresion, Pnormal, Pespecial, Pfinal, Eventos ):
    # Sugerencia siendo producida
    Sugerencia = []
    # Booleano que indica si el ritmo actual ha sido complicado o simplificado(solo se puede hacer esto una vez )
    Alterado = False
    # Lista de ritmos anteriores usados(para reencauchar)
    RitmosAnteriores = []

    # Creo ritmos para empezar
    RitmoNormal   = Generar_Ritmo( N, Pnormal )
    RitmoEspecial = Generar_Ritmo( N, Pespecial )
    RitmoFinal    = Generar_Ritmo( N, Pfinal )

    c = 0 # Contador para llevar cuenta de los compases
    a = False # Si hay que desarrollar un tiempo de anacrusa
    for x in Progresion:
        # Modulacion no cuenta
        if x[:3] == "mod":
            c = c + 1
            continue
        # Anacrusa
        elif x[:3] == "ana":
            a = True
        # Establecer el tiempo de anacrusa
        elif a == True:
            Sugerencia = Sugerencia + [[ 1.0 ]]
            a = False
        # Ritmo Final(llegando a los ultimos 3 compases)
        elif c >= ( len(Progresion) - 3 ):
            Sugerencia = Sugerencia + [RitmoFinal]
        # Ritmo Especial
        elif x in [ "I", "i", "V", "v", "V7" ]:
            Sugerencia = Sugerencia + [RitmoEspecial]

            # Evento
            if x in [ "I", "i" ]:
                # Elijo el evento aleatoriamente de acuerdo a las probabildades
                r = randrange( 0, 100 )
                even = []
                for e in Eventos:
                    if( r >= e[1] and r < e[2] ):
                        even = e
                        break
                # Lo ejecuto
                if e[0] == "Igual": # El ritmo sigue igual
                    c = c + 1
                    continue
                elif e[0] == "Simplifica" and Alterado == False: # El ritmo se simplifica
                    RitmoNormal[:]   = Simplificar_Ritmo( RitmoNormal )
                    RitmoEspecial[:] = Simplificar_Ritmo( RitmoEspecial )
                    Alterado = True
                elif e[0] == "Complica" and Alterado == False: # El ritmo se complica
                    RitmoNormal[:]   = Complicar_Ritmo( RitmoNormal)
                    RitmoEspecial[:] = Complicar_Ritmo( RitmoEspecial )
                    Alterado = True
                elif e[0] == "Cambia": # El ritmo se cambia totalmente
                    RitmosAnteriores = RitmosAnteriores + [[ RitmoNormal, RitmoEspecial, RitmoFinal ]]
                    RitmoNormal[:]   = Generar_Ritmo( N, Pnormal )
                    RitmoEspecial[:] = Generar_Ritmo( N, Pespecial )
                    RitmoFinal[:]    = Generar_Ritmo( N, Pfinal )
                elif e[0] == "Retoma" and len(RitmosAnteriores) > 0 : # Un ritmo anterior se retoma
                    L = RitmosAnteriores[ randrange( 0, len(RitmosAnteriores) ) ]
                    RitmoNormal[:]   = L[0]
                    RitmoEspecial[:] = L[1]
                    RitmoFinal[:]    = L[2]
        else:
            Sugerencia = Sugerencia + [RitmoNormal]
        c = c + 1
    # Retorno la sugerencia en ritmos generada
    return Sugerencia


# Función que adjudica notas a la sugerencia en ritmos
# Ritmo = Tiempos del ritmo
# Progresion =  Progresión de acordes sugerida
# Color = Escala mayor o menor
# N = Denominador del compás
# Adjudicación = Función que adjudica notas a sus tiempos(una función especial dependiendo si es bajo o melodia)
def GenerarRitmoNotas( N, Ritmo, Progresion, Color, Adjudicacion ):
    # Encuentro las equivalencias de duraciones
    Tiempos = [ 2, 4, 8, 16 ]
    Equivalencias = [ Tiempos_2, Tiempos_4, Tiempos_8, Tiempos_16 ]
    ListaDuraciones = Equivalencias[Tiempos.index(N)]
    # Empiezo la adjudicación de notas
    RitmoNotas = []
    c = 0
    for x in Progresion:
        # Si el compás es anacrusa
        if x[:3] == "ana":
            RitmoNotas = RitmoNotas + ['A']
            c = c - 1
        # Si se hace una modulación
        elif x[:3] == "mod":
            # Verifico que no haya cambiado de color la escala
            if Color == "Mayor" and x in [ "mod3", "mod4", "mod61", "mod71" ]:
                Color = "Menor"
            elif Color == "Menor" and x in [ "mod11", "mod3", "mod4", "mod62", "mod72" ]:
                Color = "Mayor"
            # Agrego la modulación
            RitmoNotas = RitmoNotas + [x]
            c = c - 1
        # Compás normal
        else:
            RitmoNotas = RitmoNotas + [Adjudicacion( ListaDuraciones, Ritmo[c], x, Color )]
        c = c + 1
    return RitmoNotas


# Función de interfaz para generar el ritmo del bajo
def GenerarRitmoCompletoBajo( Compas, Progresion, Color ):
    # Genero el ritmo
    Ritmo = GenerarRitmoCompleto( Compas[0], Progresion,
                                  ProbabilidadNormalBajo,
                                  ProbabilidadEspecialBajo,
                                  ProbabilidadFinalBajo,
                                  EventosBajo )
    # Adjudico las notas para el Bajo
    RitmoNotas = GenerarRitmoNotas( Compas[1], Ritmo, Progresion, Color, AdjudicacionBajo )
    # Retorno la sugerencia
    return RitmoNotas

# Función de interfaz para generar el ritmo del bajo
def GenerarRitmoCompletoMelodia( Compas, Progresion, Color ):
    # Genero el ritmo
    Ritmo = GenerarRitmoCompleto( Compas[0], Progresion,
                                  ProbabilidadNormalMelodia,
                                  ProbabilidadEspecialMelodia,
                                  ProbabilidadFinalMelodia,
                                  EventosMelodia )
    # Adjudico las notas para el Bajo
    RitmoNotas = GenerarRitmoNotas( Compas[1], Ritmo, Progresion, Color, AdjudicacionMelodia )
    # Retorno la sugerencia
    return RitmoNotas
