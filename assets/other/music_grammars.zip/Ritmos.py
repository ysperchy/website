# -*- coding: UTF-8 -*-

###
### Archivo que lee y procesa las probabilidades de cada unidad
### de tiempo en un ritmo tanto de bajo como melodía y las probabilidades
### de un evento dicho ente el cambio de un ritmo
###
### Las probabilidades de ritmo están dadas así:
###   U->Pn,Pe,Pf
### donde:
###   U  = Unidad de tiempo referida (0.5 = medio tiempo, 1.0 = tiempo completo, etc)
###      Ej: Si el compás fuese 4/4, 0.5 = corchea, 1.5 = negra con puntillo
###   Pn = Probabilidad en un compás normal
###   Pe = Probabilidad en un compás especial(climáx, Primer grado, Quinto Grado)
###   Pf = Probabilidad en un compás enmarcando el final de la canción
###
### Las probabilidades de un evento están dadas así:
###   E:->evento=P
### donde:
###   evento = Evento a ralizar
###   P      = Probabilidad de dicho evento
###

# Función random
from random import randrange

# Lista interaces para otros módulos
Pn = []
Pe = []
Pf = []
Ev = []
In = []

# Función que lee el archivo de probabilidades 
def Leer_Prob( nombre_archivo ):
    global Pn
    global Pe
    global Pf
    global Ev
    Pn = []
    Pe = []
    Pf = []
    Ev = []
    
    # Abro el archivo
    archivo = open( nombre_archivo, "r" )

    # Proceso cada línea
    linea = " "
    while True :
        # Siguiente línea
        linea = archivo.readline()
        # Acabó
        if linea == '':
            break
        # Comentario
        if linea[0] == '\n' or linea[0] == '#':
            continue
        # Linea
        Procesar_Linea_Prob( linea[:-1] )
    archivo.close()

# Función que procesa cada línea de las probabilidades
def Procesar_Linea_Prob( cadena ):
    izquierdo, derecho = cadena.strip().split( "->" ) # Parto la cadena
    # Si es un evento
    if izquierdo == "E:":
        izquierdo, derecho = derecho.strip().split( "=" )
        global Ev
        if Ev != []:
            Ev = Ev + [[ izquierdo, Ev[-1][2], Ev[-1][2] + int( float(derecho) * 100.0 ) ]]
        else:
            Ev = Ev + [[ izquierdo, 0, int( float(derecho) * 100.0 ) ]]
    # Si es una probabilidad
    else:
        n, e, f = derecho.strip().split( "," ) # Parto las probabilidades
        # Agrego a las listas
        global Pn
        global Pe
        global Pf
        if Pn != []:
            Pn = Pn + [[ float(izquierdo), Pn[-1][2], Pn[-1][2] + int( float(n) * 100.0 ) ]]
            Pe = Pe + [[ float(izquierdo), Pe[-1][2], Pe[-1][2] + int( float(e) * 100.0 ) ]]
            Pf = Pf + [[ float(izquierdo), Pf[-1][2], Pf[-1][2] + int( float(f) * 100.0 ) ]]
        else:
            Pn = Pn + [[ float(izquierdo), 0, int( float(n) * 100.0 ) ]]
            Pe = Pe + [[ float(izquierdo), 0, int( float(e) * 100.0 ) ]]
            Pf = Pf + [[ float(izquierdo), 0, int( float(f) * 100.0 ) ]]


# Función auxiliar que suma todos los elementos de una lista
def Suma_Lista( L ):
    c = 0
    for x in L:
        c = c + x
    return c

# Función que genera un ritmo aleatorio
def Generar_Ritmo( n, L ): # n = Número de unidades por los cuales está divido cada compás, L = Lista de prob. a usar
    R = []
    while( Suma_Lista( R ) != n ):
        r = randrange( 0, 100 )
        for p in L:
            if( r >= p[1] and r < p[2] ):
                R = R + [p[0]]
                break
        if Suma_Lista( R ) > n:
            R = R[:-1]
    return R


# Función que convierte un ritmo a uno más complejo
def Complicar_Ritmo( L ) : # L = Ritmo creado a complicar
    r = randrange( 0, len(L) )
    return L[:r] + [ L[r] / 2, L[r] / 2 ] + L[r+1:]

# Función que convierte un ritmo en uno más simple
def Simplificar_Ritmo( L ): # L = Ritmo creado a simplificar
    if len(L) == 1 :
        return L
    r1 = randrange( 0, len(L) )
    r2 = randrange( 0, len(L) )
    while r2 == r1:
        r2 = randrange( 0, len(L) )
    L[r1] = L[r1] + L[r2]
    L.pop(r2)
    return L
        
    
##
## Manejo de intervalos
##

# Función que lee el archivo de probabilidades de intérvalos
def Leer_Intervalos( nombre_archivo ):
    global In
    In = []

    # Abro el archivo
    archivo = open( nombre_archivo, "r" )

    # Proceso cada línea
    linea = " "
    while True :
        # Siguiente línea
        linea = archivo.readline()
        # Acabó
        if linea == '':
            break
        # Comentario
        if linea[0] == '\n' or linea[0] == '#':
            continue
        # Linea
        Procesar_Linea_Intervalo( linea[:-1] )
    archivo.close()

# Función que procesa cada línea de las probabilidades de los intérvalos
def Procesar_Linea_Intervalo( cadena ):
    # Parto la cadena
    izquierdo, derecho = cadena.strip().split( "->" ) # Parto la cadena
    global In
    # Incluyo la probabilidad en la lista
    if In == []:
        In = In + [[ int(izquierdo), [ 0, int( float(derecho) * 100.0 ) ]]]
    else:
        In = In + [[ int(izquierdo), [ In[-1][-1][-1], In[-1][-1][-1] + int( float(derecho) * 100.0 ) ]]]

# Función que genera un intérvalo dado una lista de probabilidades de intérvalos
def Generar_Intervalo( ListaProb ):
    I = 0
    r = randrange(0, 100)
    for p in ListaProb:
       if( r >= p[1][0] and r < p[1][1] ):
           I = p[0]
           break
    return I - 1


## Ejemplo

## Leer_Prob( "ritmos bajo.txt" )
## print Pn
## print Pe
## print Pf
## l = Generar_Ritmo( 4, Pn )
## print l
## print Complicar_Ritmo( l )
## print Simplificar_Ritmo( l )
## Leer_Intervalos( "intervalos.txt" )
## print In
## print Generar_Intervalo( In)
