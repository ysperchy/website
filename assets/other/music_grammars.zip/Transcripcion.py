# -*- coding: UTF-8 -*-

###
### Archivo que transcribe la lista de partitura
### al formato que toma el arhcivo "Partirura.py"
###

# Equivalencia de los nombres de las notas
Eq = [ ["do",["do","nat"] ],
       ["re",["re","nat"] ],
       ["mi",["mi","nat"] ],
       ["fa",["fa","nat"] ],
       ["sol",["sol","nat"] ],
       ["la",["la","nat"] ],
       ["si",["si","nat"] ],
       ["sibem",["si","bem"] ],
       ["mibem",["mi","bem"] ],
       ["labem",["la","bem"] ],
       ["rebem",["re","bem"] ],
       ["solbem",["sol","bem" ] ],
       ["fasos",["fa","sos"] ],
       ["dosos",["do","sos"] ],
       ["solsos",["sol", "sos"] ],
       ["resos",["re","sos"] ] ]

# Función que transcribe la partitura
# Partitura: Lista notas agrupadas por compases a transcribir
# Color: Color de la tónica(Mayor o Menor)
# Tonalidad: Tónica actual de la partitura
# Modo: Si se genera una partitura para un bajo o una melodía
def GenerarTranscripcion( Partitura, Color, Tonalidad, Modo ):
    # Verifico que la progresión no halla acabado
    if len(Partitura) == 0:
        return []

    # Selecciono las escalas adecuadas
    if Color == "Mayor":
        Escalas    = Escalas_mayores
        
    if Color == "Menor":
        Escalas    = Escalas_menores
        
    # Selecciono la escala correspondiente, modulacion y altura de notas
    nombre       = ""
    escala       = []
    modulaciones = []
    alturas      = []
    for x in Escalas:
        if x[0] == Tonalidad:
            nombre       = x[0]
            escala       = x[1]
            modulaciones = x[2]
            if Modo == "Bajo":
                alturas  = x[3]
            elif Modo == "Melodia":
                alturas  = x[4]
            break

    Compas = Partitura[0]
    
    # Manejo cada compás o evento de la partitura
    # Si es anacrusa
    if Compas == 'A':
        T = [[ "EVENTO", "ana", Partitura[1][-1][1][0] ]] # Seleciono el tiempo de la anacrusa
        T = T + GenerarTranscripcion( Partitura[1:], Color, Tonalidad, Modo )
        return T
    
    # Si es una modulación
    elif Compas[:3] == "mod":
        modulacion = []
        # Encuentro la modulación
        for x in modulaciones:
            if x[0] == Compas:
                modulacion = x
                break
        # Encuentro su nombre equivalente
        equiv = []
        for y in Eq:
            if y[0] == modulacion[1]:
                equiv = y[1]
                break
            # Devuelvo
        T = [[ "EVENTO", "ton", [ equiv[0], equiv[1] ] , modulacion[2] ]]
        T = T + GenerarTranscripcion( Partitura[1:], modulacion[2], modulacion[1], Modo )
        return T

    # Si es un compás normal
    else:
        # Por cada evento en el compás
        T = []
        for e in Compas:
            Notas = e[0]
            Duraciones = e[1]
            # Hallo las notas y su altura
            EN = []
            # Verifico si es un silencio
            if Notas == []:
                EN = [["r"]] # Escribo un silencio
            for x in Notas:
                i = 0
                Nota = ""
                Alteracion = ""
                Altura = 0
                if x[0] > 7:
                    i = x[0] - 7 - 1
                    Altura = 1
                else:
                    i = x[0] - 1
                    Altura = 0
                # Nota, Alteracion, Altura
                Nota       = escala[i][0]
                Alteracion = ""
                if x[1] == "nat":
                    Alteracion = escala[i][1]
                if x[1] == "sos":
                    if escala[i][1] == "sos":
                        Alteracion = "2sos"
                    elif escala[i][1] == "bem":
                        Alteracion = "nat"
                    elif escala[i][1] == "nat":
                        Alteracion = "sos"
                if x[1] == "bem":
                    if escala[i][1] == "sos":
                        Alteracion = "nat"
                    elif escala[i][1] == "bem":
                        Alteracion = "2bem"
                    elif escala[i][1] == "nat":
                        Alteracion = "bem"
                Altura = Altura + alturas[i]
                EN = EN + [[ Nota, Alteracion, Altura ]]
            # Hallo las duraciones para verificar ligados
            for d in Duraciones:
                T = T + [[ "NOTA", EN, d ]] + [[ "EVENTO", "lig" ]]
            T = T[:-1]
        return T + GenerarTranscripcion( Partitura[1:], Color, Tonalidad, Modo )


# Función que genera la transcripción de bajo
def GenerarTranscripcionBajo( Partitura, Color, Tonalidad, Bpp ):
    T = GenerarTranscripcion( Partitura, Color, Tonalidad, "Bajo" )
    E1 = [[ "EVENTO", "tempo", 4, Bpp ]]
    equiv = []
    for y in Eq:
        if y[0] == Tonalidad:
            equiv = y[1]
            break
    E2 = [[ "EVENTO", "ton", [ equiv[0], equiv[1] ] , Color ]]
    T = E1 + E2 + T
    return T

# Función que genera la transcripción de melodia
def GenerarTranscripcionMelodia( Partitura, Color, Tonalidad, Bpp ):
    T = GenerarTranscripcion( Partitura, Color, Tonalidad, "Melodia" )
    E1 = [[ "EVENTO", "tempo", 4, Bpp ]]
    equiv = []
    for y in Eq:
        if y[0] == Tonalidad:
            equiv = y[1]
            break
    E2 = [[ "EVENTO", "ton", [ equiv[0], equiv[1] ] , Color ]]
    T = E1 + E2 + T
    return T
