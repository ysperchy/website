# -*- coding: UTF-8 -*-

# Funciones necesarias
execfile( "Progresion.py" )
execfile( "BajoMelodia.py" )
execfile( "Transcripcion.py" )
execfile( "Partitura.py" )

# Parámetros iniciales

Color      = "Mayor"
Tonalidad  = "sol"
NoCompases = 20
Compas     = [ 4, 4]
Bpp        = 110
Midi       = True
Output     = "sug.ly"

# Realizo la progresión
Progresion = GenerarProgresionTotal( Color, NoCompases )
#print Progresion
RitmoBajo = GenerarRitmoCompletoBajo( Compas, Progresion, Color )
#for x in RitmoBajo:
#    print x
RitmoMelodia = GenerarRitmoCompletoMelodia( Compas, Progresion, Color )
#for x in RitmoMelodia:
#    print x
Bajo = GenerarTranscripcionBajo( RitmoBajo, Color, Tonalidad, Bpp )
#for x in Bajo:
#    print x
Melodia = GenerarTranscripcionMelodia( RitmoMelodia, Color, Tonalidad, Bpp )
#for x in Melodia:
#    print x
Generar_Partitura( Bajo, Melodia, Compas, Bpp, Midi, Output )
