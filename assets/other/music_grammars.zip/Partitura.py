# -*- coding: UTF-8 -*-

###
### Archivo que contiene la función principal para
### generar la partirua en formato lilypond
###

### Lista de equivalencia entre notación italiana y notación alemana
Equivalencia = [ [ "do", "c"], [ "re", "d"], [ "mi", "e" ], [ "fa", "f" ], [ "sol", "g" ], [ "la", "a" ], [ "si", "b" ], [ "r", "r"] ]

### Funión que genera la cabecera de la paritura en lilypond
def Generar_Cabecera():
	Cabecera = ""
	Cabecera = Cabecera + "\\version \"2.6.3\"\n"
	Cabecera = Cabecera + "\\header\n{\n"
	Cabecera = Cabecera + "\ttitle    = \"Sugerencia\"\n"
	Cabecera = Cabecera + "\tcomposer = \"Generado por Musi-K\"\n"
	Cabecera = Cabecera + "\tsource   = \"Musi-K\"\n"
	Cabecera = Cabecera + "}\n\n"
	return Cabecera

### Función que genera la cola de la partitura en lilypond
def Generar_Cola( Bpp, Midi ):
	Cola = ""
	Cola = Cola + "\\score\n{\n"
	Cola = Cola + "\t\\new PianoStaff\n"
	Cola = Cola + "\t<< \melodia \\bajo >>\n"
	Cola = Cola + "\t\\layout { }\n"
	Cola = Cola + "}\n"
	# Si se desea una salida midi
	if Midi:
		Cola = Cola + "\\score\n{\n"
		Cola = Cola + "\t\\unfoldRepeats\n"
		Cola = Cola + "\t\\new PianoStaff\n"
		Cola = Cola + "\t<< \melodia \\bajo >>\n"
		Cola = Cola + "\t\\midi {\\tempo 4=" + str( Bpp ) + "}\n"
		Cola = Cola + "}\n"
	return Cola

### Función que genera la cadena lilypond de una clave dicha
def Generar_Clave( Clave, Color ):
	# Nota
	Cadena = ""
	for x in Equivalencia:
		if Clave[0] == x[0]:
			Cadena = x[1]
	# Alteración
	if   Clave[1] == "nat":
		Cadena = Cadena + " "
	elif Clave[1] == "sos":
		Cadena = Cadena + "is "
	elif Clave[1] == "bem":
		Cadena = Cadena + "es "
	elif Clave[1] == "2sos":
		Cadena = Cadena + "isis "
	elif Clave[1] == "2bem":
		Cadena = Cadena + "eses "
	# Color
	if   Color == "Mayor":
		Cadena = Cadena + "\\major"
	elif Color == "Menor":
		Cadena = Cadena + "\\minor"
	return Cadena

### Función que genera un evento
def Generar_Evento( Evento ):
	# Cambio de tiempo
	if   Evento[0] == "tempo":
		return "\\tempo " + str( Evento[1] ) + "=" + str( Evento[2] )
	# Cambio de tonalidad
	elif Evento[0] == "ton":
		return "\\set Staff.printKeyCancellation = ##f\n" + "\t\\key " + Generar_Clave( Evento[1], Evento[2] )
	# Repetición
	elif Evento[0] == "rep":
		if Evento[1]:
			return "\\repeat volta 2 {"
		else:
			return "}"
	# Anacrusa
	elif Evento[0] == "ana":
		Cadena = str( int( Evento[1]) )
		if ( Evento[1] - int( Evento[1] ) == 0.5 ):
			Cadena = Cadena + "."
		return "\\partial " + Cadena
	#Ligadura
	elif Evento[0] == "lig":
		return "~"

### Función que genera una nota o acorde
def Generar_Nota( Nota ):
	Cadena = ""
	# Nota o acorde
	if len( Nota[0] ) > 1:
		Cadena = Cadena + "< "
	for n in Nota[0]:
		# Verifico si es un silencio
		if n == "r":
			Cadena = "r "
			break
		# Escribo la nota
		global Equivalencia
		for x in Equivalencia:
			if n[0] == x[0]:
				Cadena = Cadena + x[1]
		# Escribo su alteración
		if   n[1] == "nat":
			Cadena = Cadena + ""
		elif n[1] == "sos":
			Cadena = Cadena + "is"
		elif n[1] == "bem":
			Cadena = Cadena + "es"
		elif n[1] == "2sos":
			Cadena = Cadena + "isis"
		elif n[1] == "2bem":
			Cadena = Cadena + "eses"
		#Escribo su altura
		if n[2] < 0:
			while n[2] != 0:
				Cadena = Cadena + ","
				n[2] = n[2] + 1
		elif n[2] > 0:
			while n[2] != 0:
				Cadena = Cadena + "'"
				n[2] = n[2] - 1
		Cadena = Cadena + " "
	# Cierro el acorde(si existe)
	if len( Nota[0] ) > 1:
		Cadena = Cadena + "> "
	# Duración
	Cadena = Cadena + str( int( Nota[1]) )
	if ( Nota[1] - int( Nota[1] ) == 0.5 ):
		Cadena = Cadena + "."
	return Cadena

### Función que genera una linea(staff) en la partitura
def Generar_Voz( Linea, Compas, Clave ):
	Voz = ""
	# Distingo entre el bajo y la melodía
	if   Clave == "Sol":
		Voz = Voz + "melodia = \n" #\\relative c''\n"
		Voz = Voz + "\\new Staff {\n"
		Voz = Voz + "\t\\clef treble\n"
	elif Clave == "Fa":
		Voz = Voz + "bajo = \n" #\\relative c\n"
		Voz = Voz + "\\new Staff {\n"
		Voz = Voz + "\t\\clef bass\n"
	Voz = Voz + "\t\\time " + str( Compas[0] ) + "/" + str( Compas[1] ) + "\n"
	# Manejo de Eventos en la partitura
	for x in Linea:
		if x[0] == 'EVENTO':
			Voz = Voz + "\t" + Generar_Evento( x[1:] ) + "\n"
		if x[0] == 'NOTA':
			Voz = Voz + "\t" + Generar_Nota( x[1:] ) + "\n"
	Voz = Voz + "}\n\n"
	return Voz
		
### Función principal
def Generar_Partitura( Bajo, Melodia, Compas, Bpp, Midi, Output ):
	# Genero las partes básicas del archivo
	print( "Generando Cabecera..." )
	Cabecera = Generar_Cabecera()
	print( "Generando Cola..." )
	Cola     = Generar_Cola( Bpp, Midi )
	print( "Generando Melodia..." )
	Melodia  = Generar_Voz( Melodia, Compas, "Sol" )
	print( "Generando Bajo..." )
	Bajo     = Generar_Voz( Bajo, Compas, "Fa" )
	# Creo el archivo en modo escritura
	print( "Abriendo Archivo..." )
	Archivo = open( Output, "w" )
	# Escribo las partes en él(el orden es importante)
	print( "Escribiendo partitura..." )
	Archivo.write( Cabecera )
	Archivo.write( Melodia )
	Archivo.write( Bajo )
	Archivo.write( Cola )
	# Cierro el archivo
	print( "Cerrando Archivo..." )
	Archivo.close()
	print( "OK!" )


## Ejemplo
## Melodia = [ [ "EVENTO", "tempo", 4, 60 ],
## 	    [ "EVENTO", "ton", [ "do", "nat" ] , "Menor" ],
## 	    [ "EVENTO", "ana", 4 ],
## 	    [ "NOTA", [ [ "sol", "nat", 1 ] ], 4.0 ],
## 	    [ "NOTA", [ [ "do", "nat", 2 ] ], 4.0 ],
## 	    [ "NOTA", [ [ "do", "nat", 2 ] ], 4.5 ],
## 	    [ "NOTA", [ [ "sol", "nat", 1 ] ], 8.0 ],
## 	    [ "NOTA", [ [ "do", "nat", 2 ] ], 4.0 ],
## 	    [ "EVENTO", "ton", [ "sol", "nat", 1 ] , "Mayor" ],
## 	    [ "EVENTO", "tempo", 4, 120 ],
## 	    [ "EVENTO", "rep", True ],
## 	    [ "NOTA", [ [ "sol", "nat", 1 ], [ "si", "nat",1 ] ], 4.0 ],
## 	    [ "NOTA", [ [ "fa", "sos", 2 ] ], 4.0 ],
## 	    [ "NOTA", [ [ "do", "nat",2 ] ], 2.0 ],
## 	    [ "EVENTO", "rep", False ] ]

## Bajo =  [ [ "EVENTO", "ton", [ "do", "nat", 0 ] , "Menor" ],
## 	  [ "EVENTO", "ana", 4 ],
## 	  [ "NOTA", [ [ "r", "nat", 0 ] ], 4.0 ],
## 	  [ "NOTA", [ [ "do", "nat",0 ], [ "mi", "bem",0 ], [ "sol", "nat", -1 ] ], 1.0 ],
## 	  [ "EVENTO", "lig" ],
## 	  [ "EVENTO", "ton", [ "sol", "nat", -1 ] , "Mayor" ],
## 	  [ "NOTA", [ [ "do", "nat", 0 ], [ "mi", "bem", 0 ], [ "sol", "nat", -1 ] ], 1.0 ] ]
## Compas = [ 4, 4 ]

## Bpp = 60

## Midi = True

## Generar_Partitura( Bajo, Melodia, Compas, Bpp, Midi )
