//
//  ba.cpp
//  D-Spaces
//
//  Created by Salim PERCHY on 18/02/2016.
//
//

#include "ba.h"

template <class ELEM_TYPE>
ba<ELEM_TYPE>::ba( std::vector<ELEM_TYPE> atoms, unsigned int n, bool inverted ) :
m_scse( scs<std::set<ELEM_TYPE>>( inverted ? cs<std::set<ELEM_TYPE>>( std::set<ELEM_TYPE>( atoms.begin(), atoms.end() ), std::set<ELEM_TYPE>() ) :
                                             cs<std::set<ELEM_TYPE>>( std::set<ELEM_TYPE>(), std::set<ELEM_TYPE>( atoms.begin(), atoms.end() ) ), n ),
        scse<std::set<ELEM_TYPE>>::E_CHOICE_FUNCTION::EC_MANUAL ) {
    
    // Recursive Lambda Function to calculate positions from the atoms set to produce an element of the powerset
    std::function<void(std::vector<int>&,int,int)> next = [&next] ( std::vector<int>& v, int i, int n ) -> void {
        v[i]++;
        if( v[i] > ( n - 1 ) - ( v.size() - (i + 1) ) ) {
            next( v, i - 1, n );
            v[i] = v[i-1] + 1;
        }
    };
    
    m_n = n;
    m_atoms = std::set<ELEM_TYPE>( atoms.begin(), atoms.end() );
    std::set<std::set<ELEM_TYPE>> Si;                   // Elements of length i-1 of powerset
    std::set<std::set<ELEM_TYPE>> Sj;                   // Elements of length i of powerset
    std::vector<std::set<ELEM_TYPE>> S = { m_atoms };   // Top or bottom (if inverted) element
    std::sort( atoms.begin(), atoms.end() ); // Each element of the powerset is produced orderded by its positions in the atoms set (this avoids further sorting when determining bounds)
    
    // Produce the power set. Each iteration produces the elements of length i
    for( int i = 0; i <= atoms.size(); i++ ) { // i = 0 and i = len(atoms) won't be added to the lattice (they are repeated) but will be added to the elements
        std::vector<int> v(i); // Example (length 3, 5 elements) v = [0,1,2], [0,1,3], [0,1,4], [0,2,3], ..., [2,3,4]
        std::vector<int> w(i); // Example (length 3, 5 elements) w = [2,3,4]
        std::iota( std::begin(v), std::end(v), 0 );
        std::iota( std::begin(w), std::end(w), atoms.size() - i );
        while( true ) {
            std::set<ELEM_TYPE> elem;
            std::vector<std::set<ELEM_TYPE>> Se; // bounds (lower or upper) of element
            std::for_each( v.begin(), v.end(), [atoms,&elem] (int e) { elem.insert( atoms.at(e) ); } ); // actual element (not the positions in the atoms vector)
            Sj.insert( elem );
            // Find the included elements of length i-1, i.e lower or upper (if lattice is inverted) bounds
            std::for_each( Si.begin(), Si.end(), [&Se,elem] (std::set<ELEM_TYPE> e) { if( std::includes( elem.begin(), elem.end(), e.begin(), e.end() ) ) Se.push_back( e ); } );
            m_elems.insert( elem ); // Add to elements
            m_scse.add_element( elem, ( inverted ? S : Se ), ( inverted ? Se : S ) ); // Add to lattice
            if( v != w ) // Next element of length i in powerset
                next( v, i - 1, atoms.size() );
            else // No elements of length i left to produce after last one
                break;
        }
        Si = Sj;
        Sj.clear();
    }
}

template <class ELEM_TYPE>
ba<ELEM_TYPE>::ba( const ba<ELEM_TYPE>& BA ) : m_scse( BA.m_scse ) {
    m_n     = BA.m_n;
    m_atoms = BA.m_atoms;
    m_elems = BA.m_elems;
}

template <class ELEM_TYPE>
ba<ELEM_TYPE>::~ba<ELEM_TYPE>( void ) = default;

template <class ELEM_TYPE>
void ba<ELEM_TYPE>::map_s( const std::function<std::set<ELEM_TYPE>(int, std::set<ELEM_TYPE>, std::set<ELEM_TYPE>)>& s_func, typename scse<std::set<ELEM_TYPE>>::E_CHOICE_FUNCTION e_func ) {
    for( int i = 1; i <= m_n; i++ )
        std::for_each( m_elems.begin(), m_elems.end(), [i,s_func,this] (std::set<ELEM_TYPE> e) { m_scse.s_map( i, { e }, s_func( i, e, m_atoms ) ); } );
    if( e_func != scse<std::set<ELEM_TYPE>>::E_CHOICE_FUNCTION::EC_MANUAL ) { // ATTENTION: The following hack to re-initialize an object is extremly DISCOURAGED (but works :\)
        scse<std::set<ELEM_TYPE>> t_scse( m_scse );
        m_scse.~scse();
        new(&m_scse) scse<std::set<ELEM_TYPE>>( t_scse, e_func );
    }
}

template <class ELEM_TYPE>
void ba<ELEM_TYPE>::map_e( const std::function<std::set<ELEM_TYPE>(int, std::set<ELEM_TYPE>, std::set<ELEM_TYPE>)>& e_func ) {
    for( int i = 1; i <= m_n; i++ )
        std::for_each( m_elems.begin(), m_elems.end(), [i,e_func,this] (std::set<ELEM_TYPE> e) { m_scse.e_map( i, { e }, e_func( i, e, m_atoms ) ); } );
}


template class ba<int>;
template class ba<char>;
template class ba<std::string>;
template class ba<std::pair<std::string,int>>;
