#include "libs/opengl.c"
#include "libs/openal.c"
#include "libs/math.c"
#include "libs/fonts.c"
#include "libs/camera.c"
#include "libs/terrain.c"
#include "libs/pSystem.c"
#include "libs/sprite.c"
#include "libs/shader.c"
#include "libs/shadow.c"
#include "libs/skybox.c"
#include "libs/model.c"
#include "libs/collision.c"
 

/* Especificaciones */
#define WIDTH      1920
#define HEIGHT     1080
#define BPP        32
#define DEPTH      16
#define FULLSCREEN GL_TRUE
#define VSYNC      GL_TRUE

/*** Fuente  ***/
FONT  fontArial;
COLOR fontColor  = WHITE;
char  timeText[15];
char  collisionText[20];
char  posText[50];

/*** FPS y Texto ***/
GLfloat totalTime = 0.0f;
char    fpsText[10];

/*** Sonidos ***/
SOUND     fxSound;
ALboolean playSound  = AL_FALSE;
ALboolean stopSound  = AL_FALSE;
ALboolean placeSound = AL_FALSE;

/*** Música ***/
MUSIC     ambMusic;
ALboolean playMusic    = AL_FALSE;
ALboolean stopMusic    = AL_FALSE;
ALboolean musicPlaying = AL_FALSE;

/*** Colisiones **/
GLboolean near       = GL_FALSE;
GLfloat   epsilon    = 0.1f;
GLfloat   iterations = 10;
VECTOR    gravity    = { 0.0f, -9.8f, 0.0f };

/*** Camara ***/
CAMERA cam = {  { 50.0f, 20.0f, 600.0f },  // pos
                {  1.0f,  0.0f,   0.0f },  // right
                {  0.0f,  1.0f,   0.0f },  // up
                {   0.0f,  0.0f,  -1.0f }, // look
                GL_FALSE, GL_FALSE,        // walk
                GL_FALSE, GL_FALSE,        // strafe
                GL_FALSE, GL_FALSE,        // fly
                GL_FALSE, GL_FALSE, 60.0f, // pitch
                GL_FALSE, GL_FALSE,        // yaw
                GL_FALSE, GL_FALSE, 20.0f  // roll
};
GLfloat vel = 30.0f; // Velocidad de movimiento
GLfloat sen = 10.0f; // Sensibilidad del mouse

VECTOR cameraAxes = { 2.0f, 5.0f, 2.0f }; // Ejes de elipse rodeante

/*** Luces ***/
// Sol
COLOR    ambColor = BLACK;
DIRLIGHT dirLight = { WHITE, WHITE, BLACK, {0.0f, 1.0f, 1.0f} };

/*** Terreno ***/
TERRAIN  terrain;
MATERIAL terrainMtrl = {GRAY, GRAY, BLACK, BLACK, 0.0f};

/*** Skybox ***/
SKYBOX skybox;
BOX    skyboxBox   = {{0.0f, 0.0f, 0.0f}, {630.0f, 300.0f, 630.0f}};
COLOR  skyboxColor = WHITE;

/*** Sistema de partículas(Nieve) ***/
PSYSTEM pSystem;
BOX psystemBox = {{0.0f, 0.0f, 0.0f}, {(64-1)*10.0f, 255*1.0f, (64-1)*10.0f}};

// Función de reseto de partículas de nueve
void resetFunc( PSYSTEM* pSystem, PARTICLE* particle );
// Función de actualización de partículas de nive
void updateFunc( PSYSTEM* pSystem, PARTICLE* particle, float elapsed );

/*** Modelos ***/
MODEL    model;
VOLUMES  modelVolumes;
VOLUMES  cameraVolumes;
// Bounding Box
GLuint   boundingBox;
MATERIAL boxMaterial = {BLUE, BLUE, BLACK, BLACK, 0.0f};

// Lista de objetos
GLuint   nObjs = 2;
MODEL*   objList[2]    = { NULL, &model };
VOLUMES* objVolumes[2] = { &cameraVolumes, &modelVolumes };

/*** Inicialización de recursos ***/
void Init( void )
{
    // Inicio OpenGL
    InitOpenGL( WIDTH, HEIGHT, BPP, DEPTH, FULLSCREEN, VSYNC );
    SetOpenGL( WIDTH, HEIGHT, (GLfloat*)&ambColor, (GLfloat*)&ambColor );
    
    // Incio OpenAL
    InitOpenAL( NULL );
    
    // Escondo el cursor
    SDL_ShowCursor( SDL_DISABLE );
    
    // Inicio y cargo la fuente
    InitFont( WIDTH, HEIGHT );
    fontArial = OpenFont( "fonts/arial.ttf", 16 );
    SetFontStyle( fontArial, TTF_STYLE_NORMAL );
    
    // Sonidos
    CreateSound( &fxSound, "sounds/explosion.wav" );
    CreateMusic( &ambMusic, "sounds/sunday.ogg" );
    
    // Terreno
    InitTerrain( &terrain, "resources/coastMountain64.raw", "textures/grass.png",
                 GL_FALSE, &terrainMtrl, 64, 64, 10.0f, 1.0f );
    
    // Skybox
    InitSkybox( &skybox, "textures/skybox.png" );
    
    // Particulas
    InitPSystem( &pSystem, 5000, 500, "textures/snowflake.png", resetFunc, updateFunc );
    ResetPSystem( &pSystem );
    
    // Modelo
    LoadModel( "models/door.3ds", "textures", GL_FALSE, &model );
    BoundingVolumes( &model, &modelVolumes, NULL, GL_FALSE );
    // Bounding Box
    boxMaterial.diffuse.a = 0.2f;
    boundingBox = RenderBoundingBox( &modelVolumes.box.min,
                                     &modelVolumes.box.max,
                                     &boxMaterial );
    
    // Cámara
    CreateCameraVolume( cam, cameraAxes, &cameraVolumes );
}

/*** Liberación de recursos ***/
void Free( void )
{
    // Libero la letra y las fuentes
    CloseFont( fontArial );
    FreeFont();
    
    // Libero el sonido
    FreeSound( &fxSound );
    FreeMusic( &ambMusic );
    
    // Libero el terreno
    FreeTerrain( &terrain );
    
    // Libero el skybox
    FreeSkybox( &skybox );
    
    // Libero las partículas
    FreePSystem( &pSystem );
    
    // Libero el modelo
    FreeModel( &model );
    glDeleteLists( boundingBox, 1 );
    
    // Último
    FreeOpenAL();
    FreeOpenGL();
}

/*** Procesamiento de los dispositivos de entrada ***/
void Input( float elapsed )
{
    SDL_Event event;
    /* Proceso los eventos de input hasta que no haya más */
    while( SDL_PollEvent( &event ) )
    {
        switch( event.type )
        {
            case SDL_KEYUP:
                switch( event.key.keysym.sym )
                {
                    case SDLK_ESCAPE:
                        g_ExitProgram = GL_TRUE;
                        break;
                    case SDLK_F6:
                        CreateScreenshot( "Ejercicio" );
                        break;
                    case SDLK_SPACE:
                        placeSound = AL_TRUE;
                        break;
                    case SDLK_w:
                        cam.walk      = GL_FALSE;
                        break;
                    case SDLK_s:
                        cam.walkinv   = GL_FALSE;
                        break;
                    case SDLK_d:
                        cam.strafe    = GL_FALSE;
                        break;
                    case SDLK_a:
                        cam.strafeinv = GL_FALSE;
                        break;
                    case SDLK_m:
                        if( musicPlaying )
                            stopMusic = AL_TRUE;
                        else
                            playMusic = AL_TRUE;
                        break;
                    default:
                        PrintError( "Unhandled KEYUP event", GL_TRUE );
                }
                break;
                
            case SDL_KEYDOWN:
                switch( event.key.keysym.sym )
                {
                    case SDLK_ESCAPE:
                        break;
                    case SDLK_F6:
                        break;
                    case SDLK_SPACE:
                        break;
                    case SDLK_w:
                        cam.walk      = GL_TRUE;
                        break;
                    case SDLK_s:
                        cam.walkinv   = GL_TRUE;
                        break;
                    case SDLK_d:
                        cam.strafe    = GL_TRUE;
                        break;
                    case SDLK_a:
                        cam.strafeinv = GL_TRUE;
                        break;
                    case SDLK_m:
                        break;
                    default:
                        PrintError( "Unhandled KEYDOWN event", GL_TRUE );
                }
                break;
            
            /* Botones del mouse */
            case SDL_MOUSEBUTTONUP:
                switch( event.button.button )
                {
                    case SDL_BUTTON_LEFT:
                        playSound = AL_TRUE;
                        break;
                    case SDL_BUTTON_RIGHT:
                        stopSound = AL_TRUE;
                        break;
                    default:
                        PrintError( "Unhandled MOUSEBUTTONUP event", GL_TRUE );
                }
                break;
            
            case SDL_MOUSEBUTTONDOWN:
                switch( event.button.button )
                {
                    case SDL_BUTTON_LEFT:
                        break;
                    case SDL_BUTTON_RIGHT:
                        break;
                    default:
                        PrintError( "Unhandled MOUSEBUTTONDOWN event", GL_TRUE );
                }
                break;
            
                
            /* Movimiento del mouse */
            case SDL_MOUSEMOTION:
                {
                    /* Capturo los movimientos */
                    GLfloat xrel, yrel;
                    xrel = (GLfloat)event.motion.xrel;
                    yrel = (GLfloat)event.motion.yrel;
                
                    /* Movimiento en x */
                    if( xrel != 0 && xrel < 100 && xrel > -100 )
                        Yaw( &cam, xrel * elapsed * sen, GL_TRUE );
                
                    /* Movimiento en y */
                    if( yrel != 0 && yrel < 100 && yrel > -100 )
                        Pitch( &cam, yrel * elapsed * sen, GL_TRUE );
                }
                break;
                
            default:
                PrintError( "Unhandled type of event", GL_TRUE );
        }
        
        /* Borro el mensaje para evitar procesarlo de nuevo */
        memset( &event, 0, sizeof(SDL_Event) );
    }
}

/*** Procesamiento de la lógica del juego ***/
void Logic( float elapsed )
{
    // Actualizo el sistema de partículas
	UpdatePSystem( &pSystem, elapsed );
    
    /*** Modelos ***/
    static GLboolean passed = GL_FALSE;
    if( !passed )
    {
        // Escalación
        glScalef( 0.5f, 0.5f, 0.5f );
        BoundingVolumes( objList[1], objVolumes[1], NULL, GL_FALSE );
        // Traslación
        VECTOR disp = { 50.0f, GetHeight( &terrain, 50.0f, 550.0f ), 550.0f };
        UpdateVolumes( objVolumes[1], disp );
        // No se repite
        passed = !passed;
    }

    /*** Movimiento ***/
    VECTOR origin = cam.pos;
    /* Walk Fordward */
    if( cam.walk )
        Walk( &cam, elapsed * vel, GL_TRUE );
    /* Walk Backward */
    if( cam.walkinv )
        Walk( &cam, elapsed * -vel, GL_TRUE );
    /* Strafe Right */
    if( cam.strafe )
        Strafe( &cam, elapsed * vel, GL_TRUE );
    /* Strafe Left */
    if( cam.strafeinv )
        Strafe( &cam, elapsed * -vel, GL_TRUE );
    
    VECTOR disp  = ResVector( cam.pos, origin );
    
    /* Colisión de esferas */
    GLfloat time;
    VECTOR  cPos;
    if( SphereCollision( objVolumes[0], objVolumes[1],
                        disp, &time, &cPos ) )
        near = !near;
    
    /* Detección de colisión de la cámara */
    /* Desplazamiento */
    cam.pos = ResVector( cam.pos, disp );
    CollisionAndResponse( iterations, epsilon, &cam, &terrain,
                          objList, objVolumes, nObjs, 0, disp );
    
    /* Gravedad */
    disp = MulVector( gravity, elapsed );
    CollisionAndResponse( iterations, epsilon, &cam, &terrain,
                          objList, objVolumes, nObjs, 0, disp );
    
    // Altura de la cámara = altura del terreno + altura persona
    //cam.pos.y = GetHeight( &terrain, cam.pos.x, cam.pos.z ) + 5.0f;
    
    /* Tiempo total transcurrido */
    totalTime += elapsed;

}

/*** Procesamiento de cada cuadro de sonido ***/
void Sound( float elapsed )
{
    // Efectos de Sonido
    VECTOR vel = {0.0f, 0.0f, 0.0f};
    
    // Posición del espectador
    SetListener( (ALfloat*)&cam.pos, (ALfloat*)&cam.look, (ALfloat*)&cam.up, (ALfloat*)&vel );
    
    // Posición del Sonido
    if( placeSound )
    {
        fxSound.audioPosition[0] = cam.pos.x;
        fxSound.audioPosition[1] = cam.pos.y;
        fxSound.audioPosition[2] = cam.pos.z;
        placeSound = AL_FALSE;
    }
    
    // Sonido
    SetSoundProperties( &fxSound );
    if( playSound )
    {
        PlaySound( &fxSound, 1.0f, AL_FALSE );
        playSound = AL_FALSE;
    }
    if( stopSound )
    {
        StopSound( &fxSound );
        stopSound = AL_FALSE;
    }

    
    // Música
    if( playMusic )
    {
        PlayMusic( &ambMusic, 1.0f, AL_TRUE );
        playMusic    = AL_FALSE;
        musicPlaying = AL_TRUE;
    }
    if( stopMusic )
    {
        StopMusic( &ambMusic );
        stopMusic    = AL_FALSE;
        musicPlaying = AL_FALSE;
    }
    
    // Reproducción
    if( musicPlaying )
        StreamMusic( &ambMusic );
}

/*** Procesamiento de cada cuadro ***/
void Video( float elapsed )
{
    /* Limpio la pantalla */
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT );
    
    /* Perspectiva */
    glMatrixMode( GL_PROJECTION );
    glLoadIdentity();
    gluPerspective( 45.0f,                           // Ángulo de visión vertical
                   (GLfloat)WIDTH / (GLfloat)HEIGHT, // Aspecto
                   1.0f,                             // Plano cercano
                   1500.0f );                        // Plano lejano
    
    /* Cámara */
    glMatrixMode( GL_MODELVIEW );
    glLoadIdentity();
    VECTOR dir = SumVector( cam.pos, cam.look );
    gluLookAt( cam.pos.x , cam.pos.y , cam.pos.z , // Posición
               dir.x     , dir.y     , dir.z,      // Dirección
               0.0f      , 1.0f      , 0.0f );     // Arriba(Persona)

    
    // Luces
    SetDirLight( GL_LIGHT0, &dirLight );
    glEnable( GL_LIGHT0 );
    
    /*** Terreno ***/
    glPushMatrix(); // Guardo la cámara
    
    SetMaterial( &terrain.material );
    glBindTexture( GL_TEXTURE_2D, terrain.textureID );
    glCallList( terrain.terrainList );
    
    glPopMatrix(); // Restauro la cámara
    /*________*/
    
    /*** Skybox ***/
    glPushMatrix(); // Guardo la cámara
    RenderSkybox( &skybox, &skyboxBox, &skyboxColor );
    glPopMatrix(); // Restauro la cámara
    /*________*/
    
    /*** Sistema de partículas ***/
    glPushMatrix(); // Guardo la cámara
    RenderPSystem( &pSystem );
    glPopMatrix();  // Restauro la cámara
    /*________*/

    
    /*** Modelo ***/
    glPushMatrix();
    
    glMultTransposeMatrixf( modelVolumes.matrix );
    glCallList( model.modelList );
    //glCallList( boundingBox );
    
    glPopMatrix();
    /*________*/
    
    /* FPS */
    sprintf( fpsText, "%d fps", CalculateFPS( elapsed ) );
    RenderText( fpsText, fontArial, 0, 0, &fontColor, GL_FALSE );
    
    /* Time */
    sprintf( timeText, "Time: %.2fs", totalTime );
    RenderText( timeText, fontArial, 0,
                GetFontLineSkip( fontArial ), &fontColor, GL_FALSE );
    
    /* Colisión */
    // Cerca
    sprintf( collisionText, "Near: %s", near ? "True" : "False" );
    RenderText( collisionText, fontArial, 0,
                GetFontLineSkip( fontArial ) * 3, &fontColor, GL_FALSE );
    
    /* Posición */
    // Cámara
    sprintf( posText, "Camera pos: x=%.1f y=%.1f z=%.1f",
             cameraVolumes.sphere.center.x,
             cameraVolumes.sphere.center.y,
             cameraVolumes.sphere.center.z );
    RenderText( posText, fontArial, WIDTH - 280, 0, &fontColor, GL_FALSE );
    // Modelo
    sprintf( posText, "Sphere pos: x=%.1f y=%.1f z=%.1f",
             modelVolumes.sphere.center.x,
             modelVolumes.sphere.center.y,
             modelVolumes.sphere.center.z );
    RenderText( posText, fontArial, WIDTH - 280,
                GetFontLineSkip( fontArial ) , &fontColor, GL_FALSE );
    
    /* Ejecutar comandos en cola */
    glFlush();
    
    /* BackBuffer=FrontBuffer(flip) */
    SDL_GL_SwapBuffers();
}

/*** Loop ***/
void Loop( float elapsed )
{
    /* Input, Lógica, Sonido y Video */
    Input( elapsed );
    Logic( elapsed );
    Sound( elapsed );
    Video( elapsed );
}

/*** ResetFunc ***/
void resetFunc( PSYSTEM* pSystem, PARTICLE* particle )
{
    // Posición
    particle->pos.x = RandomFloat( psystemBox.min.x, psystemBox.max.x, 2 );
    particle->pos.y = psystemBox.max.y;
    particle->pos.z = RandomFloat( psystemBox.min.z, psystemBox.max.z, 2 );
    
    // Velocidad
    particle->vel.x = RandomFloat( 0.0f, 1.0f, 2 ) * -3.0f;
    particle->vel.y = RandomFloat( 0.0f, 1.0f, 2 ) * -10.0f;
    particle->vel.z = 0.0f;
    
    // Aceleración
    particle->acc.x = 0.0f;
    particle->acc.y = 0.0f;
    particle->acc.z = 0.0f;
    
    // Color
    COLOR c = WHITE;
    particle->color = c;
    
    // Life, age;
    particle->life = 0.0f;
    particle->age  = 0.0f;
    
    // Activa
    particle->active = GL_TRUE;
}

/*** UpdateFunc ***/
void updateFunc( PSYSTEM* pSystem, PARTICLE* particle, float elapsed )
{
    particle->pos = SumVector( particle->pos, MulVector( particle->vel, elapsed ) );
    particle->vel = SumVector( particle->vel, MulVector( particle->acc, elapsed ) );
    
    // Si se sale del area de nevado
    if( !PointInsideBox( psystemBox, particle->pos ) )
        ((ResetFunc*)pSystem->resetFunc)( pSystem, particle );
}
